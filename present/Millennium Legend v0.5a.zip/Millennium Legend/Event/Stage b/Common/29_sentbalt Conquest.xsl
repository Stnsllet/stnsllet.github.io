<?xml version="1.0" encoding="Shift_JIS"?>
<xsl:stylesheet xmlns:xsl="http://www.w3.org/1999/XSL/Transform" version="1.0"  xmlns:spibre="http://geroha.ld.infoseek.co.jp/spibre/">
<xsl:output method="xml" version="1.0" encoding="Shift_JIS" indent="yes" />

<xsl:param name="_temp_nodeid"/>
<xsl:param name="_temp_nodeleader"/>
<xsl:param name="_temp_nodelocker"/>
<xsl:param name="_temp_leaderid"/>

<xsl:template match="CallTrans">
	<xsl:variable name="param" select="@param"/>

	<xsl:variable name="name" select="@name"/>

	<xsl:element name="CallTrans">
		<xsl:attribute name="root">Event</xsl:attribute>
		<xsl:attribute name="path">=SC</xsl:attribute>
		<xsl:if test="@name = 'nodeset'">
			<xsl:element name="Range">
				<xsl:attribute name="name"><xsl:value-of select="$_temp_nodeleader"/></xsl:attribute>
				<xsl:attribute name="pos">=_temp_nodepos.<xsl:value-of select="$_temp_nodeid"/></xsl:attribute>
				<xsl:attribute name="length">180</xsl:attribute>
				<xsl:element name="ChkFlg">
					<xsl:attribute name="off">_temp_locker.<xsl:value-of select="$_temp_nodeid"/></xsl:attribute>
						<xsl:element name="Param">
							<xsl:attribute name="name">_temp_circle_gauge<xsl:value-of select="$_temp_nodeid"/></xsl:attribute>
							<xsl:attribute name="com">+</xsl:attribute>
							<xsl:attribute name="val">1</xsl:attribute>
							<xsl:attribute name="ex">clamp</xsl:attribute>
						</xsl:element>
							<xsl:element name="Function">
								<xsl:attribute name="func">threshNode</xsl:attribute>
								<xsl:attribute name="ex"><xsl:value-of select="$_temp_nodeid"/></xsl:attribute>	
							</xsl:element>
						<xsl:element name="Event">
							<xsl:attribute name="flg">e_locking<xsl:value-of select="$_temp_nodeid"/></xsl:attribute>
						</xsl:element>
						<xsl:element name="Param">
							<xsl:attribute name="name">_temp_circle_gauge<xsl:value-of select="$_temp_nodeid"/></xsl:attribute>
							<xsl:attribute name="com">=</xsl:attribute>
							<xsl:attribute name="val">9</xsl:attribute>
							<xsl:element name="Function">
								<xsl:attribute name="func">nodeLocker</xsl:attribute>
								<xsl:attribute name="ex"><xsl:value-of select="$_temp_nodeid"/>/_temp_locker.<xsl:value-of select="$_temp_nodeid"/>/<xsl:value-of select="$_temp_nodeleader"/></xsl:attribute>	
							</xsl:element>
						</xsl:element>
				</xsl:element>
				<xsl:element name="Timer">
					<xsl:attribute name="time">3000</xsl:attribute>
					<xsl:element name="Function">
						<xsl:attribute name="func">setSingleNode</xsl:attribute>
						<xsl:attribute name="ex"><xsl:value-of select="$_temp_nodeid"/>/<xsl:value-of select="$_temp_nodeleader"/></xsl:attribute>	
					</xsl:element>
				</xsl:element>
			</xsl:element>
		</xsl:if>
		<xsl:if test="@name = 'nodelock'">
			<xsl:element name="Event">
				<xsl:attribute name="flg"><xsl:value-of select="$_temp_nodelocker"/></xsl:attribute>
				<xsl:element name="Param">
					<xsl:attribute name="name"><xsl:value-of select="$_temp_nodelocker"/></xsl:attribute>
					<xsl:attribute name="val"><xsl:value-of select="$_temp_nodeleader"/></xsl:attribute>
				</xsl:element>
				<xsl:element name="State">
					<xsl:attribute name="name"><xsl:value-of select="$_temp_nodeleader"/></xsl:attribute>
					<xsl:attribute name="act">dead</xsl:attribute>
					<xsl:element name="Event">
						<xsl:attribute name="unflg"><xsl:value-of select="$_temp_nodelocker"/></xsl:attribute>
						<xsl:element name="Param">
							<xsl:attribute name="name"><xsl:value-of select="$_temp_nodelocker"/></xsl:attribute>
							<xsl:attribute name="val"></xsl:attribute>
						</xsl:element>
					</xsl:element>
				</xsl:element>
			</xsl:element>
		</xsl:if>
		<xsl:if test="@name = 'respawn'">
			<xsl:element name="Timer">
				<xsl:attribute name="time">=_temp_respawn_cooldown</xsl:attribute>
				<xsl:element name="Paty">
					<xsl:attribute name="brave">50</xsl:attribute>
					<xsl:attribute name="army">user</xsl:attribute>
					<xsl:attribute name="parampos">=_temp_conpos.<xsl:value-of select="$_temp_leaderid"/></xsl:attribute>
					<xsl:attribute name="no">=_temp_conleader.<xsl:value-of select="$_temp_leaderid"/></xsl:attribute>
				</xsl:element>
				<xsl:element name="Param">
					<xsl:attribute name="name">_temp_respawn_cooldown</xsl:attribute>
					<xsl:attribute name="com">+</xsl:attribute>
					<xsl:attribute name="val">1000</xsl:attribute>
				</xsl:element>									
				<xsl:element name="Function">
					<xsl:attribute name="func">setSingleNode</xsl:attribute>
					<xsl:attribute name="ex">A/=_temp_leader.<xsl:value-of select="$_temp_leaderid"/></xsl:attribute>	
				</xsl:element>
				<xsl:element name="Function">
					<xsl:attribute name="func">setSingleNode</xsl:attribute>
					<xsl:attribute name="ex">B/=_temp_leader.<xsl:value-of select="$_temp_leaderid"/></xsl:attribute>	
				</xsl:element>
				<xsl:element name="Function">
					<xsl:attribute name="func">setSingleNode</xsl:attribute>
					<xsl:attribute name="ex">C/=_temp_leader.<xsl:value-of select="$_temp_leaderid"/></xsl:attribute>	
				</xsl:element>
				<xsl:element name="Function">
					<xsl:attribute name="func">setLeaderRespone</xsl:attribute>
					<xsl:attribute name="ex"><xsl:value-of select="$_temp_leaderid"/></xsl:attribute>	
				</xsl:element>
			</xsl:element>
		</xsl:if>
	</xsl:element>

</xsl:template>

</xsl:stylesheet>
