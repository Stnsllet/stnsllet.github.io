<?xml version="1.0" encoding="Shift_JIS"?>
<xsl:stylesheet xmlns:xsl="http://www.w3.org/1999/XSL/Transform" version="1.0"  xmlns:spibre="http://geroha.ld.infoseek.co.jp/spibre/">
<xsl:output method="xml" version="1.0" encoding="Shift_JIS" indent="yes" />

<xsl:template match="CallTrans">
	<xsl:variable name="PasonData" select="document(concat('../',@file))/PasonData"/>
	<xsl:variable name="ItemData" select="document(concat('../',@file))/ItemData"/>
	<xsl:variable name="NewsList" select="document(concat('../',@file))/NewsList"/>
	<xsl:variable name="SkillDefine" select="document(concat('../',@file))/SkillDefine"/>
	<xsl:variable name="MoveDefine" select="document(concat('../',@file))/MoveDefine"/>
	<xsl:variable name="JobData" select="document(concat('../',@file))/JobData"/>
	<xsl:variable name="ex" select="@ex"/>
	
	<xsl:element name="List">
		<xsl:element name="Param">
			<xsl:attribute name="name">_temp_p</xsl:attribute>
			<xsl:attribute name="val"><xsl:value-of select="@get"/></xsl:attribute>
		</xsl:element>
		<xsl:if test="@type = 'Pason'">
		<xsl:for-each select="$PasonData/Pason">
			<xsl:if test="$ex = 'member'">
				<xsl:element name="Command">
					<xsl:attribute name="com">data/member/<xsl:value-of select="@name"/></xsl:attribute>
					<xsl:element name="Param">
						<xsl:attribute name="name">=_temp_p</xsl:attribute>
						<xsl:attribute name="com">+</xsl:attribute>
						<xsl:attribute name="val">/<xsl:value-of select="@name"/></xsl:attribute>
					</xsl:element>					
				</xsl:element>
			</xsl:if>
			<xsl:if test="$ex = '!member'">
				<xsl:element name="Choice">
					<xsl:element name="Command">
						<xsl:attribute name="com">data/member/<xsl:value-of select="@name"/></xsl:attribute>
						<xsl:element name="Event"/>
					</xsl:element>
					<xsl:element name="Param">
						<xsl:attribute name="name">=_temp_p</xsl:attribute>
						<xsl:attribute name="com">+</xsl:attribute>
						<xsl:attribute name="val">/<xsl:value-of select="@name"/></xsl:attribute>
					</xsl:element>			
				</xsl:element>
			</xsl:if>
			<xsl:if test="not($ex)">
			<xsl:element name="Param">
				<xsl:attribute name="name">=_temp_p</xsl:attribute>
				<xsl:attribute name="com">+</xsl:attribute>
				<xsl:attribute name="val">/<xsl:value-of select="@name"/></xsl:attribute>
			</xsl:element>
			</xsl:if>
		</xsl:for-each>
		</xsl:if>
		<xsl:if test="@type = 'Job'">
		<xsl:for-each select="$JobData/Job">
			<xsl:element name="Param">
				<xsl:attribute name="name">=_temp_p</xsl:attribute>
				<xsl:attribute name="com">+</xsl:attribute>
				<xsl:attribute name="val">/<xsl:value-of select="@name"/></xsl:attribute>
			</xsl:element>
		</xsl:for-each>
		</xsl:if>
		<xsl:if test="@type = 'Item'">
		<xsl:for-each select="$ItemData/Item">
			<xsl:element name="Param">
				<xsl:attribute name="name">=_temp_p</xsl:attribute>
				<xsl:attribute name="com">+</xsl:attribute>
				<xsl:attribute name="val">/<xsl:value-of select="@id"/></xsl:attribute>
			</xsl:element>
		</xsl:for-each>
		</xsl:if>
		<xsl:if test="@type = 'News'">
		<xsl:for-each select="$NewsList/Item">
			<xsl:element name="Param">
				<xsl:attribute name="name">=_temp_p</xsl:attribute>
				<xsl:attribute name="com">+</xsl:attribute>
				<xsl:attribute name="val">/<xsl:value-of select="@name"/></xsl:attribute>
			</xsl:element>
		</xsl:for-each>
		</xsl:if>
		<xsl:if test="@type = 'Move'">
		<xsl:for-each select="$MoveDefine/MoveType">
			<xsl:element name="Param">
				<xsl:attribute name="name">=_temp_p</xsl:attribute>
				<xsl:attribute name="com">+</xsl:attribute>
				<xsl:attribute name="val">/<xsl:value-of select="@name"/></xsl:attribute>
			</xsl:element>
		</xsl:for-each>
		</xsl:if>
		<xsl:if test="@type = 'Skill'">
		<xsl:for-each select="$SkillDefine/Skill">
			<xsl:element name="Param">
				<xsl:attribute name="name">=_temp_p</xsl:attribute>
				<xsl:attribute name="com">+</xsl:attribute>
				<xsl:attribute name="val">/<xsl:value-of select="@name"/></xsl:attribute>
			</xsl:element>
		</xsl:for-each>
		</xsl:if>
	</xsl:element>
</xsl:template>

</xsl:stylesheet>
