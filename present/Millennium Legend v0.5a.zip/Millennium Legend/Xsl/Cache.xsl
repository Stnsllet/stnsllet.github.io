<?xml version="1.0" encoding="Shift_JIS"?>
<xsl:stylesheet xmlns:xsl="http://www.w3.org/1999/XSL/Transform" version="1.0"  xmlns:spibre="http://geroha.ld.infoseek.co.jp/spibre/">
<xsl:output method="xml" version="1.0" encoding="Shift_JIS" indent="yes" />
<xsl:param name="_temp_cBgm"/>
<xsl:param name="_temp_cTex"/>
<xsl:param name="_temp_cTexpath"/>
<xsl:param name="_temp_cPoly"/>
<xsl:param name="_temp_cWave"/>
<xsl:param name="_temp_cXml"/>
<xsl:param name="_temp_cClear"/>

<msxsl:script xmlns:msxsl="urn:schemas-microsoft-com:xslt" language="JavaScript" implements-prefix="spibre">
  function cBgm(list){
	var array = list.split('/');
	var ret = '';
	for (i = 0; i &lt; array.length; i++) {
		ret = ret + '&lt;Cache bgm=&quot;' + array[i] + '&quot; /&gt;'
	}
   	return(ret);
  }
  function cTex(list){
	var array = list.split('/');
	var ret = '';
	for (i = 0; i &lt; array.length; i++) {
		ret = ret + '&lt;Cache tex=&quot;' + array[i] + '&quot; /&gt;'
	}
   	return(ret);
  }
  function cTexpath(list){
	var array = list.split('/');
	var ret = '';
	for (i = 0; i &lt; array.length; i++) {
		ret = ret + '&lt;Cache texpath=&quot;' + array[i] + '&quot; /&gt;'
	}
   	return(ret);
  }
  function cPoly(list){
	var array = list.split('/');
	var ret = '';
	for (i = 0; i &lt; array.length; i++) {
		ret = ret + '&lt;Cache poly=&quot;' + array[i] + '&quot; /&gt;'
	}
   	return(ret);
  }
  function cWave(list){
	var array = list.split('/');
	var ret = '';
	for (i = 0; i &lt; array.length; i++) {
		ret = ret + '&lt;Cache wave=&quot;' + array[i] + '&quot; /&gt;'
	}
   	return(ret);
  }
  function cXml(list){
	var array = list.split(',');
	var ret = '';
	for (i = 0; i &lt; array.length; i++) {
		ret = ret + '&lt;Cache xml=&quot;' + array[i] + '&quot; /&gt;'
	}
   	return(ret);
  }
  function cClear(list){
	var array = list.split('/');
	var ret = '';
	for (i = 0; i &lt; array.length; i++) {
		ret = ret + '&lt;Cache clear=&quot;' + array[i] + '&quot; /&gt;'
	}
   	return(ret);
  }
</msxsl:script>

<xsl:template match="CallTrans">
	<xsl:element name="Event">
		<xsl:value-of select="spibre:cClear($_temp_cClear)" disable-output-escaping="yes"/>
		<xsl:value-of select="spibre:cBgm($_temp_cBgm)" disable-output-escaping="yes"/>
		<xsl:value-of select="spibre:cTex($_temp_cTex)" disable-output-escaping="yes"/>
		<xsl:value-of select="spibre:cTexpath($_temp_cTexpath)" disable-output-escaping="yes"/>
		<xsl:value-of select="spibre:cPoly($_temp_cPoly)" disable-output-escaping="yes"/>
		<xsl:value-of select="spibre:cWave($_temp_cWave)" disable-output-escaping="yes"/>
		<xsl:value-of select="spibre:cXml($_temp_cXml)" disable-output-escaping="yes"/>
	</xsl:element>
</xsl:template>

<xsl:template match="*">
	<xsl:element name="Event">
		<xsl:copy-of select="."/>
	</xsl:element>
</xsl:template>

</xsl:stylesheet>
