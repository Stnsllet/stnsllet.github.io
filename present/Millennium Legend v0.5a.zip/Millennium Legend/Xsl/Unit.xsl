<?xml version="1.0" encoding="Shift_JIS"?>
<xsl:stylesheet xmlns:xsl="http://www.w3.org/1999/XSL/Transform" version="1.0"  xmlns:spibre="http://geroha.ld.infoseek.co.jp/spibre/">
<xsl:output method="xml" version="1.0" encoding="Shift_JIS" indent="yes" />

<xsl:template match="CallTrans">

<xsl:element name="Event">

	<xsl:if test="@pos">
		<xsl:element name="Param">
			<xsl:attribute name="name">_temp_pos</xsl:attribute>
			<xsl:attribute name="val"><xsl:value-of select="@pos"/></xsl:attribute>
		</xsl:element>
		<xsl:element name="Param">
			<xsl:attribute name="name">_temp_shiftpos</xsl:attribute>
			<xsl:attribute name="val"><xsl:value-of select="@pos"/></xsl:attribute>
		</xsl:element>
	</xsl:if>
	<xsl:if test="@type">
		<xsl:element name="Param">
			<xsl:attribute name="name">_temp_type</xsl:attribute>
			<xsl:attribute name="val"><xsl:value-of select="@type"/></xsl:attribute>
		</xsl:element>
	</xsl:if>
	<xsl:if test="@army">
		<xsl:element name="Param">
			<xsl:attribute name="name">_temp_army</xsl:attribute>
			<xsl:attribute name="val"><xsl:value-of select="@army"/></xsl:attribute>
		</xsl:element>
		<xsl:element name="Event"><xsl:attribute name="flg">t_ScUfArmy</xsl:attribute></xsl:element>
	</xsl:if>
	<xsl:if test="@form">
		<xsl:element name="Param">
			<xsl:attribute name="name">_temp_form</xsl:attribute>
			<xsl:attribute name="val"><xsl:value-of select="@form"/></xsl:attribute>
		</xsl:element>
	</xsl:if>
	<xsl:if test="@lead">
		<xsl:element name="Param">
			<xsl:attribute name="name">_temp_leader</xsl:attribute>
			<xsl:attribute name="val"><xsl:value-of select="@lead"/></xsl:attribute>
		</xsl:element>
		<xsl:element name="Event"><xsl:attribute name="flg">t_ScUfLead</xsl:attribute></xsl:element>
	</xsl:if>
	<xsl:if test="@brave">
		<xsl:element name="Param">
			<xsl:attribute name="name">_temp_brave</xsl:attribute>
			<xsl:attribute name="val"><xsl:value-of select="@brave"/></xsl:attribute>
		</xsl:element>
	</xsl:if>
	<xsl:if test="@ai">
		<xsl:element name="Param">
			<xsl:attribute name="name">_temp_ai</xsl:attribute>
			<xsl:choose>
			<xsl:when test="@ai = 'a'"><xsl:attribute name="val">attack</xsl:attribute></xsl:when>
			<xsl:when test="@ai = 'h'"><xsl:attribute name="val">help</xsl:attribute></xsl:when>
			<xsl:when test="@ai = 'w'"><xsl:attribute name="val">walking</xsl:attribute></xsl:when>
			<xsl:when test="@ai = 'f'"><xsl:attribute name="val">flying</xsl:attribute></xsl:when>
			<xsl:when test="@ai"><xsl:attribute name="val"><xsl:value-of select="@ai"/></xsl:attribute></xsl:when>
			</xsl:choose>
		</xsl:element>
		<xsl:element name="Event"><xsl:attribute name="flg">t_ScUfAi</xsl:attribute></xsl:element>
	</xsl:if>
	<xsl:if test="@count">
		<xsl:element name="Param">
			<xsl:attribute name="name">_temp_count</xsl:attribute>
			<xsl:attribute name="val"><xsl:value-of select="@count"/></xsl:attribute>
		</xsl:element>
		<xsl:element name="Event"><xsl:attribute name="flg">t_ScUfCount</xsl:attribute></xsl:element>
	</xsl:if>
	<xsl:element name="LoadEvent">
		<xsl:attribute name="path"><xsl:value-of select="@units"/></xsl:attribute>
	</xsl:element>
</xsl:element>

</xsl:template>

</xsl:stylesheet>
