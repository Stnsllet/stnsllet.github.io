<?xml version="1.0" encoding="Shift_JIS"?>
<xsl:stylesheet xmlns:xsl="http://www.w3.org/1999/XSL/Transform" version="1.0"  xmlns:spibre="http://geroha.ld.infoseek.co.jp/spibre/">
<xsl:output method="xml" version="1.0" encoding="Shift_JIS" indent="yes" />
<xsl:param name="_temp_shiftpos"/>
<xsl:param name="_temp_shift_f"/>
<xsl:param name="_temp_shift_r"/>
<msxsl:script xmlns:msxsl="urn:schemas-microsoft-com:xslt" language="JavaScript" implements-prefix="spibre">
  function sin(data){
   	return(Math.sin(Math.PI * data));
  }
  function cos(data){
   	return(Math.cos(Math.PI * data));
  }
</msxsl:script>

<xsl:template match="CallTrans">
	<xsl:variable name="shift_f" select="$_temp_shift_f"/>
	<xsl:variable name="shift_r" select="$_temp_shift_r"/>
	<xsl:variable name="x" select="substring-before($_temp_shiftpos,'/')"/>
	<xsl:variable name="y" select="substring-before(substring-after($_temp_shiftpos,'/'),'/')"/>
	<xsl:variable name="d" select="substring-after(substring-after($_temp_shiftpos,'/'),'/')"/>

	<xsl:variable name="nx" select="format-number($shift_f*spibre:sin($d) - $shift_r*spibre:cos($d) + $x, '0.##')"/>
	<xsl:variable name="ny" select="format-number(-$shift_f*spibre:cos($d) - $shift_r*spibre:sin($d) + $y, '0.##')"/>
	<xsl:element name="Event">
	<xsl:element name="Param">
		<xsl:attribute name="name">_temp_shiftpos</xsl:attribute>
		<xsl:attribute name="val"><xsl:value-of select="$nx"/>/<xsl:value-of select="$ny"/>/<xsl:value-of select="$d"/></xsl:attribute>
	</xsl:element>
	<xsl:element name="Param">
		<xsl:attribute name="name">_temp_shiftpos.x</xsl:attribute>
		<xsl:attribute name="val"><xsl:value-of select="$nx"/></xsl:attribute>
	</xsl:element>
	<xsl:element name="Param">
		<xsl:attribute name="name">_temp_shiftpos.y</xsl:attribute>
		<xsl:attribute name="val"><xsl:value-of select="$ny"/></xsl:attribute>
	</xsl:element>
	<xsl:element name="Param">
		<xsl:attribute name="name">_temp_shiftpos.d</xsl:attribute>
		<xsl:attribute name="val"><xsl:value-of select="$d"/></xsl:attribute>
	</xsl:element>
	<xsl:element name="Param">
		<xsl:attribute name="name">_temp_shiftpos.xy</xsl:attribute>
		<xsl:attribute name="val"><xsl:value-of select="$nx"/>/<xsl:value-of select="$ny"/></xsl:attribute>
	</xsl:element>
	</xsl:element>
</xsl:template>

</xsl:stylesheet>
