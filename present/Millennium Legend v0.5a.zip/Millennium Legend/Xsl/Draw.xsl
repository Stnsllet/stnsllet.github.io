<?xml version="1.0" encoding="Shift_JIS"?>
<xsl:stylesheet xmlns:xsl="http://www.w3.org/1999/XSL/Transform" version="1.0"  xmlns:spibre="http://geroha.ld.infoseek.co.jp/spibre/">
<xsl:output method="xml" version="1.0" encoding="Shift_JIS" indent="yes" />
<xsl:param name="_temp_sccol"/>
<xsl:param name="_temp_scx"/>
<xsl:param name="_temp_scy"/>
<xsl:param name="_temp_scw"/>
<xsl:param name="_temp_sch"/>
<xsl:param name="_temp_sctex"/>

<xsl:template match="CallTrans">
	<xsl:variable name="num" select="string(@num)"/>
	<xsl:variable name="base" select="string(@base)"/>
	<xsl:variable name="pars" select="string(@pars)"/>
	<xsl:variable name="col" select="$_temp_sccol"/>
	<xsl:variable name="tex" select="$_temp_sctex"/>
	<xsl:variable name="x" select="$_temp_scx"/>
	<xsl:variable name="y" select="$_temp_scy"/>
	<xsl:variable name="w" select="$_temp_scw"/>
	<xsl:variable name="h" select="$_temp_sch"/>
	<xsl:element name="Powered">
		<xsl:attribute name="x">0</xsl:attribute>
		<xsl:attribute name="y">0</xsl:attribute>
		<xsl:attribute name="w">800</xsl:attribute>
		<xsl:attribute name="h">600</xsl:attribute>
		<xsl:attribute name="col">0</xsl:attribute>
		<xsl:attribute name="life"><xsl:value-of select="@life"/></xsl:attribute>
		<xsl:element name="Tag">
			<xsl:attribute name="x"><xsl:value-of select="$x"/></xsl:attribute>
			<xsl:attribute name="y"><xsl:value-of select="$y"/></xsl:attribute>
			<xsl:attribute name="w"><xsl:value-of select="$w"/></xsl:attribute>
			<xsl:attribute name="h"><xsl:value-of select="$h"/></xsl:attribute>
			<xsl:attribute name="col"><xsl:value-of select="$col"/></xsl:attribute>
			<xsl:attribute name="msg"><xsl:value-of select="@msg"/></xsl:attribute>
			<xsl:attribute name="font"><xsl:value-of select="@font"/></xsl:attribute>
			<xsl:attribute name="tex"><xsl:value-of select="$tex"/></xsl:attribute>
		</xsl:element>
	</xsl:element>
</xsl:template>

</xsl:stylesheet>
