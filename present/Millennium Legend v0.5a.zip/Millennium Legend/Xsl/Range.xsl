<?xml version="1.0" encoding="Shift_JIS"?>
<xsl:stylesheet xmlns:xsl="http://www.w3.org/1999/XSL/Transform" version="1.0"  xmlns:sys="https://stnsllet.github.io/">
<xsl:output method="xml" version="1.0" encoding="Shift_JIS" indent="yes" />
<xsl:param name="_temp_range_name"/>
<xsl:param name="_temp_range_id"/>
<xsl:param name="_temp_range_taget"/>
<xsl:param name="_temp_range_pos"/>
<xsl:param name="_temp_range_count"/>
<xsl:param name="_temp_range_length"/>
<xsl:param name="_temp_range_ex"/>

<xsl:template match="CallTrans">
	<xsl:element name="List">
		<xsl:element name="Range">
			<xsl:attribute name="name"><xsl:value-of select="$_temp_range_name"/></xsl:attribute>
			<xsl:attribute name="id"><xsl:value-of select="$_temp_range_id"/></xsl:attribute>
			<xsl:attribute name="taget"><xsl:value-of select="$_temp_range_taget"/></xsl:attribute>
			<xsl:attribute name="pos"><xsl:value-of select="$_temp_range_pos"/></xsl:attribute>
			<xsl:attribute name="count"><xsl:value-of select="$_temp_range_count"/></xsl:attribute>
			<xsl:attribute name="length"><xsl:value-of select="$_temp_range_length"/></xsl:attribute>
			<xsl:element name="Param">
				<xsl:attribute name="name">_temp_sys_lastex</xsl:attribute>
				<xsl:attribute name="val"><xsl:value-of select="$_temp_range_ex"/></xsl:attribute>
			</xsl:element>
			<xsl:element name="Param">
				<xsl:attribute name="name">_temp_sys_lastrange</xsl:attribute>
				<xsl:attribute name="val"><xsl:value-of select="$_temp_range_name"/></xsl:attribute>
				<xsl:apply-templates/>
			</xsl:element>
		</xsl:element>
	</xsl:element>
</xsl:template>

<xsl:template match="*">
	<xsl:copy-of select="."/>
</xsl:template>

</xsl:stylesheet>
