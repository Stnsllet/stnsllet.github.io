<?xml version="1.0" encoding="Shift_JIS"?>
<xsl:stylesheet xmlns:xsl="http://www.w3.org/1999/XSL/Transform" version="1.0"  xmlns:spibre="http://geroha.ld.infoseek.co.jp/spibre/">
<xsl:output method="xml" version="1.0" encoding="Shift_JIS" indent="yes" />

<xsl:template match="CallTrans">
	<xsl:variable name="flg" select="@flg"/>
	<xsl:variable name="type" select="@type"/>

	<xsl:element name="Event">
		<xsl:if test="$type = 'save'">
			<xsl:element name="ChkFlg">
				<xsl:attribute name="on"><xsl:value-of select="$flg"/></xsl:attribute>

				<xsl:element name="Param">
					<xsl:attribute name="name">_temp_<xsl:value-of select="$flg"/></xsl:attribute>
					<xsl:attribute name="val">1</xsl:attribute>
				</xsl:element>
			</xsl:element>
		</xsl:if>
		<xsl:if test="$type = 'load'">
			<xsl:element name="Param">
				<xsl:attribute name="name">_temp_<xsl:value-of select="$flg"/></xsl:attribute>
				<xsl:attribute name="com">=</xsl:attribute>
				<xsl:attribute name="val">1</xsl:attribute>
				<xsl:element name="Event">
					<xsl:attribute name="flg"><xsl:value-of select="$flg"/></xsl:attribute>
				</xsl:element>
			</xsl:element>
		</xsl:if>

		<xsl:if test="$type = 'Psave'">
			<xsl:element name="Param">
				<xsl:attribute name="name">_temp_<xsl:value-of select="$flg"/></xsl:attribute>
				<xsl:attribute name="val">=<xsl:value-of select="$flg"/></xsl:attribute>
			</xsl:element>
		</xsl:if>
		<xsl:if test="$type = 'Pload'">
			<xsl:element name="Param">
				<xsl:attribute name="name"><xsl:value-of select="$flg"/></xsl:attribute>
				<xsl:attribute name="val">=_temp_<xsl:value-of select="$flg"/></xsl:attribute>
			</xsl:element>
		</xsl:if>

	</xsl:element>

</xsl:template>

</xsl:stylesheet>
