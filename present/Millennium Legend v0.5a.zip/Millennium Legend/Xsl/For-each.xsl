<?xml version="1.0" encoding="Shift_JIS"?>
<xsl:stylesheet xmlns:xsl="http://www.w3.org/1999/XSL/Transform" version="1.0"  xmlns:spibre="http://geroha.ld.infoseek.co.jp/spibre/">
<xsl:output method="xml" version="1.0" encoding="Shift_JIS" indent="yes" />

<xsl:template match="CallTrans">

	<xsl:variable name="sel" select="@sel"/>

	<xsl:element name="List">
		<xsl:for-each select="$sel">
			<xsl:element name="Param">
				<xsl:attribute name="name">_temp_msg</xsl:attribute>
				<xsl:attribute name="val"><xsl:value-of select="@str"/></xsl:attribute>
			</xsl:element>
			<xsl:element name="Msg">
				<xsl:attribute name="msg"><xsl:value-of select="$sel"/> is <xsl:value-of select="@str"/></xsl:attribute>
			</xsl:element>
			<xsl:apply-templates />
		</xsl:for-each>
	</xsl:element>
</xsl:template>

</xsl:stylesheet>
