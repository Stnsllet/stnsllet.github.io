<?xml version="1.0" encoding="Shift_JIS"?>
<xsl:stylesheet xmlns:xsl="http://www.w3.org/1999/XSL/Transform" version="1.0" xmlns:syscore="http://stnsllethouse.blog.fc2.com/">
<xsl:output method="xml" version="1.0" encoding="Shift_JIS" indent="yes" />

<xsl:param name="_monlev"/>
<xsl:param name="_temp_count"/>
<xsl:param name="_temp_leader"/>
<xsl:param name="_temp_uflev"/>
<xsl:param name="_temp_ufjob"/>
<xsl:param name="_temp_ufwep"/>
<xsl:param name="_temp_ufbody"/>
<xsl:param name="_temp_ufacs"/>
<xsl:param name="_temp_ufrev"/>

<xsl:template match="CallTrans">
	<xsl:element name="Paty">
		<xsl:if test="@brave"><xsl:attribute name="brave"><xsl:value-of select="@brave"/></xsl:attribute></xsl:if>
		<xsl:if test="@escape"><xsl:attribute name="escape"><xsl:value-of select="@escape"/></xsl:attribute></xsl:if>
		<xsl:attribute name="tactics"><xsl:value-of select="@tactics"/></xsl:attribute>
		<xsl:attribute name="army"><xsl:value-of select="@army"/></xsl:attribute>
		<xsl:attribute name="form"><xsl:value-of select="@form"/></xsl:attribute>
		<xsl:attribute name="parampos"><xsl:value-of select="@parampos"/></xsl:attribute>
		<xsl:attribute name="x"><xsl:value-of select="@x"/></xsl:attribute>
		<xsl:attribute name="y"><xsl:value-of select="@y"/></xsl:attribute>
		<xsl:attribute name="dir"><xsl:value-of select="@dir"/></xsl:attribute>
		<xsl:attribute name="user"><xsl:value-of select="@user"/></xsl:attribute>
		<xsl:if test="@no"><xsl:attribute name="no"><xsl:value-of select="@no"/></xsl:attribute></xsl:if>
		<xsl:if test="@money"><xsl:attribute name="money"><xsl:value-of select="@money"/></xsl:attribute></xsl:if>
		<xsl:for-each select="Member">
		<xsl:choose>
			<xsl:when test="*[1]">
				<xsl:copy-of select="."/>
			</xsl:when>
			<xsl:when test="position() &lt;= $_temp_count">
				<xsl:call-template name="member_sub">
					<xsl:with-param name="lev" select="syscore:getFixedLev(number(@lev), number($_monlev), number($_temp_uflev))"/>
					<xsl:with-param name="pason" select="@pason"/>
					<xsl:with-param name="job" select="@job"/>
					<xsl:with-param name="wep" select="@wep"/>
					<xsl:with-param name="body" select="@body"/>
					<xsl:with-param name="acs" select="@acs"/>
					<xsl:with-param name="lead" select="@lead"/>
					<xsl:with-param name="user" select="@user"/>
					<xsl:with-param name="inpaty" select="@inpaty"/>
					<xsl:with-param name="rev" select="@rev"/>
				</xsl:call-template>
			</xsl:when>
		</xsl:choose>	
		</xsl:for-each>
	</xsl:element>
</xsl:template>

<xsl:template name="member_sub">
	<xsl:param name="lev"/>
	<xsl:param name="pason"/>
	<xsl:param name="job"/>
	<xsl:param name="wep"/>
	<xsl:param name="body"/>
	<xsl:param name="acs"/>
	<xsl:param name="lead"/>
	<!-- <xsl:param name="rev"/> -->
	<xsl:variable name="name" select="syscore:choicePason2(string(@pason), string($_temp_leader), number(@lead))"/>
	<xsl:variable name="fixlev" select="syscore:getFixedLev(number(@lev), number($_monlev), number($_temp_uflev))"/>
	<xsl:variable name="rev" select="syscore:choiceRev2(number(@rev), $_temp_ufrev, number(@lead))"/>
	<xsl:element name="Member">
		<xsl:choose>
			<xsl:when test="@pason"><xsl:attribute name="pason"><xsl:value-of select="@pason"/></xsl:attribute></xsl:when>
			<xsl:when test="@lead='1'"><xsl:attribute name="pason">=_temp_leader</xsl:attribute></xsl:when>
			<xsl:when test="@id"><xsl:attribute name="pason">=_temp_temp<xsl:value-of select="@id"/>pason</xsl:attribute></xsl:when>
			<xsl:when test="not(@pason) and not(@lead='1')"><xsl:attribute name="pason">=_temp_temppason</xsl:attribute></xsl:when><xsl:when test="not(@pason) and not(@lead='1')"><xsl:attribute name="pason">=_temp_temppason</xsl:attribute></xsl:when>
		</xsl:choose>
		<xsl:if test="not(@user)">
		<xsl:choose>
			<xsl:when test="@lev"><xsl:attribute name="lev"><xsl:value-of select="@lev"/></xsl:attribute></xsl:when>
			<xsl:when test="@lead='1'"><xsl:attribute name="lev">=_temp_uflev</xsl:attribute></xsl:when>
			<xsl:when test="@id"><xsl:attribute name="lev">=_temp_temp<xsl:value-of select="@id"/>lev</xsl:attribute></xsl:when>
			<xsl:when test="not(@lev) or not(@lead='1')"><xsl:attribute name="lev">=_temp_templev</xsl:attribute></xsl:when>
		</xsl:choose>
		<xsl:choose>
			<xsl:when test="@job"><xsl:attribute name="job"><xsl:value-of select="@job"/></xsl:attribute></xsl:when>
			<xsl:when test="@lead='1'"><xsl:attribute name="job">=_temp_ufjob</xsl:attribute></xsl:when>
			<xsl:when test="@id"><xsl:attribute name="job">=_temp_temp<xsl:value-of select="@id"/>job</xsl:attribute></xsl:when>
			<xsl:when test="not(@job) and not(@lead='1')"><xsl:attribute name="job">=_temp_tempjob</xsl:attribute></xsl:when>
		</xsl:choose>
		<xsl:choose>
			<xsl:when test="@wep"><xsl:attribute name="wep"><xsl:value-of select="@wep"/></xsl:attribute></xsl:when>
			<xsl:when test="@lead='1'"><xsl:attribute name="wep">=_temp_ufwep</xsl:attribute></xsl:when>
			<xsl:when test="@id"><xsl:attribute name="wep">=_temp_temp<xsl:value-of select="@id"/>wep</xsl:attribute></xsl:when>
			<xsl:when test="not(@wep) and not(@lead='1')"><xsl:attribute name="wep">=_temp_tempwep</xsl:attribute></xsl:when>
		</xsl:choose>
		<xsl:choose>
			<xsl:when test="@body"><xsl:attribute name="body"><xsl:value-of select="@body"/></xsl:attribute></xsl:when>
			<xsl:when test="@lead='1'"><xsl:attribute name="body">=_temp_ufbody</xsl:attribute></xsl:when>
			<xsl:when test="@id"><xsl:attribute name="body">=_temp_temp<xsl:value-of select="@id"/>body</xsl:attribute></xsl:when>
			<xsl:when test="not(@body) and not(@lead='1')"><xsl:attribute name="body">=_temp_tempbody</xsl:attribute></xsl:when>
		</xsl:choose>		
		<xsl:choose>
			<xsl:when test="@acs"><xsl:attribute name="acs"><xsl:value-of select="@acs"/></xsl:attribute></xsl:when>
			<xsl:when test="@lead='1'"><xsl:attribute name="acs">=_temp_ufacs</xsl:attribute></xsl:when>
			<xsl:when test="@id"><xsl:attribute name="acs">=_temp_temp<xsl:value-of select="@id"/>acs</xsl:attribute></xsl:when>
			<xsl:when test="not(@acs) and not(@lead='1')"><xsl:attribute name="acs">=_temp_tempacs</xsl:attribute></xsl:when>
		</xsl:choose>
		<xsl:if test="@inpaty"><xsl:attribute name="inpaty"><xsl:value-of select="@inpaty"/></xsl:attribute></xsl:if>
		</xsl:if>
		<xsl:choose>
		<xsl:when test="$name != 'default' or $rev != 1.0">
			<xsl:element name="Status">
			<xsl:for-each select="document('../Data/PreCalcStatus.xml')/PreCalcStatus/Status[@name=$name]">
				<xsl:attribute name="hp"><xsl:value-of select="syscore:calcParam(number($lev), number(@ghp), number(@php), number($rev)) * (number($rev) * 0.8)"/></xsl:attribute>
				<xsl:attribute name="mp"><xsl:value-of select="syscore:calcParam(number($lev), number(@gmp), number(@pmp), number($rev)) * (number($rev) * 0.6)"/></xsl:attribute>
				<xsl:attribute name="atc"><xsl:value-of select="syscore:calcParam(number($lev), number(@gatc), number(@patc), number($rev))"/></xsl:attribute>
				<xsl:attribute name="def"><xsl:value-of select="syscore:calcParam(number($lev), number(@gdef), number(@pdef), number($rev))"/></xsl:attribute>
				<xsl:attribute name="mag"><xsl:value-of select="syscore:calcParam(number($lev), number(@gmag), number(@pmag), number($rev))"/></xsl:attribute>
				<xsl:attribute name="spd"><xsl:value-of select="syscore:calcParam(number($lev), number(@gspd), number(@pspd), number($rev))"/></xsl:attribute>
				</xsl:for-each>
			</xsl:element>
		</xsl:when>
		</xsl:choose>
	</xsl:element>
</xsl:template>

<!-- <xsl:template match="Member">
	<xsl:variable name="name" select="syscore:choicePason(string($_temp_leader), string(@pason))"/>
	<xsl:variable name="job" select="$_temp_ufjob"/>
	<xsl:variable name="wep" select="$_temp_ufwep"/>
	<xsl:variable name="body" select="$_temp_ufbody"/>
	<xsl:variable name="acs" select="$_temp_ufacs"/>
	<xsl:variable name="fixlev" select="syscore:getFixedLev(number(@lev), number($_monlev), number($_temp_uflev))"/>
	<xsl:variable name="rev" select="@rev"/>
	<xsl:element name="Member">
		<xsl:choose>
			<xsl:when test="@pason"><xsl:attribute name="pason"><xsl:value-of select="@pason"/></xsl:attribute></xsl:when>
			<xsl:when test="@lead='1'"><xsl:attribute name="pason"><xsl:value-of select="$name"/></xsl:attribute></xsl:when>
			<xsl:when test="@id"><xsl:attribute name="pason">=_temp_temp<xsl:value-of select="@id"/>pason</xsl:attribute></xsl:when>
			<xsl:when test="not(@pason) and not(@lead='1')"><xsl:attribute name="pason">=_temp_temppason</xsl:attribute></xsl:when><xsl:when test="not(@pason) and not(@lead='1')"><xsl:attribute name="pason">=_temp_temppason</xsl:attribute></xsl:when>
		</xsl:choose>
		<xsl:if test="not(@user)">
		<xsl:choose>
			<xsl:when test="@lev"><xsl:attribute name="lev"><xsl:value-of select="@lev"/></xsl:attribute></xsl:when>
			<xsl:when test="@lead='1'"><xsl:attribute name="lev"><xsl:value-of select="$_temp_uflev"/></xsl:attribute></xsl:when>
			<xsl:when test="@id"><xsl:attribute name="lev">=_temp_temp<xsl:value-of select="@id"/>lev</xsl:attribute></xsl:when>
			<xsl:when test="not(@lev) or not(@lead='1')"><xsl:attribute name="lev">=_temp_templev</xsl:attribute></xsl:when>
		</xsl:choose>
		<xsl:choose>
			<xsl:when test="@job"><xsl:attribute name="job"><xsl:value-of select="@job"/></xsl:attribute></xsl:when>
			<xsl:when test="@lead='1'"><xsl:attribute name="job"><xsl:value-of select="$job"/></xsl:attribute></xsl:when>
			<xsl:when test="@id"><xsl:attribute name="job">=_temp_temp<xsl:value-of select="@id"/>job</xsl:attribute></xsl:when>
			<xsl:when test="not(@job) and not(@lead='1')"><xsl:attribute name="job">=_temp_tempjob</xsl:attribute></xsl:when>
		</xsl:choose>
		<xsl:choose>
			<xsl:when test="@wep"><xsl:attribute name="wep"><xsl:value-of select="@wep"/></xsl:attribute></xsl:when>
			<xsl:when test="@lead='1'"><xsl:attribute name="wep"><xsl:value-of select="$wep"/></xsl:attribute></xsl:when>
			<xsl:when test="@id"><xsl:attribute name="wep">=_temp_temp<xsl:value-of select="@id"/>wep</xsl:attribute></xsl:when>
			<xsl:when test="not(@wep) and not(@lead='1')"><xsl:attribute name="wep">=_temp_tempwep</xsl:attribute></xsl:when>
		</xsl:choose>
		<xsl:choose>
			<xsl:when test="@body"><xsl:attribute name="body"><xsl:value-of select="@body"/></xsl:attribute></xsl:when>
			<xsl:when test="@lead='1'"><xsl:attribute name="body"><xsl:value-of select="$body"/></xsl:attribute></xsl:when>
			<xsl:when test="@id"><xsl:attribute name="body">=_temp_temp<xsl:value-of select="@id"/>body</xsl:attribute></xsl:when>
			<xsl:when test="not(@body) and not(@lead='1')"><xsl:attribute name="body">=_temp_tempbody</xsl:attribute></xsl:when>
		</xsl:choose>		
		<xsl:choose>
			<xsl:when test="@acs"><xsl:attribute name="acs"><xsl:value-of select="@acs"/></xsl:attribute></xsl:when>
			<xsl:when test="@lead='1'"><xsl:attribute name="acs"><xsl:value-of select="$acs"/></xsl:attribute></xsl:when>
			<xsl:when test="@id"><xsl:attribute name="acs">=_temp_temp<xsl:value-of select="@id"/>acs</xsl:attribute></xsl:when>
			<xsl:when test="not(@acs) and not(@lead='1')"><xsl:attribute name="acs">=_temp_tempacs</xsl:attribute></xsl:when>
		</xsl:choose>
		<xsl:if test="@inpaty"><xsl:attribute name="inpaty"><xsl:value-of select="@inpaty"/></xsl:attribute></xsl:if>
		</xsl:if>
		<xsl:if test="not(@rev)">
			<xsl:apply-templates />
		</xsl:if>
		<xsl:if test="$rev">
			<xsl:element name="Status">
			<xsl:attribute name="hp">10</xsl:attribute>
			<xsl:for-each select="document('../Data/PreCalcStatus.xml')/PreCalcStatus/Status[@name=$name]">
				<xsl:attribute name="hp"><xsl:value-of select="syscore:calcParam(number($fixlev), number(@ghp), number(@php), number($rev))"/></xsl:attribute>
				<xsl:attribute name="mp"><xsl:value-of select="syscore:calcParam(number($fixlev), number(@gmp), number(@pmp), number($rev))"/></xsl:attribute>
				<xsl:attribute name="atc"><xsl:value-of select="syscore:calcParam(number($fixlev), number(@gatc), number(@patc), number($rev))"/></xsl:attribute>
				<xsl:attribute name="def"><xsl:value-of select="syscore:calcParam(number($fixlev), number(@gdef), number(@pdef), number($rev))"/></xsl:attribute>
				<xsl:attribute name="mag"><xsl:value-of select="syscore:calcParam(number($fixlev), number(@gmag), number(@pmag), number($rev))"/></xsl:attribute>
				<xsl:attribute name="spd"><xsl:value-of select="syscore:calcParam(number($fixlev), number(@gspd), number(@pspd), number($rev))"/></xsl:attribute>
				</xsl:for-each>
			</xsl:element>
		</xsl:if>
	</xsl:element>
</xsl:template> -->

<xsl:template match="*">
	<xsl:copy-of select="."/>
</xsl:template>

<xsl:include href="../Xsl/Script.dll" />

</xsl:stylesheet>
