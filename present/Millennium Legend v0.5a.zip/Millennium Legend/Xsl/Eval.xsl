<?xml version="1.0" encoding="Shift_JIS"?>
<xsl:stylesheet xmlns:xsl="http://www.w3.org/1999/XSL/Transform" version="1.0" xmlns:spibre="a">
<xsl:output method="xml" version="1.0" encoding="Shift_JIS" indent="yes" />

<xsl:param name="_temp_jseval"/>

<xsl:param name="_temp_jsarg0"/>
<xsl:param name="_temp_jsarg1"/>
<xsl:param name="_temp_jsarg2"/>

<msxsl:script xmlns:msxsl="urn:schemas-microsoft-com:xslt" language="JScript" implements-prefix="spibre">
<![CDATA[
function cardinal(num,base,change){
	var n=String(num); 
	var str = parseInt(n, base).toString(change);
   	return(str);
}

function splitPos(pos){
	var obj = new Object();
	var spos = pos.split("/");
	obj.X = spos[0];
	obj.Y = spos[1];
	obj.D = spos[2];
	return obj;
}

function evaling(str,arg0,arg1,arg2){
var args = new Array(arg0,arg1,arg2);

var r;
try {
    eval("r="+str+";");
}
catch(exception){
    return exception.message;
}

return r;
}

]]>
</msxsl:script>

<xsl:template match="CallTrans">
	<xsl:variable name="eval" select="string($_temp_jseval)"/>
	<xsl:variable name="arg0" select="$_temp_jsarg0"/>
	<xsl:variable name="arg1" select="$_temp_jsarg1"/>
	<xsl:variable name="arg2" select="$_temp_jsarg2"/>

	<xsl:element name="Event">
		<xsl:element name="Param">
			<xsl:attribute name="name"><xsl:value-of select="@name"/></xsl:attribute>
			<xsl:attribute name="val"><xsl:value-of select="spibre:evaling($eval,$arg0,$arg1,$arg2)"/></xsl:attribute>
		</xsl:element>
	</xsl:element>
</xsl:template>

</xsl:stylesheet>