<?xml version="1.0" encoding="Shift_JIS"?>
<xsl:stylesheet xmlns:xsl="http://www.w3.org/1999/XSL/Transform" version="1.0"  xmlns:spibre="http://geroha.ld.infoseek.co.jp/spibre/">
<xsl:output method="xml" version="1.0" encoding="Shift_JIS" indent="yes" />
<xsl:param name="_temp_gauge1"/>
<xsl:param name="_temp_gauge2"/>
<xsl:param name="_temp_gauge3"/>
<xsl:param name="_temp_gauge4"/>

<xsl:template match="CallTrans">
	<xsl:variable name="gauge1" select="$_temp_gauge1"/>
	<xsl:variable name="gauge2" select="$_temp_gauge2"/>
	<xsl:variable name="gauge3" select="$_temp_gauge3"/>
	<xsl:variable name="gauge4" select="$_temp_gauge3"/>
	<xsl:variable name="type" select="@type"/>
	<xsl:variable name="num" select="@num"/>

	<xsl:variable name="param" select="@param"/>
	<xsl:variable name="name" select="@name"/>
	<xsl:variable name="id" select="@id"/>
	<xsl:variable name="pos" select="@pos"/>
	<xsl:variable name="len" select="@len"/>
	<xsl:variable name="gauge" select="@gauge"/>

<xsl:element name="Event">
	<xsl:if test="$type = 'Gauge'">
		<xsl:element name="Powered">
			<xsl:attribute name="x">100</xsl:attribute>
			<xsl:attribute name="y">30</xsl:attribute>
			<xsl:attribute name="w">100</xsl:attribute>
			<xsl:attribute name="h">150</xsl:attribute>
			<xsl:attribute name="life">1900</xsl:attribute>
			<xsl:attribute name="col">0</xsl:attribute>
			<xsl:element name="Tag">
				<xsl:attribute name="y">20</xsl:attribute>
				<xsl:attribute name="font">wnd_tag</xsl:attribute>
				<xsl:attribute name="msg">�`</xsl:attribute>
			</xsl:element>
			<xsl:element name="Tag">
				<xsl:attribute name="y">30</xsl:attribute>
				<xsl:attribute name="w">100</xsl:attribute>
				<xsl:attribute name="h">10</xsl:attribute>
				<xsl:attribute name="tex">Tex/System/Gauge_R.png</xsl:attribute>
			</xsl:element>
			<xsl:element name="Tag">
				<xsl:attribute name="y">30</xsl:attribute>
				<xsl:attribute name="w"><xsl:value-of select="$gauge1"/></xsl:attribute>
				<xsl:attribute name="h">10</xsl:attribute>
				<xsl:attribute name="tex">Tex/System/Gauge_G.png</xsl:attribute>
			</xsl:element>
			<xsl:if test="$num &gt; '2'">
			<xsl:element name="Tag">
				<xsl:attribute name="y">40</xsl:attribute>
				<xsl:attribute name="font">wnd_tag</xsl:attribute>
				<xsl:attribute name="msg">�a</xsl:attribute>
			</xsl:element>
			<xsl:element name="Tag">
				<xsl:attribute name="y">50</xsl:attribute>
				<xsl:attribute name="w">100</xsl:attribute>
				<xsl:attribute name="h">10</xsl:attribute>
				<xsl:attribute name="tex">Tex/System/Gauge_R.png</xsl:attribute>
			</xsl:element>
			<xsl:element name="Tag">
				<xsl:attribute name="y">50</xsl:attribute>
				<xsl:attribute name="w"><xsl:value-of select="$gauge2"/></xsl:attribute>
				<xsl:attribute name="h">10</xsl:attribute>
				<xsl:attribute name="tex">Tex/System/Gauge_G.png</xsl:attribute>
			</xsl:element>
			</xsl:if>
			<xsl:if test="$num &gt;= '3'">
			<xsl:element name="Tag">
				<xsl:attribute name="y">60</xsl:attribute>
				<xsl:attribute name="font">wnd_tag</xsl:attribute>
				<xsl:attribute name="msg">�b</xsl:attribute>
			</xsl:element>
			<xsl:element name="Tag">
				<xsl:attribute name="y">70</xsl:attribute>
				<xsl:attribute name="w">100</xsl:attribute>
				<xsl:attribute name="h">10</xsl:attribute>
				<xsl:attribute name="tex">Tex/System/Gauge_R.png</xsl:attribute>
			</xsl:element>
			<xsl:element name="Tag">
				<xsl:attribute name="y">70</xsl:attribute>
				<xsl:attribute name="w"><xsl:value-of select="$gauge3"/></xsl:attribute>
				<xsl:attribute name="h">10</xsl:attribute>
				<xsl:attribute name="tex">Tex/System/Gauge_G.png</xsl:attribute>
			</xsl:element>
			</xsl:if>
			<xsl:if test="$num &gt;= '4'">
			<xsl:element name="Tag">
				<xsl:attribute name="y">80</xsl:attribute>
				<xsl:attribute name="font">wnd_tag</xsl:attribute>
				<xsl:attribute name="msg">�c</xsl:attribute>
			</xsl:element>
			<xsl:element name="Tag">
				<xsl:attribute name="y">90</xsl:attribute>
				<xsl:attribute name="w">100</xsl:attribute>
				<xsl:attribute name="h">10</xsl:attribute>
				<xsl:attribute name="tex">Tex/System/Gauge_R.png</xsl:attribute>
			</xsl:element>
			<xsl:element name="Tag">
				<xsl:attribute name="y">90</xsl:attribute>
				<xsl:attribute name="w"><xsl:value-of select="$gauge4"/></xsl:attribute>
				<xsl:attribute name="h">10</xsl:attribute>
				<xsl:attribute name="tex">Tex/System/Gauge_G.png</xsl:attribute>
			</xsl:element>
			</xsl:if>
		</xsl:element>
	</xsl:if>
	<xsl:if test="$type = 'Site'">
		<xsl:element name="Range">
			<xsl:attribute name="name"><xsl:value-of select="$name"/></xsl:attribute>
			<xsl:attribute name="pos"><xsl:value-of select="$pos"/></xsl:attribute>
			<xsl:attribute name="length"><xsl:value-of select="$len"/></xsl:attribute>
			<xsl:element name="Param">
				<xsl:attribute name="name">_temp_dieflg</xsl:attribute>
				<xsl:attribute name="val">die_</xsl:attribute>
			</xsl:element>
			<xsl:element name="Param">
				<xsl:attribute name="name">_temp_dieflg</xsl:attribute>
				<xsl:attribute name="com">+</xsl:attribute>
				<xsl:attribute name="val"><xsl:value-of select="$name"/></xsl:attribute>
			</xsl:element>
			<xsl:element name="ChkFlg">
				<xsl:attribute name="off">=_temp_dieflg</xsl:attribute>
			<xsl:element name="Param">
				<xsl:attribute name="name">_temp_tcount</xsl:attribute>
				<xsl:attribute name="val">=_temp_Gcount</xsl:attribute>
			</xsl:element>
			<xsl:element name="Param">
				<xsl:attribute name="name">_temp_tcount</xsl:attribute>
				<xsl:attribute name="com">-</xsl:attribute>
				<xsl:attribute name="val">1</xsl:attribute>
			</xsl:element>
			<xsl:element name="Param">
				<xsl:attribute name="name">_temp_Ncount<xsl:value-of select="$gauge"/></xsl:attribute>
				<xsl:attribute name="com">=</xsl:attribute>
				<xsl:attribute name="val">=_temp_tcount</xsl:attribute>
				<xsl:element name="Param">
					<xsl:attribute name="name">_temp_gauge<xsl:value-of select="$gauge"/></xsl:attribute>
					<xsl:attribute name="com">ld</xsl:attribute>
					<xsl:attribute name="val">100</xsl:attribute>
					<xsl:element name="Param">
						<xsl:attribute name="name">_temp_gauge<xsl:value-of select="$gauge"/></xsl:attribute>
						<xsl:attribute name="com">+</xsl:attribute>
						<xsl:attribute name="val">2</xsl:attribute>
					</xsl:element>
				</xsl:element>
				<xsl:element name="Param">
					<xsl:attribute name="name">_temp_Ncount<xsl:value-of select="$gauge"/></xsl:attribute>
					<xsl:attribute name="com">+</xsl:attribute>
					<xsl:attribute name="val">1</xsl:attribute>
				</xsl:element>
			</xsl:element>
			</xsl:element>
		</xsl:element>
	</xsl:if>

	<xsl:if test="$type = 'Site2'">

		<xsl:element name="Range">
			<xsl:attribute name="name"><xsl:value-of select="@name"/></xsl:attribute>
			<xsl:attribute name="pos">1200/2580</xsl:attribute>
			<xsl:attribute name="length">250</xsl:attribute>
			<xsl:apply-templates/>
		</xsl:element>
	</xsl:if>


	<xsl:if test="$type = 'Respawn'">
		<xsl:element name="State">
			<xsl:attribute name="name">=<xsl:value-of select="$param"/>.name</xsl:attribute>
			<xsl:attribute name="act">dead</xsl:attribute>
			<xsl:element name="Param">
				<xsl:attribute name="name">_temp_rescount</xsl:attribute>
				<xsl:attribute name="com">+</xsl:attribute>
				<xsl:attribute name="val">1</xsl:attribute>
			</xsl:element>
			<xsl:element name="Event">
				<xsl:attribute name="flg"><xsl:value-of select="$param"/>.flg</xsl:attribute>
				<xsl:element name="Param">
					<xsl:attribute name="name">_temp_dieflg</xsl:attribute>
					<xsl:attribute name="val">die_</xsl:attribute>
				</xsl:element>
				<xsl:element name="Param">
					<xsl:attribute name="name">_temp_dieflg</xsl:attribute>
					<xsl:attribute name="com">+</xsl:attribute>
					<xsl:attribute name="val">=<xsl:value-of select="$param"/>.name</xsl:attribute>
				</xsl:element>
				<xsl:element name="Event">
					<xsl:attribute name="flg">=_temp_dieflg</xsl:attribute>
				</xsl:element>
				<xsl:element name="Timer">
					<xsl:attribute name="time">=_temp_cooltime</xsl:attribute>

					<xsl:element name="Event">
						<xsl:attribute name="unflg"><xsl:value-of select="$param"/>.flg</xsl:attribute>
						<xsl:element name="Bat">
							<xsl:attribute name="name">=<xsl:value-of select="$param"/>.name</xsl:attribute>
							<xsl:attribute name="escape">paty</xsl:attribute>
						</xsl:element>
						<xsl:element name="Param">
							<xsl:attribute name="name">_temp_dieflg</xsl:attribute>
							<xsl:attribute name="val">die_</xsl:attribute>
						</xsl:element>
						<xsl:element name="Param">
							<xsl:attribute name="name">_temp_dieflg</xsl:attribute>
							<xsl:attribute name="com">+</xsl:attribute>
							<xsl:attribute name="val">=<xsl:value-of select="$param"/>.name</xsl:attribute>
						</xsl:element>
						<xsl:element name="Event">
							<xsl:attribute name="unflg">=_temp_dieflg</xsl:attribute>
						</xsl:element>
						<xsl:element name="Paty">
							<xsl:attribute name="army">user</xsl:attribute>
							<xsl:attribute name="no">=<xsl:value-of select="$param"/></xsl:attribute>
							<xsl:attribute name="brave">50</xsl:attribute>
							<xsl:attribute name="parampos">=<xsl:value-of select="$param"/>.pos</xsl:attribute>
						</xsl:element>
						<xsl:element name="CallTrans">
							<xsl:attribute name="param"><xsl:value-of select="$param"/></xsl:attribute>
							<xsl:attribute name="type">Respawn</xsl:attribute>
							<xsl:attribute name="path">Xsl/Conquest.xsl</xsl:attribute>
						</xsl:element>
					</xsl:element>
				</xsl:element>
			</xsl:element>
		</xsl:element>
	</xsl:if>
</xsl:element>

</xsl:template>

</xsl:stylesheet>
