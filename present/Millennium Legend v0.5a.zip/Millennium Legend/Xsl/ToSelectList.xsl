<?xml version="1.0" encoding="Shift_JIS"?>
<xsl:stylesheet xmlns:xsl="http://www.w3.org/1999/XSL/Transform" version="1.0"  xmlns:spibre="http://geraha.ld.infoseek.co.jp/spibre/">
<xsl:output method="xml" version="1.0" encoding="Shift_JIS" indent="yes" />

<xsl:template match="CallTrans">
	<xsl:element name="Msg">
		<xsl:attribute name="msg">�����I��</xsl:attribute>
		<xsl:for-each select="Node">
			<xsl:if test="@name">
			<xsl:element name="Com">
				<xsl:attribute name="msg">�E<xsl:value-of select="@name"/>����</xsl:attribute>
				<xsl:element name="Param">
					<xsl:attribute name="name">_temp_paty</xsl:attribute>
					<xsl:attribute name="val"><xsl:value-of select="position()-1"/></xsl:attribute>
				</xsl:element>
			</xsl:element>
			</xsl:if>
		</xsl:for-each>
	</xsl:element>
</xsl:template>

</xsl:stylesheet>
