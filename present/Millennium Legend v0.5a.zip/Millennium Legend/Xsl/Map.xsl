<?xml version="1.0" encoding="Shift_JIS"?>
<xsl:stylesheet xmlns:xsl="http://www.w3.org/1999/XSL/Transform" version="1.0"  xmlns:spibre="http://geroha.ld.infoseek.co.jp/spibre/">
<xsl:output method="xml" version="1.0" encoding="Shift_JIS" indent="yes" />

<xsl:param name="_temp_searchkey"/>
<xsl:param name="_temp_searchpath"/>

<xsl:template match="CallTrans">

	<xsl:variable name="param" select="@param"/>
	<xsl:variable name="key" select="$_temp_searchkey"/>
	<xsl:variable name="map" select="$_temp_searchpath"/>

	<xsl:element name="List">
	<xsl:for-each select="document(concat('../',$_temp_searchpath))/MapList/Map[@key=$_temp_searchkey]">
		<xsl:element name="Param">
			<xsl:attribute name="name"><xsl:value-of select="$param"/></xsl:attribute>
			<xsl:attribute name="val"><xsl:value-of select="@val"/></xsl:attribute>
		</xsl:element>
		<xsl:element name="Param">
			<xsl:attribute name="name"><xsl:value-of select="$param"/>.2</xsl:attribute>
			<xsl:attribute name="val"><xsl:value-of select="@val2"/></xsl:attribute>
		</xsl:element>
	</xsl:for-each>
	<xsl:for-each select="document(concat('../',$_temp_searchpath))/MapList/Map[@val=$_temp_searchkey]|document(concat('../',$_temp_searchpath))/MapList/Map[@val2=$_temp_searchkey]">
		<xsl:element name="Choice">
		<xsl:element name="Param">
			<xsl:attribute name="name"><xsl:value-of select="$param"/></xsl:attribute>
			<xsl:attribute name="com">=</xsl:attribute>
			<xsl:attribute name="val">0</xsl:attribute>
			<xsl:element name="Param">
				<xsl:attribute name="name"><xsl:value-of select="$param"/></xsl:attribute>
				<xsl:attribute name="val"><xsl:value-of select="@key"/></xsl:attribute>
			</xsl:element>
		</xsl:element>

		<xsl:element name="Param">
			<xsl:attribute name="name"><xsl:value-of select="$param"/></xsl:attribute>
			<xsl:attribute name="com">+</xsl:attribute>
			<xsl:attribute name="val">/<xsl:value-of select="@key"/></xsl:attribute>
		</xsl:element>
		</xsl:element>
	</xsl:for-each>
	</xsl:element>
</xsl:template>

</xsl:stylesheet>
