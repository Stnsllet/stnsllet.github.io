<?xml version="1.0" encoding="Shift_JIS"?>
<xsl:stylesheet xmlns:xsl="http://www.w3.org/1999/XSL/Transform" version="1.0"  xmlns:spibre="http://geroha.ld.infoseek.co.jp/spibre/">
<xsl:output method="xml" version="1.0" encoding="Shift_JIS" indent="yes" />

<xsl:param name="_temp_data"/>

<xsl:template match="CallTrans">
	<xsl:variable name="SkillDef" select="document('../Data/Skill.xml')/SkillDefine"/>
	<xsl:variable name="search" select="$_temp_data"/>
	<xsl:element name="List">
	<xsl:for-each select="$SkillDef/Skill[@name=$_temp_data]">
		<xsl:element name="Msg">
			<xsl:attribute name="msg">
				<xsl:value-of select="@name"/>�F<xsl:value-of select="@str"/>&#xa;
���x���F�p���[�F�͈́F��
				<xsl:for-each select="./Level">
				�@�@<xsl:value-of select="@lev"/>�@ �F�@<xsl:value-of select="@pow"/>�@ �F�@<xsl:value-of select="@range"/>�F<xsl:value-of select="@count"/>
				</xsl:for-each>
			</xsl:attribute>
		</xsl:element>
	</xsl:for-each>

		<xsl:element name="Window">
			<xsl:attribute name="x">0</xsl:attribute>
			<xsl:attribute name="y">0</xsl:attribute>
			<xsl:attribute name="w">800</xsl:attribute>
			<xsl:attribute name="h">600</xsl:attribute>
			<xsl:attribute name="life">1900</xsl:attribute>
			<xsl:attribute name="col">0</xsl:attribute>
			<xsl:attribute name="name">dataskill</xsl:attribute>
	<xsl:for-each select="$SkillDef/Skill">
			<xsl:element name="Plane">
				<xsl:attribute name="x"><xsl:value-of select="floor((position()-1) div 30) mod 30 *100 + 4"/></xsl:attribute>
				<xsl:attribute name="y"><xsl:value-of select="(position()-1) mod 30 *20"/></xsl:attribute>
				<xsl:attribute name="name"><xsl:value-of select="@name"/></xsl:attribute>
				<xsl:attribute name="event">Round - �R�s�[.xml</xsl:attribute>
				<xsl:attribute name="com">param/rnd/_temp_data/<xsl:value-of select="@name"/></xsl:attribute>
			</xsl:element>
	</xsl:for-each>
		</xsl:element>
	</xsl:element>
</xsl:template>

</xsl:stylesheet>
