<?xml version="1.0" encoding="Shift_JIS"?>
<xsl:stylesheet xmlns:xsl="http://www.w3.org/1999/XSL/Transform" version="1.0" xmlns:spibre="a">
<xsl:output method="xml" version="1.0" encoding="Shift_JIS" indent="yes" />

<xsl:param name="_temp_timeCtrans"/>

<xsl:template match="CallTrans">
	<xsl:variable name="params" select="@params"/>
	<xsl:variable name="h" select="floor($_temp_timeCtrans div 3600000)"/>
	<xsl:variable name="m" select="floor($_temp_timeCtrans div 60000) - ($h*60)"/>
	<xsl:variable name="s" select="floor($_temp_timeCtrans div 1000) - ($h*3600) - ($m*60)"/>
	<xsl:variable name="c" select="floor((floor($_temp_timeCtrans div 1) - ($h*3600000) - ($m*60000) - ($s*1000)) div 10)"/>
	<xsl:variable name="com" select="@com"/>

	<xsl:variable name="dech" select="substring-before($_temp_timeCtrans,':')"/>
	<xsl:variable name="decm" select="substring-before(substring-after($_temp_timeCtrans,':'),':')"/>
	<xsl:variable name="decs" select="substring-before(substring-after(substring-after($_temp_timeCtrans,':'),':'),'.')"/>
	<xsl:variable name="decc" select="substring-after(substring-after($_temp_timeCtrans,':'),'.')"/>

	<xsl:variable name="decrh" select="floor($dech * 3600000)"/>
	<xsl:variable name="decrm" select="floor($decm * 60000)"/>
	<xsl:variable name="decrs" select="floor($decs * 1000)"/>
	<xsl:variable name="decrc" select="floor($decc * 10)"/>

	<xsl:variable name="sdecm" select="substring-before($_temp_timeCtrans,':')"/>
	<xsl:variable name="sdecs" select="substring-before(substring-after($_temp_timeCtrans,':'),'.')"/>
	<xsl:variable name="sdecc" select="substring-after(substring-after($_temp_timeCtrans,':'),'.')"/>

	<xsl:variable name="sdecrm" select="floor($sdecm * 60000)"/>
	<xsl:variable name="sdecrs" select="floor($sdecs * 1000)"/>
	<xsl:variable name="sdecrc" select="floor($sdecc * 10)"/>



	<xsl:element name="Event">

  		<xsl:if test="@type = 'format'">
  		<xsl:choose>
        		<xsl:when test="$com = 'speed'">
				<xsl:element name="Param">
					<xsl:attribute name="name"><xsl:value-of select="@param"/></xsl:attribute>
					<xsl:attribute name="val"><xsl:value-of select="format-number($m,'00')"/>:<xsl:value-of select="format-number($s,'00')"/>.<xsl:value-of select="format-number($c,'00')"/></xsl:attribute>
				</xsl:element>
      	  		</xsl:when>
        		<xsl:when test="$com = 'short'">
				<xsl:element name="Param">
					<xsl:attribute name="name"><xsl:value-of select="@param"/></xsl:attribute>
					<xsl:attribute name="val"><xsl:value-of select="format-number($m,'00')"/>:<xsl:value-of select="format-number($s,'00')"/></xsl:attribute>
				</xsl:element>
      	  		</xsl:when>
        		<xsl:when test="$com = 'time'">
				<xsl:element name="Param">
					<xsl:attribute name="name"><xsl:value-of select="@param"/></xsl:attribute>
					<xsl:attribute name="val"><xsl:value-of select="format-number($h,'00')"/>:<xsl:value-of select="format-number($m,'00')"/>:<xsl:value-of select="format-number($s,'00')"/></xsl:attribute>
				</xsl:element>
      	  		</xsl:when>
        		<xsl:when test="$com = 'long'">
				<xsl:element name="Param">
					<xsl:attribute name="name"><xsl:value-of select="@param"/></xsl:attribute>
					<xsl:attribute name="val"><xsl:value-of select="format-number($h,'000')"/>:<xsl:value-of select="format-number($m,'00')"/>:<xsl:value-of select="format-number($s,'00')"/></xsl:attribute>
				</xsl:element>
      	  		</xsl:when>
        		<xsl:when test="$com = 'none'">
				<xsl:element name="Param">
					<xsl:attribute name="name"><xsl:value-of select="@param"/></xsl:attribute>
					<xsl:attribute name="val">=<xsl:value-of select="@param"/></xsl:attribute>
				</xsl:element>
      	  		</xsl:when>
        		<xsl:when test="$com = 'all'">
				<xsl:element name="Param">
					<xsl:attribute name="name"><xsl:value-of select="@param"/></xsl:attribute>
					<xsl:attribute name="val"><xsl:value-of select="format-number($h,'00')"/>:<xsl:value-of select="format-number($m,'00')"/>:<xsl:value-of select="format-number($s,'00')"/>.<xsl:value-of select="format-number($c,'00')"/></xsl:attribute>
				</xsl:element>
      	  		</xsl:when>
  		</xsl:choose>
		</xsl:if>
 		<xsl:if test="@type = 'decode'">
			<xsl:element name="Param">
				<xsl:attribute name="name"><xsl:value-of select="@param"/></xsl:attribute>
				<xsl:attribute name="val">0</xsl:attribute>
			</xsl:element>
  		<xsl:choose>
        		<xsl:when test="@x = 'all'">

				<xsl:element name="Param">
					<xsl:attribute name="name"><xsl:value-of select="@param"/></xsl:attribute>
					<xsl:attribute name="com">+</xsl:attribute>
					<xsl:attribute name="val"><xsl:value-of select="$decrh"/></xsl:attribute>
				</xsl:element>
				<xsl:element name="Param">
					<xsl:attribute name="name"><xsl:value-of select="@param"/></xsl:attribute>
					<xsl:attribute name="com">+</xsl:attribute>
					<xsl:attribute name="val"><xsl:value-of select="$decrm"/></xsl:attribute>
				</xsl:element>
				<xsl:element name="Param">
					<xsl:attribute name="name"><xsl:value-of select="@param"/></xsl:attribute>
					<xsl:attribute name="com">+</xsl:attribute>
					<xsl:attribute name="val"><xsl:value-of select="$decrs"/></xsl:attribute>
				</xsl:element>
				<xsl:element name="Param">
					<xsl:attribute name="name"><xsl:value-of select="@param"/></xsl:attribute>
					<xsl:attribute name="com">+</xsl:attribute>
					<xsl:attribute name="val"><xsl:value-of select="$decrc"/></xsl:attribute>
				</xsl:element>
      	  		</xsl:when>
        		<xsl:when test="@x = 'speed' or 1">
				<xsl:element name="Param">
					<xsl:attribute name="name"><xsl:value-of select="@param"/></xsl:attribute>
					<xsl:attribute name="com">+</xsl:attribute>
					<xsl:attribute name="val"><xsl:value-of select="$sdecrm"/></xsl:attribute>
				</xsl:element>
				<xsl:element name="Param">
					<xsl:attribute name="name"><xsl:value-of select="@param"/></xsl:attribute>
					<xsl:attribute name="com">+</xsl:attribute>
					<xsl:attribute name="val"><xsl:value-of select="$sdecrs"/></xsl:attribute>
				</xsl:element>
				<xsl:element name="Param">
					<xsl:attribute name="name"><xsl:value-of select="@param"/></xsl:attribute>
					<xsl:attribute name="com">+</xsl:attribute>
					<xsl:attribute name="val"><xsl:value-of select="$sdecrc"/></xsl:attribute>
				</xsl:element>
      	  		</xsl:when>

  		</xsl:choose>
		</xsl:if>

	</xsl:element>
</xsl:template>

</xsl:stylesheet>
