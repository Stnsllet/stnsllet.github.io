<?xml version="1.0" encoding="Shift_JIS"?>
<xsl:stylesheet xmlns:xsl="http://www.w3.org/1999/XSL/Transform" version="1.0"  xmlns:spibre="http://geroha.ld.infoseek.co.jp/spibre/">
<xsl:output method="xml" version="1.0" encoding="Shift_JIS" indent="yes" />
<xsl:param name="_temp_list"/>
<xsl:param name="_temp_path"/>

<msxsl:script xmlns:msxsl="urn:schemas-microsoft-com:xslt" language="JavaScript" implements-prefix="spibre">
  function toNode(list){
	var array = list.split('/');
	var ret = '';
	for (i = 0; i &lt; array.length; i++) {
		ret = ret + '&lt;Node name=&quot;' + array[i] + '&quot; /&gt;'
	}
   	return(ret);
  }
</msxsl:script>

<xsl:template match="CallTrans">
	<xsl:element name="Event">
	<xsl:element name="CallTrans">
		<xsl:attribute name="path"><xsl:value-of select="$_temp_path"/></xsl:attribute>
		<xsl:copy-of select="child"/>
		<xsl:copy-of select="."/>
		<xsl:value-of select="spibre:toNode($_temp_list)" disable-output-escaping="yes"/>
		<xsl:for-each select="Node">
		<xsl:apply-templates /><xsl:apply-templates /><xsl:apply-templates />
		</xsl:for-each>
	</xsl:element>

	<xsl:element name="Event">
		<xsl:for-each select="Node">
		<xsl:apply-templates /><xsl:apply-templates /><xsl:apply-templates />
		</xsl:for-each>
	</xsl:element>
	</xsl:element>
</xsl:template>

<xsl:template match="*">
	<xsl:element name="Event">
		<xsl:copy-of select="."/>
	</xsl:element>
</xsl:template>

</xsl:stylesheet>
