<?xml version="1.0" encoding="Shift_JIS"?>
<xsl:stylesheet xmlns:xsl="http://www.w3.org/1999/XSL/Transform" version="1.0"  xmlns:sys="http://stnsllethouse.blog.fc2.com/">
<xsl:output method="xml" version="1.0" encoding="Shift_JIS" indent="yes" />

<xsl:param name="_temp_searchpason"/>
<xsl:param name="_temp_searchjob"/>

<msxsl:script xmlns:msxsl="urn:schemas-microsoft-com:xslt" language="JavaScript" implements-prefix="sys">
  function rnd(){
   	return(Math.random() * (1.005-0.995)+0.995);
  }
  function rnd2(){
   	return((Math.random() * 1.00005) + 1);
  }
</msxsl:script>


<xsl:template match="CallTrans">
	<xsl:variable name="lev" select="@lev"/>
	<xsl:variable name="get" select="@out"/>
	<xsl:variable name="pason" select="$_temp_searchpason"/>
	<xsl:variable name="job" select="$_temp_searchjob"/>

	<xsl:element name="List">
	<xsl:for-each select="document(concat('../',@data))/PasonData/Pason[@name=$_temp_searchpason]">
		<xsl:element name="Param">
			<xsl:attribute name="name"><xsl:value-of select="$get"/>.name</xsl:attribute>
			<xsl:attribute name="val"><xsl:value-of select="@name"/></xsl:attribute>
		</xsl:element>
		<xsl:element name="Param">
			<xsl:attribute name="name"><xsl:value-of select="$get"/>.str</xsl:attribute>
			<xsl:attribute name="val"><xsl:value-of select="@str"/></xsl:attribute>
		</xsl:element>
		<xsl:element name="Param">
			<xsl:attribute name="name"><xsl:value-of select="$get"/>.help</xsl:attribute>
			<xsl:attribute name="val"><xsl:value-of select="@help"/></xsl:attribute>
		</xsl:element>
		<xsl:for-each select="./Grow">
		<xsl:element name="Param">
			<xsl:attribute name="name"><xsl:value-of select="$get"/>.Grow.hp</xsl:attribute>
			<xsl:attribute name="val"><xsl:value-of select="@hp"/></xsl:attribute>
		</xsl:element>
		<xsl:element name="Param">
			<xsl:attribute name="name"><xsl:value-of select="$get"/>.Grow.mp</xsl:attribute>
			<xsl:attribute name="val"><xsl:value-of select="@mp"/></xsl:attribute>
		</xsl:element>
		<xsl:element name="Param">
			<xsl:attribute name="name"><xsl:value-of select="$get"/>.Grow.atc</xsl:attribute>
			<xsl:attribute name="val"><xsl:value-of select="@atc"/></xsl:attribute>
		</xsl:element>
		<xsl:element name="Param">
			<xsl:attribute name="name"><xsl:value-of select="$get"/>.Grow.def</xsl:attribute>
			<xsl:attribute name="val"><xsl:value-of select="@def"/></xsl:attribute>
		</xsl:element>
		<xsl:element name="Param">
			<xsl:attribute name="name"><xsl:value-of select="$get"/>.Grow.mag</xsl:attribute>
			<xsl:attribute name="val"><xsl:value-of select="@mag"/></xsl:attribute>
		</xsl:element>
		<xsl:element name="Param">
			<xsl:attribute name="name"><xsl:value-of select="$get"/>.Grow.spd</xsl:attribute>
			<xsl:attribute name="val"><xsl:value-of select="@spd"/></xsl:attribute>
		</xsl:element>
		</xsl:for-each>
		<xsl:for-each select="./Param">
		<xsl:element name="Param">
			<xsl:attribute name="name"><xsl:value-of select="$get"/>.Param.hp</xsl:attribute>
			<xsl:attribute name="val"><xsl:value-of select="@hp"/></xsl:attribute>
		</xsl:element>
		<xsl:element name="Param">
			<xsl:attribute name="name"><xsl:value-of select="$get"/>.First.hp</xsl:attribute>
			<xsl:attribute name="val">0.4</xsl:attribute>
		</xsl:element>
		<xsl:element name="Param">
			<xsl:attribute name="name"><xsl:value-of select="$get"/>.Param.mp</xsl:attribute>
			<xsl:attribute name="val"><xsl:value-of select="@mp"/></xsl:attribute>
		</xsl:element>
		<xsl:element name="Param">
			<xsl:attribute name="name"><xsl:value-of select="$get"/>.First.mp</xsl:attribute>
			<xsl:attribute name="val">0.4</xsl:attribute>
		</xsl:element>
		<xsl:element name="Param">
			<xsl:attribute name="name"><xsl:value-of select="$get"/>.First.mp</xsl:attribute>
			<xsl:attribute name="com">*</xsl:attribute>
			<xsl:attribute name="val">=<xsl:value-of select="$get"/>.Param.mp</xsl:attribute>
		</xsl:element>
		<xsl:element name="Param">
			<xsl:attribute name="name"><xsl:value-of select="$get"/>.Param.atc</xsl:attribute>
			<xsl:attribute name="val"><xsl:value-of select="@atc"/></xsl:attribute>
		</xsl:element>
		<xsl:element name="Param">
			<xsl:attribute name="name"><xsl:value-of select="$get"/>.First.atc</xsl:attribute>
			<xsl:attribute name="val">0.4</xsl:attribute>
		</xsl:element>
		<xsl:element name="Param">
			<xsl:attribute name="name"><xsl:value-of select="$get"/>.First.atc</xsl:attribute>
			<xsl:attribute name="com">*</xsl:attribute>
			<xsl:attribute name="val">=<xsl:value-of select="$get"/>.Param.atc</xsl:attribute>
		</xsl:element>
		<xsl:element name="Param">
			<xsl:attribute name="name"><xsl:value-of select="$get"/>.Param.def</xsl:attribute>
			<xsl:attribute name="val"><xsl:value-of select="@def"/></xsl:attribute>
		</xsl:element>
		<xsl:element name="Param">
			<xsl:attribute name="name"><xsl:value-of select="$get"/>.First.def</xsl:attribute>
			<xsl:attribute name="val">0.4</xsl:attribute>
		</xsl:element>
		<xsl:element name="Param">
			<xsl:attribute name="name"><xsl:value-of select="$get"/>.First.def</xsl:attribute>
			<xsl:attribute name="com">*</xsl:attribute>
			<xsl:attribute name="val">=<xsl:value-of select="$get"/>.Param.def</xsl:attribute>
		</xsl:element>
		<xsl:element name="Param">
			<xsl:attribute name="name"><xsl:value-of select="$get"/>.Param.mag</xsl:attribute>
			<xsl:attribute name="val"><xsl:value-of select="@mag"/></xsl:attribute>
		</xsl:element>
		<xsl:element name="Param">
			<xsl:attribute name="name"><xsl:value-of select="$get"/>.First.mag</xsl:attribute>
			<xsl:attribute name="val">0.4</xsl:attribute>
		</xsl:element>
		<xsl:element name="Param">
			<xsl:attribute name="name"><xsl:value-of select="$get"/>.First.mag</xsl:attribute>
			<xsl:attribute name="com">*</xsl:attribute>
			<xsl:attribute name="val">=<xsl:value-of select="$get"/>.Param.mag</xsl:attribute>
		</xsl:element>
		<xsl:element name="Param">
			<xsl:attribute name="name"><xsl:value-of select="$get"/>.Param.spd</xsl:attribute>
			<xsl:attribute name="val"><xsl:value-of select="@spd"/></xsl:attribute>
		</xsl:element>
		<xsl:element name="Param">
			<xsl:attribute name="name"><xsl:value-of select="$get"/>.First.spd</xsl:attribute>
			<xsl:attribute name="val">0.4</xsl:attribute>
		</xsl:element>
		<xsl:element name="Param">
			<xsl:attribute name="name"><xsl:value-of select="$get"/>.First.spd</xsl:attribute>
			<xsl:attribute name="com">*</xsl:attribute>
			<xsl:attribute name="val">=<xsl:value-of select="$get"/>.Param.spd</xsl:attribute>
		</xsl:element>
		<xsl:element name="Param">
			<xsl:attribute name="name"><xsl:value-of select="$get"/>.Param.mov</xsl:attribute>
			<xsl:attribute name="val"><xsl:value-of select="@mov"/></xsl:attribute>
		</xsl:element>
		<xsl:element name="Param">
			<xsl:attribute name="name"><xsl:value-of select="$get"/>.First.mov</xsl:attribute>
			<xsl:attribute name="val">=<xsl:value-of select="$get"/>.Param.mov</xsl:attribute>
		</xsl:element>
		</xsl:for-each>
		<xsl:for-each select="./Enemy">
		<xsl:element name="Param">
			<xsl:attribute name="name"><xsl:value-of select="$get"/>.Enemy.hp</xsl:attribute>
			<xsl:attribute name="val"><xsl:value-of select="@hp"/></xsl:attribute>
		</xsl:element>
		<xsl:element name="Param">
			<xsl:attribute name="name"><xsl:value-of select="$get"/>.Enemy.mp</xsl:attribute>
			<xsl:attribute name="val"><xsl:value-of select="@mp"/></xsl:attribute>
		</xsl:element>
		<xsl:element name="Param">
			<xsl:attribute name="name"><xsl:value-of select="$get"/>.Enemy.atc</xsl:attribute>
			<xsl:attribute name="val"><xsl:value-of select="@atc"/></xsl:attribute>
		</xsl:element>
		<xsl:element name="Param">
			<xsl:attribute name="name"><xsl:value-of select="$get"/>.Enemy.def</xsl:attribute>
			<xsl:attribute name="val"><xsl:value-of select="@def"/></xsl:attribute>
		</xsl:element>
		<xsl:element name="Param">
			<xsl:attribute name="name"><xsl:value-of select="$get"/>.Enemy.mag</xsl:attribute>
			<xsl:attribute name="val"><xsl:value-of select="@mag"/></xsl:attribute>
		</xsl:element>
		<xsl:element name="Param">
			<xsl:attribute name="name"><xsl:value-of select="$get"/>.Enemy.spd</xsl:attribute>
			<xsl:attribute name="val"><xsl:value-of select="@spd"/></xsl:attribute>
		</xsl:element>
		</xsl:for-each>
		<xsl:for-each select="./Ex">
		<xsl:element name="Param">
			<xsl:attribute name="name"><xsl:value-of select="$get"/>.Ex.job</xsl:attribute>
			<xsl:attribute name="val"><xsl:value-of select="@job"/></xsl:attribute>
		</xsl:element>
		</xsl:for-each>
	</xsl:for-each>

	<xsl:for-each select="document('../Data/Job.xml')/JobData/Job[@name=$_temp_searchjob]">
		<xsl:element name="Param">
			<xsl:attribute name="name"><xsl:value-of select="$get"/>.Job.name</xsl:attribute>
			<xsl:attribute name="val"><xsl:value-of select="@name"/></xsl:attribute>
		</xsl:element>
		<xsl:element name="Param">
			<xsl:attribute name="name"><xsl:value-of select="$get"/>.Job.str</xsl:attribute>
			<xsl:attribute name="val"><xsl:value-of select="@str"/></xsl:attribute>
		</xsl:element>
		<xsl:element name="Param">
			<xsl:attribute name="name"><xsl:value-of select="$get"/>.Job.help</xsl:attribute>
			<xsl:attribute name="val"><xsl:value-of select="@help"/></xsl:attribute>
		</xsl:element>
		<xsl:for-each select="./Grow">
		<xsl:element name="Param">
			<xsl:attribute name="name"><xsl:value-of select="$get"/>.Job.Grow.hp</xsl:attribute>
			<xsl:attribute name="val"><xsl:value-of select="@hp"/></xsl:attribute>
		</xsl:element>
		<xsl:element name="Param">
			<xsl:attribute name="name"><xsl:value-of select="$get"/>.Job.Grow.mp</xsl:attribute>
			<xsl:attribute name="val"><xsl:value-of select="@mp"/></xsl:attribute>
		</xsl:element>
		<xsl:element name="Param">
			<xsl:attribute name="name"><xsl:value-of select="$get"/>.Job.Grow.atc</xsl:attribute>
			<xsl:attribute name="val"><xsl:value-of select="@atc"/></xsl:attribute>
		</xsl:element>
		<xsl:element name="Param">
			<xsl:attribute name="name"><xsl:value-of select="$get"/>.Job.Grow.def</xsl:attribute>
			<xsl:attribute name="val"><xsl:value-of select="@def"/></xsl:attribute>
		</xsl:element>
		<xsl:element name="Param">
			<xsl:attribute name="name"><xsl:value-of select="$get"/>.Job.Grow.mag</xsl:attribute>
			<xsl:attribute name="val"><xsl:value-of select="@mag"/></xsl:attribute>
		</xsl:element>
		<xsl:element name="Param">
			<xsl:attribute name="name"><xsl:value-of select="$get"/>.Job.Grow.spd</xsl:attribute>
			<xsl:attribute name="val"><xsl:value-of select="@spd"/></xsl:attribute>
		</xsl:element>
		</xsl:for-each>
	</xsl:for-each>

	<xsl:element name="Param"><xsl:attribute name="name"><xsl:value-of select="$get"/>.lev</xsl:attribute><xsl:attribute name="val"><xsl:value-of select="$lev"/></xsl:attribute></xsl:element>
	<xsl:element name="Param"><xsl:attribute name="name"><xsl:value-of select="$get"/>.lev2</xsl:attribute><xsl:attribute name="val"><xsl:value-of select="$lev"/></xsl:attribute></xsl:element>
	<xsl:element name="Param"><xsl:attribute name="name"><xsl:value-of select="$get"/>.lev2</xsl:attribute><xsl:attribute name="com">/</xsl:attribute><xsl:attribute name="val">1000</xsl:attribute></xsl:element>
	<xsl:element name="Param"><xsl:attribute name="name"><xsl:value-of select="$get"/>.lev</xsl:attribute><xsl:attribute name="com">-</xsl:attribute><xsl:attribute name="val">=<xsl:value-of select="$get"/>.lev2</xsl:attribute></xsl:element>
	<xsl:element name="Param"><xsl:attribute name="name">_temp_coef</xsl:attribute><xsl:attribute name="val">0.93</xsl:attribute></xsl:element>
	<xsl:element name="Param"><xsl:attribute name="name"><xsl:value-of select="$get"/>.lev2</xsl:attribute><xsl:attribute name="com">/</xsl:attribute><xsl:attribute name="val">8</xsl:attribute></xsl:element>
	<xsl:element name="Param"><xsl:attribute name="name">_temp_coef</xsl:attribute><xsl:attribute name="com">+</xsl:attribute><xsl:attribute name="val">=<xsl:value-of select="$get"/>.lev2</xsl:attribute></xsl:element>

	<xsl:element name="Param">
		<xsl:attribute name="name"><xsl:value-of select="$get"/>.hp</xsl:attribute>
		<xsl:attribute name="val">=<xsl:value-of select="$get"/>.Grow.hp</xsl:attribute>
	</xsl:element>
	<xsl:element name="Param">
		<xsl:attribute name="name"><xsl:value-of select="$get"/>.hp</xsl:attribute>
		<xsl:attribute name="com">*</xsl:attribute>
		<xsl:attribute name="val">=<xsl:value-of select="$get"/>.Job.Grow.hp</xsl:attribute>
	</xsl:element>
	<xsl:element name="Param">
		<xsl:attribute name="name"><xsl:value-of select="$get"/>.hp</xsl:attribute>
		<xsl:attribute name="com">/</xsl:attribute>
		<xsl:attribute name="val">1300</xsl:attribute>
	</xsl:element>
	<xsl:element name="Param">
		<xsl:attribute name="name"><xsl:value-of select="$get"/>.hp</xsl:attribute>
		<xsl:attribute name="com">*</xsl:attribute>
		<xsl:attribute name="val">=_temp_coef</xsl:attribute>
	</xsl:element>
	<xsl:element name="Param">
		<xsl:attribute name="name"><xsl:value-of select="$get"/>.hp</xsl:attribute>
		<xsl:attribute name="com">*</xsl:attribute>
		<xsl:attribute name="val">=<xsl:value-of select="$get"/>.lev</xsl:attribute>
	</xsl:element>
	<xsl:element name="Param">
		<xsl:attribute name="name"><xsl:value-of select="$get"/>.hp</xsl:attribute>
		<xsl:attribute name="com">*</xsl:attribute>
		<xsl:attribute name="val"><xsl:value-of select="sys:rnd()"/></xsl:attribute>
	</xsl:element>
	<xsl:element name="Param">
		<xsl:attribute name="name"><xsl:value-of select="$get"/>.hp</xsl:attribute>
		<xsl:attribute name="com">+</xsl:attribute>
		<xsl:attribute name="val">=<xsl:value-of select="$get"/>.First.hp</xsl:attribute>
	</xsl:element>
	<xsl:if test="@enemy">
	<xsl:element name="Param">
		<xsl:attribute name="name"><xsl:value-of select="$get"/>.Enemy.hp</xsl:attribute>
		<xsl:attribute name="com">*</xsl:attribute>
		<xsl:attribute name="val"><xsl:value-of select="@enemy"/></xsl:attribute>
	</xsl:element>
	<xsl:element name="Param">
		<xsl:attribute name="name"><xsl:value-of select="$get"/>.hp</xsl:attribute>
		<xsl:attribute name="com">+</xsl:attribute>
		<xsl:attribute name="val">=<xsl:value-of select="$get"/>.Enemy.hp</xsl:attribute>
	</xsl:element>
	</xsl:if>

	<xsl:element name="Param">
		<xsl:attribute name="name"><xsl:value-of select="$get"/>.mp</xsl:attribute>
		<xsl:attribute name="val">=<xsl:value-of select="$get"/>.Grow.mp</xsl:attribute>
	</xsl:element>
	<xsl:element name="Param">
		<xsl:attribute name="name"><xsl:value-of select="$get"/>.mp</xsl:attribute>
		<xsl:attribute name="com">*</xsl:attribute>
		<xsl:attribute name="val">=<xsl:value-of select="$get"/>.Job.Grow.mp</xsl:attribute>
	</xsl:element>
	<xsl:element name="Param">
		<xsl:attribute name="name"><xsl:value-of select="$get"/>.mp</xsl:attribute>
		<xsl:attribute name="com">/</xsl:attribute>
		<xsl:attribute name="val">1300</xsl:attribute>
	</xsl:element>
	<xsl:element name="Param">
		<xsl:attribute name="name"><xsl:value-of select="$get"/>.mp</xsl:attribute>
		<xsl:attribute name="com">*</xsl:attribute>
		<xsl:attribute name="val">=_temp_coef</xsl:attribute>
	</xsl:element>
	<xsl:element name="Param">
		<xsl:attribute name="name"><xsl:value-of select="$get"/>.mp</xsl:attribute>
		<xsl:attribute name="com">*</xsl:attribute>
		<xsl:attribute name="val">=<xsl:value-of select="$get"/>.lev</xsl:attribute>
	</xsl:element>
	<xsl:element name="Param">
		<xsl:attribute name="name"><xsl:value-of select="$get"/>.mp</xsl:attribute>
		<xsl:attribute name="com">*</xsl:attribute>
		<xsl:attribute name="val"><xsl:value-of select="sys:rnd()"/></xsl:attribute>
	</xsl:element>
	<xsl:element name="Param">
		<xsl:attribute name="name"><xsl:value-of select="$get"/>.mp</xsl:attribute>
		<xsl:attribute name="com">+</xsl:attribute>
		<xsl:attribute name="val">=<xsl:value-of select="$get"/>.First.hp</xsl:attribute>
	</xsl:element>
	<xsl:if test="@enemy">
	<xsl:element name="Param">
		<xsl:attribute name="name"><xsl:value-of select="$get"/>.Enemy.mp</xsl:attribute>
		<xsl:attribute name="com">*</xsl:attribute>
		<xsl:attribute name="val"><xsl:value-of select="@enemy"/></xsl:attribute>
	</xsl:element>
	<xsl:element name="Param">
		<xsl:attribute name="name"><xsl:value-of select="$get"/>.mp</xsl:attribute>
		<xsl:attribute name="com">+</xsl:attribute>
		<xsl:attribute name="val">=<xsl:value-of select="$get"/>.Enemy.mp</xsl:attribute>
	</xsl:element>
	</xsl:if>

	<xsl:element name="Param">
		<xsl:attribute name="name"><xsl:value-of select="$get"/>.atc</xsl:attribute>
		<xsl:attribute name="val">=<xsl:value-of select="$get"/>.Grow.atc</xsl:attribute>
	</xsl:element>
	<xsl:element name="Param">
		<xsl:attribute name="name"><xsl:value-of select="$get"/>.atc</xsl:attribute>
		<xsl:attribute name="com">*</xsl:attribute>
		<xsl:attribute name="val">=<xsl:value-of select="$get"/>.Job.Grow.atc</xsl:attribute>
	</xsl:element>
	<xsl:element name="Param">
		<xsl:attribute name="name"><xsl:value-of select="$get"/>.atc</xsl:attribute>
		<xsl:attribute name="com">/</xsl:attribute>
		<xsl:attribute name="val">3000</xsl:attribute>
	</xsl:element>
	<xsl:element name="Param">
		<xsl:attribute name="name"><xsl:value-of select="$get"/>.atc</xsl:attribute>
		<xsl:attribute name="com">*</xsl:attribute>
		<xsl:attribute name="val">=_temp_coef</xsl:attribute>
	</xsl:element>

	<xsl:element name="Param">
		<xsl:attribute name="name"><xsl:value-of select="$get"/>.atc</xsl:attribute>
		<xsl:attribute name="com">*</xsl:attribute>
		<xsl:attribute name="val">=<xsl:value-of select="$get"/>.lev</xsl:attribute>
	</xsl:element>
	<xsl:element name="Param">
		<xsl:attribute name="name"><xsl:value-of select="$get"/>.atc</xsl:attribute>
		<xsl:attribute name="com">*</xsl:attribute>
		<xsl:attribute name="val"><xsl:value-of select="sys:rnd()"/></xsl:attribute>
	</xsl:element>
	<xsl:element name="Param">
		<xsl:attribute name="name"><xsl:value-of select="$get"/>.atc</xsl:attribute>
		<xsl:attribute name="com">+</xsl:attribute>
		<xsl:attribute name="val">=<xsl:value-of select="$get"/>.First.atc</xsl:attribute>
	</xsl:element>
	<xsl:if test="@enemy">
	<xsl:element name="Param">
		<xsl:attribute name="name"><xsl:value-of select="$get"/>.Enemy.atc</xsl:attribute>
		<xsl:attribute name="com">*</xsl:attribute>
		<xsl:attribute name="val"><xsl:value-of select="@enemy"/></xsl:attribute>
	</xsl:element>
	<xsl:element name="Param">
		<xsl:attribute name="name"><xsl:value-of select="$get"/>.atc</xsl:attribute>
		<xsl:attribute name="com">+</xsl:attribute>
		<xsl:attribute name="val">=<xsl:value-of select="$get"/>.Enemy.atc</xsl:attribute>
	</xsl:element>
	</xsl:if>

	<xsl:element name="Param">
		<xsl:attribute name="name"><xsl:value-of select="$get"/>.def</xsl:attribute>
		<xsl:attribute name="val">=<xsl:value-of select="$get"/>.Grow.def</xsl:attribute>
	</xsl:element>
	<xsl:element name="Param">
		<xsl:attribute name="name"><xsl:value-of select="$get"/>.def</xsl:attribute>
		<xsl:attribute name="com">*</xsl:attribute>
		<xsl:attribute name="val">=<xsl:value-of select="$get"/>.Job.Grow.def</xsl:attribute>
	</xsl:element>
	<xsl:element name="Param">
		<xsl:attribute name="name"><xsl:value-of select="$get"/>.def</xsl:attribute>
		<xsl:attribute name="com">/</xsl:attribute>
		<xsl:attribute name="val">3000</xsl:attribute>
	</xsl:element>
	<xsl:element name="Param">
		<xsl:attribute name="name"><xsl:value-of select="$get"/>.def</xsl:attribute>
		<xsl:attribute name="com">*</xsl:attribute>
		<xsl:attribute name="val">=_temp_coef</xsl:attribute>
	</xsl:element>
	<xsl:element name="Param">
		<xsl:attribute name="name"><xsl:value-of select="$get"/>.def</xsl:attribute>
		<xsl:attribute name="com">*</xsl:attribute>
		<xsl:attribute name="val">=<xsl:value-of select="$get"/>.lev</xsl:attribute>
	</xsl:element>
	<xsl:element name="Param">
		<xsl:attribute name="name"><xsl:value-of select="$get"/>.def</xsl:attribute>
		<xsl:attribute name="com">*</xsl:attribute>
		<xsl:attribute name="val"><xsl:value-of select="sys:rnd()"/></xsl:attribute>
	</xsl:element>
	<xsl:element name="Param">
		<xsl:attribute name="name"><xsl:value-of select="$get"/>.def</xsl:attribute>
		<xsl:attribute name="com">+</xsl:attribute>
		<xsl:attribute name="val">=<xsl:value-of select="$get"/>.First.def</xsl:attribute>
	</xsl:element>
	<xsl:if test="@enemy">
	<xsl:element name="Param">
		<xsl:attribute name="name"><xsl:value-of select="$get"/>.Enemy.def</xsl:attribute>
		<xsl:attribute name="com">*</xsl:attribute>
		<xsl:attribute name="val"><xsl:value-of select="@enemy"/></xsl:attribute>
	</xsl:element>
	<xsl:element name="Param">
		<xsl:attribute name="name"><xsl:value-of select="$get"/>.def</xsl:attribute>
		<xsl:attribute name="com">+</xsl:attribute>
		<xsl:attribute name="val">=<xsl:value-of select="$get"/>.Enemy.def</xsl:attribute>
	</xsl:element>
	</xsl:if>

	<xsl:element name="Param">
		<xsl:attribute name="name"><xsl:value-of select="$get"/>.mag</xsl:attribute>
		<xsl:attribute name="val">=<xsl:value-of select="$get"/>.Grow.mag</xsl:attribute>
	</xsl:element>
	<xsl:element name="Param">
		<xsl:attribute name="name"><xsl:value-of select="$get"/>.mag</xsl:attribute>
		<xsl:attribute name="com">*</xsl:attribute>
		<xsl:attribute name="val">=<xsl:value-of select="$get"/>.Job.Grow.mag</xsl:attribute>
	</xsl:element>
	<xsl:element name="Param">
		<xsl:attribute name="name"><xsl:value-of select="$get"/>.mag</xsl:attribute>
		<xsl:attribute name="com">/</xsl:attribute>
		<xsl:attribute name="val">3000</xsl:attribute>
	</xsl:element>
	<xsl:element name="Param">
		<xsl:attribute name="name"><xsl:value-of select="$get"/>.mag</xsl:attribute>
		<xsl:attribute name="com">*</xsl:attribute>
		<xsl:attribute name="val">=_temp_coef</xsl:attribute>
	</xsl:element>
	<xsl:element name="Param">
		<xsl:attribute name="name"><xsl:value-of select="$get"/>.mag</xsl:attribute>
		<xsl:attribute name="com">*</xsl:attribute>
		<xsl:attribute name="val">=<xsl:value-of select="$get"/>.lev</xsl:attribute>
	</xsl:element>
	<xsl:element name="Param">
		<xsl:attribute name="name"><xsl:value-of select="$get"/>.mag</xsl:attribute>
		<xsl:attribute name="com">*</xsl:attribute>
		<xsl:attribute name="val"><xsl:value-of select="sys:rnd()"/></xsl:attribute>
	</xsl:element>
	<xsl:element name="Param">
		<xsl:attribute name="name"><xsl:value-of select="$get"/>.mag</xsl:attribute>
		<xsl:attribute name="com">+</xsl:attribute>
		<xsl:attribute name="val">=<xsl:value-of select="$get"/>.First.mag</xsl:attribute>
	</xsl:element>
	<xsl:if test="@enemy">
	<xsl:element name="Param">
		<xsl:attribute name="name"><xsl:value-of select="$get"/>.Enemy.mag</xsl:attribute>
		<xsl:attribute name="com">*</xsl:attribute>
		<xsl:attribute name="val"><xsl:value-of select="@enemy"/></xsl:attribute>
	</xsl:element>
	<xsl:element name="Param">
		<xsl:attribute name="name"><xsl:value-of select="$get"/>.mag</xsl:attribute>
		<xsl:attribute name="com">+</xsl:attribute>
		<xsl:attribute name="val">=<xsl:value-of select="$get"/>.Enemy.mag</xsl:attribute>
	</xsl:element>
	</xsl:if>

	<xsl:element name="Param">
		<xsl:attribute name="name"><xsl:value-of select="$get"/>.spd</xsl:attribute>
		<xsl:attribute name="val">=<xsl:value-of select="$get"/>.Grow.spd</xsl:attribute>
	</xsl:element>
	<xsl:element name="Param">
		<xsl:attribute name="name"><xsl:value-of select="$get"/>.spd</xsl:attribute>
		<xsl:attribute name="com">*</xsl:attribute>
		<xsl:attribute name="val">=<xsl:value-of select="$get"/>.Job.Grow.spd</xsl:attribute>
	</xsl:element>
	<xsl:element name="Param">
		<xsl:attribute name="name"><xsl:value-of select="$get"/>.spd</xsl:attribute>
		<xsl:attribute name="com">/</xsl:attribute>
		<xsl:attribute name="val">3000</xsl:attribute>
	</xsl:element>
	<xsl:element name="Param">
		<xsl:attribute name="name"><xsl:value-of select="$get"/>.spd</xsl:attribute>
		<xsl:attribute name="com">*</xsl:attribute>
		<xsl:attribute name="val">=_temp_coef</xsl:attribute>
	</xsl:element>
	<xsl:element name="Param">
		<xsl:attribute name="name"><xsl:value-of select="$get"/>.spd</xsl:attribute>
		<xsl:attribute name="com">*</xsl:attribute>
		<xsl:attribute name="val">=<xsl:value-of select="$get"/>.lev</xsl:attribute>
	</xsl:element>
	<xsl:element name="Param">
		<xsl:attribute name="name"><xsl:value-of select="$get"/>.spd</xsl:attribute>
		<xsl:attribute name="com">*</xsl:attribute>
		<xsl:attribute name="val"><xsl:value-of select="sys:rnd()"/></xsl:attribute>
	</xsl:element>
	<xsl:element name="Param">
		<xsl:attribute name="name"><xsl:value-of select="$get"/>.spd</xsl:attribute>
		<xsl:attribute name="com">+</xsl:attribute>
		<xsl:attribute name="val">=<xsl:value-of select="$get"/>.First.spd</xsl:attribute>
	</xsl:element>
	<xsl:if test="@enemy">
	<xsl:element name="Param">
		<xsl:attribute name="name"><xsl:value-of select="$get"/>.Enemy.spd</xsl:attribute>
		<xsl:attribute name="com">*</xsl:attribute>
		<xsl:attribute name="val"><xsl:value-of select="@enemy"/></xsl:attribute>
	</xsl:element>
	<xsl:element name="Param">
		<xsl:attribute name="name"><xsl:value-of select="$get"/>.spd</xsl:attribute>
		<xsl:attribute name="com">+</xsl:attribute>
		<xsl:attribute name="val">=<xsl:value-of select="$get"/>.Enemy.spd</xsl:attribute>
	</xsl:element>
	</xsl:if>

	</xsl:element>
</xsl:template>

</xsl:stylesheet>
