<?xml version="1.0" encoding="Shift_JIS"?>
<xsl:stylesheet xmlns:xsl="http://www.w3.org/1999/XSL/Transform" version="1.0"  xmlns:spibre="http://geroha.ld.infoseek.co.jp/spibre/">
<xsl:output method="xml" version="1.0" encoding="Shift_JIS" indent="yes" />

<xsl:param name="_temp_selflg"/>

<xsl:template match="CallTrans">
	<xsl:variable name="FlgDef" select="document('../System/GlobalFlg.xml')/GlobalFlg"/>
	<xsl:variable name="search" select="$_temp_selflg"/>
	<xsl:element name="List">
		<xsl:for-each select="$FlgDef/Flg[@name=$_temp_selflg]">
		<xsl:element name="Popup">
			<xsl:attribute name="msg">flagname= <xsl:value-of select="@name"/>
				Path = <xsl:value-of select="@no"/>
				���l = <xsl:value-of select="@help"/>
			</xsl:attribute>
		</xsl:element>
		<xsl:element name="Sound">
			<xsl:attribute name="bgm"><xsl:value-of select="@name"/></xsl:attribute>
		</xsl:element>
		</xsl:for-each>
		<xsl:element name="Window">
			<xsl:attribute name="x">0</xsl:attribute>
			<xsl:attribute name="y">0</xsl:attribute>
			<xsl:attribute name="w">800</xsl:attribute>
			<xsl:attribute name="h">600</xsl:attribute>
			<xsl:attribute name="col">0</xsl:attribute>
			<xsl:attribute name="name">flgcheck2</xsl:attribute>
			<xsl:attribute name="title">�t���O�`�F�b�N</xsl:attribute>
			<xsl:for-each select="$FlgDef/Flg">
			<xsl:element name="Plane">
				<xsl:attribute name="x"><xsl:value-of select="floor((position()-1) div 30) mod 30 *100 + 4"/></xsl:attribute>
				<xsl:attribute name="y"><xsl:value-of select="(position()-1) mod 30 *18 + 8"/></xsl:attribute>
				<xsl:attribute name="name"><xsl:value-of select="@name"/></xsl:attribute>
				<xsl:attribute name="event">[Debug]FlgCheck.xml</xsl:attribute>
				<xsl:attribute name="com">param/rnd/_temp_selflg/<xsl:value-of select="@name"/></xsl:attribute>
			</xsl:element>
			</xsl:for-each>
		</xsl:element>
	</xsl:element>
</xsl:template>

</xsl:stylesheet>
