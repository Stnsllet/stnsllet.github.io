<?xml version="1.0" encoding="Shift_JIS"?>
<xsl:stylesheet xmlns:xsl="http://www.w3.org/1999/XSL/Transform" version="1.0"  xmlns:spibre="http://geroha.ld.infoseek.co.jp/spibre/">
<xsl:output method="xml" version="1.0" encoding="Shift_JIS" indent="yes" />

<xsl:template match="CallTrans">
	<xsl:variable name="leader" select="substring-before(@param,'/')"/>
	<xsl:variable name="maploc" select="substring-before(substring-after(@param,'/'),'/')"/>
	<xsl:variable name="charapos" select="substring-after(substring-after(@param,'/'),'/')"/>

	<xsl:element name="Event">
		<xsl:if test="@type = 'gate'">
			<xsl:element name="CallTrans">
				<xsl:attribute name="type">move</xsl:attribute><xsl:attribute name="param">_temp_lead/_temp_m/_temp_p</xsl:attribute><xsl:if test="@to"><xsl:attribute name="to"><xsl:value-of select="@to"/></xsl:attribute></xsl:if><xsl:if test="@from"><xsl:attribute name="from"><xsl:value-of select="@from"/></xsl:attribute></xsl:if>
				<xsl:attribute name="id">0</xsl:attribute><xsl:attribute name="len">=_temp_gatesize</xsl:attribute><xsl:if test="@pos"><xsl:attribute name="pos"><xsl:value-of select="@pos"/></xsl:attribute></xsl:if><xsl:if test="@locate"><xsl:attribute name="locate"><xsl:value-of select="@locate"/></xsl:attribute></xsl:if>
				<xsl:attribute name="path">Xsl/MultiMap.xsl</xsl:attribute>
			</xsl:element>
			<xsl:element name="CallTrans">
				<xsl:attribute name="type">move</xsl:attribute><xsl:attribute name="param">_temp_lead/_temp_m/_temp_p</xsl:attribute><xsl:if test="@to"><xsl:attribute name="to"><xsl:value-of select="@to"/></xsl:attribute></xsl:if><xsl:if test="@from"><xsl:attribute name="from"><xsl:value-of select="@from"/></xsl:attribute></xsl:if>
				<xsl:attribute name="id">1</xsl:attribute><xsl:attribute name="len">=_temp_gatesize</xsl:attribute><xsl:if test="@pos"><xsl:attribute name="pos"><xsl:value-of select="@pos"/></xsl:attribute></xsl:if><xsl:if test="@locate"><xsl:attribute name="locate"><xsl:value-of select="@locate"/></xsl:attribute></xsl:if>
				<xsl:attribute name="path">Xsl/MultiMap.xsl</xsl:attribute>
			</xsl:element>
			<xsl:element name="CallTrans">
				<xsl:attribute name="type">move</xsl:attribute><xsl:attribute name="param">_temp_lead/_temp_m/_temp_p</xsl:attribute><xsl:if test="@to"><xsl:attribute name="to"><xsl:value-of select="@to"/></xsl:attribute></xsl:if><xsl:if test="@from"><xsl:attribute name="from"><xsl:value-of select="@from"/></xsl:attribute></xsl:if>
				<xsl:attribute name="id">2</xsl:attribute><xsl:attribute name="len">=_temp_gatesize</xsl:attribute><xsl:if test="@pos"><xsl:attribute name="pos"><xsl:value-of select="@pos"/></xsl:attribute></xsl:if><xsl:if test="@locate"><xsl:attribute name="locate"><xsl:value-of select="@locate"/></xsl:attribute></xsl:if>
				<xsl:attribute name="path">Xsl/MultiMap.xsl</xsl:attribute>
			</xsl:element>
			<xsl:element name="CallTrans">
				<xsl:attribute name="type">move</xsl:attribute><xsl:attribute name="param">_temp_lead/_temp_m/_temp_p</xsl:attribute><xsl:if test="@to"><xsl:attribute name="to"><xsl:value-of select="@to"/></xsl:attribute></xsl:if><xsl:if test="@from"><xsl:attribute name="from"><xsl:value-of select="@from"/></xsl:attribute></xsl:if>
				<xsl:attribute name="id">3</xsl:attribute><xsl:attribute name="len">=_temp_gatesize</xsl:attribute><xsl:if test="@pos"><xsl:attribute name="pos"><xsl:value-of select="@pos"/></xsl:attribute></xsl:if><xsl:if test="@locate"><xsl:attribute name="locate"><xsl:value-of select="@locate"/></xsl:attribute></xsl:if>
				<xsl:attribute name="path">Xsl/MultiMap.xsl</xsl:attribute>
			</xsl:element>
			<xsl:element name="CallTrans">
				<xsl:attribute name="type">move</xsl:attribute><xsl:attribute name="param">_temp_lead/_temp_m/_temp_p</xsl:attribute><xsl:if test="@to"><xsl:attribute name="to"><xsl:value-of select="@to"/></xsl:attribute></xsl:if><xsl:if test="@from"><xsl:attribute name="from"><xsl:value-of select="@from"/></xsl:attribute></xsl:if>
				<xsl:attribute name="id">4</xsl:attribute><xsl:attribute name="len">=_temp_gatesize</xsl:attribute><xsl:if test="@pos"><xsl:attribute name="pos"><xsl:value-of select="@pos"/></xsl:attribute></xsl:if><xsl:if test="@locate"><xsl:attribute name="locate"><xsl:value-of select="@locate"/></xsl:attribute></xsl:if>
				<xsl:attribute name="path">Xsl/MultiMap.xsl</xsl:attribute>
			</xsl:element>
			<xsl:element name="CallTrans">
				<xsl:attribute name="type">move</xsl:attribute><xsl:attribute name="param">_temp_lead/_temp_m/_temp_p</xsl:attribute><xsl:if test="@to"><xsl:attribute name="to"><xsl:value-of select="@to"/></xsl:attribute></xsl:if><xsl:if test="@from"><xsl:attribute name="from"><xsl:value-of select="@from"/></xsl:attribute></xsl:if>
				<xsl:attribute name="id">5</xsl:attribute><xsl:attribute name="len">=_temp_gatesize</xsl:attribute><xsl:if test="@pos"><xsl:attribute name="pos"><xsl:value-of select="@pos"/></xsl:attribute></xsl:if><xsl:if test="@locate"><xsl:attribute name="locate"><xsl:value-of select="@locate"/></xsl:attribute></xsl:if>
				<xsl:attribute name="path">Xsl/MultiMap.xsl</xsl:attribute>
			</xsl:element>
			<xsl:element name="CallTrans">
				<xsl:attribute name="type">move</xsl:attribute><xsl:attribute name="param">_temp_lead/_temp_m/_temp_p</xsl:attribute><xsl:if test="@to"><xsl:attribute name="to"><xsl:value-of select="@to"/></xsl:attribute></xsl:if><xsl:if test="@from"><xsl:attribute name="from"><xsl:value-of select="@from"/></xsl:attribute></xsl:if>
				<xsl:attribute name="id">6</xsl:attribute><xsl:attribute name="len">=_temp_gatesize</xsl:attribute><xsl:if test="@pos"><xsl:attribute name="pos"><xsl:value-of select="@pos"/></xsl:attribute></xsl:if><xsl:if test="@locate"><xsl:attribute name="locate"><xsl:value-of select="@locate"/></xsl:attribute></xsl:if>
				<xsl:attribute name="path">Xsl/MultiMap.xsl</xsl:attribute>
			</xsl:element>
			<xsl:element name="CallTrans">
				<xsl:attribute name="type">move</xsl:attribute><xsl:attribute name="param">_temp_lead/_temp_m/_temp_p</xsl:attribute><xsl:if test="@to"><xsl:attribute name="to"><xsl:value-of select="@to"/></xsl:attribute></xsl:if><xsl:if test="@from"><xsl:attribute name="from"><xsl:value-of select="@from"/></xsl:attribute></xsl:if>
				<xsl:attribute name="id">7</xsl:attribute><xsl:attribute name="len">=_temp_gatesize</xsl:attribute><xsl:if test="@pos"><xsl:attribute name="pos"><xsl:value-of select="@pos"/></xsl:attribute></xsl:if><xsl:if test="@locate"><xsl:attribute name="locate"><xsl:value-of select="@locate"/></xsl:attribute></xsl:if>
				<xsl:attribute name="path">Xsl/MultiMap.xsl</xsl:attribute>
			</xsl:element>
			<xsl:element name="CallTrans">
				<xsl:attribute name="type">move</xsl:attribute><xsl:attribute name="param">_temp_lead/_temp_m/_temp_p</xsl:attribute><xsl:if test="@to"><xsl:attribute name="to"><xsl:value-of select="@to"/></xsl:attribute></xsl:if><xsl:if test="@from"><xsl:attribute name="from"><xsl:value-of select="@from"/></xsl:attribute></xsl:if>
				<xsl:attribute name="id">8</xsl:attribute><xsl:attribute name="len">=_temp_gatesize</xsl:attribute><xsl:if test="@pos"><xsl:attribute name="pos"><xsl:value-of select="@pos"/></xsl:attribute></xsl:if><xsl:if test="@locate"><xsl:attribute name="locate"><xsl:value-of select="@locate"/></xsl:attribute></xsl:if>
				<xsl:attribute name="path">Xsl/MultiMap.xsl</xsl:attribute>
			</xsl:element>
			<xsl:element name="CallTrans">
				<xsl:attribute name="type">move</xsl:attribute><xsl:attribute name="param">_temp_lead/_temp_m/_temp_p</xsl:attribute><xsl:if test="@to"><xsl:attribute name="to"><xsl:value-of select="@to"/></xsl:attribute></xsl:if><xsl:if test="@from"><xsl:attribute name="from"><xsl:value-of select="@from"/></xsl:attribute></xsl:if>
				<xsl:attribute name="id">9</xsl:attribute><xsl:attribute name="len">=_temp_gatesize</xsl:attribute><xsl:if test="@pos"><xsl:attribute name="pos"><xsl:value-of select="@pos"/></xsl:attribute></xsl:if><xsl:if test="@locate"><xsl:attribute name="locate"><xsl:value-of select="@locate"/></xsl:attribute></xsl:if>
				<xsl:attribute name="path">Xsl/MultiMap.xsl</xsl:attribute>
			</xsl:element>
			<xsl:element name="CallTrans">
				<xsl:attribute name="type">move</xsl:attribute><xsl:attribute name="param">_temp_lead/_temp_m/_temp_p</xsl:attribute><xsl:if test="@to"><xsl:attribute name="to"><xsl:value-of select="@to"/></xsl:attribute></xsl:if><xsl:if test="@from"><xsl:attribute name="from"><xsl:value-of select="@from"/></xsl:attribute></xsl:if>
				<xsl:attribute name="id">10</xsl:attribute><xsl:attribute name="len">=_temp_gatesize</xsl:attribute><xsl:if test="@pos"><xsl:attribute name="pos"><xsl:value-of select="@pos"/></xsl:attribute></xsl:if><xsl:if test="@locate"><xsl:attribute name="locate"><xsl:value-of select="@locate"/></xsl:attribute></xsl:if>
				<xsl:attribute name="path">Xsl/MultiMap.xsl</xsl:attribute>
			</xsl:element>
			<xsl:element name="CallTrans">
				<xsl:attribute name="type">move</xsl:attribute><xsl:attribute name="param">_temp_lead/_temp_m/_temp_p</xsl:attribute><xsl:if test="@to"><xsl:attribute name="to"><xsl:value-of select="@to"/></xsl:attribute></xsl:if><xsl:if test="@from"><xsl:attribute name="from"><xsl:value-of select="@from"/></xsl:attribute></xsl:if>
				<xsl:attribute name="id">11</xsl:attribute><xsl:attribute name="len">=_temp_gatesize</xsl:attribute><xsl:if test="@pos"><xsl:attribute name="pos"><xsl:value-of select="@pos"/></xsl:attribute></xsl:if><xsl:if test="@locate"><xsl:attribute name="locate"><xsl:value-of select="@locate"/></xsl:attribute></xsl:if>
				<xsl:attribute name="path">Xsl/MultiMap.xsl</xsl:attribute>
			</xsl:element>
		</xsl:if>
		<xsl:if test="@type = 'move'">
		<xsl:element name="State">
			<xsl:attribute name="name">=<xsl:value-of select="$leader"/>.<xsl:value-of select="@id"/></xsl:attribute>
		<xsl:element name="Range">
			<xsl:attribute name="name">=<xsl:value-of select="$leader"/>.<xsl:value-of select="@id"/></xsl:attribute>
			<xsl:attribute name="pos"><xsl:value-of select="@pos"/></xsl:attribute>
			<xsl:attribute name="length"><xsl:value-of select="@len"/></xsl:attribute>

		<xsl:element name="ChkFlg">
			<xsl:attribute name="off">mtt_inbattle</xsl:attribute>
			<xsl:element name="Param">
				<xsl:attribute name="name"><xsl:value-of select="$maploc"/>.<xsl:value-of select="@id"/></xsl:attribute>
				<xsl:attribute name="val"><xsl:value-of select="@to"/></xsl:attribute>
			</xsl:element>
			<xsl:element name="Param">
				<xsl:attribute name="name">_temp_lastmove</xsl:attribute>
				<xsl:attribute name="val">=<xsl:value-of select="$leader"/>.<xsl:value-of select="@id"/></xsl:attribute>
			</xsl:element>
			<xsl:element name="CallTrans">
				<xsl:attribute name="type">savepos</xsl:attribute>
				<xsl:attribute name="param"><xsl:value-of select="@param"/></xsl:attribute>
				<xsl:attribute name="path">Xsl/MultiMap.xsl</xsl:attribute>
			</xsl:element>
			<xsl:element name="Param">
				<xsl:attribute name="name"><xsl:value-of select="$charapos"/>.<xsl:value-of select="@id"/></xsl:attribute>
				<xsl:if test="not(@from)"><xsl:attribute name="val">=_temp_<xsl:value-of select="@to"/>pos</xsl:attribute></xsl:if>
				<xsl:if test="@from"><xsl:attribute name="val">=_temp_<xsl:value-of select="@from"/>-<xsl:value-of select="@to"/>pos</xsl:attribute></xsl:if>
			</xsl:element>
			<xsl:element name="List">
				<xsl:element name="Title">
					<xsl:attribute name="life">1</xsl:attribute>
					<xsl:attribute name="wait">1</xsl:attribute>
					<xsl:attribute name="msg">�@</xsl:attribute>
				</xsl:element>
				<xsl:element name="Event">
				<xsl:element name="Mode">
					<xsl:attribute name="mode">none</xsl:attribute>
				</xsl:element>
				<xsl:element name="Mode">
					<xsl:attribute name="mode">battle</xsl:attribute>
				</xsl:element>
				<xsl:element name="Param">
					<xsl:attribute name="name">_temp_nextpath</xsl:attribute>
					<xsl:attribute name="val">Event/</xsl:attribute>
				</xsl:element>
				<xsl:element name="Param">
					<xsl:attribute name="name">_temp_location</xsl:attribute>
					<xsl:attribute name="val"><xsl:value-of select="@locate"/></xsl:attribute>
				</xsl:element>
				<xsl:element name="Param">
					<xsl:attribute name="name">_temp_nextpath</xsl:attribute>
					<xsl:attribute name="com">+</xsl:attribute>
					<xsl:attribute name="val">=_temp_folder</xsl:attribute>
				</xsl:element>
				<xsl:element name="Param">
					<xsl:attribute name="name">_temp_nextpath</xsl:attribute>
					<xsl:attribute name="com">+</xsl:attribute>
					<xsl:attribute name="val">/<xsl:value-of select="@to"/>.xml</xsl:attribute>
				</xsl:element>
				<xsl:element name="LoadEvent">
					<xsl:attribute name="path">=_temp_nextpath</xsl:attribute>
				</xsl:element>
				</xsl:element>
			</xsl:element>
		</xsl:element>
			</xsl:element>
		</xsl:element>
		</xsl:if>
		<xsl:if test="@type = 'savepos'">

			<xsl:element name="Param">
				<xsl:attribute name="name"><xsl:value-of select="$maploc"/>.0</xsl:attribute>
				<xsl:attribute name="com">=</xsl:attribute>
				<xsl:attribute name="val">=_temp_location</xsl:attribute>
				<xsl:element name="Command">
					<xsl:attribute name="com">param/batpos/<xsl:value-of select="$charapos"/>.0/=<xsl:value-of select="$leader"/>.0</xsl:attribute>
				</xsl:element>
			</xsl:element>
			<xsl:element name="Param">
				<xsl:attribute name="name"><xsl:value-of select="$maploc"/>.1</xsl:attribute>
				<xsl:attribute name="com">=</xsl:attribute>
				<xsl:attribute name="val">=_temp_location</xsl:attribute>
				<xsl:element name="Command">
					<xsl:attribute name="com">param/batpos/<xsl:value-of select="$charapos"/>.1/=<xsl:value-of select="$leader"/>.1</xsl:attribute>
				</xsl:element>
			</xsl:element>
			<xsl:element name="Param">
				<xsl:attribute name="name"><xsl:value-of select="$maploc"/>.2</xsl:attribute>
				<xsl:attribute name="com">=</xsl:attribute>
				<xsl:attribute name="val">=_temp_location</xsl:attribute>
				<xsl:element name="Command">
					<xsl:attribute name="com">param/batpos/<xsl:value-of select="$charapos"/>.2/=<xsl:value-of select="$leader"/>.2</xsl:attribute>
				</xsl:element>
			</xsl:element>
			<xsl:element name="Param">
				<xsl:attribute name="name"><xsl:value-of select="$maploc"/>.3</xsl:attribute>
				<xsl:attribute name="com">=</xsl:attribute>
				<xsl:attribute name="val">=_temp_location</xsl:attribute>
				<xsl:element name="Command">
					<xsl:attribute name="com">param/batpos/<xsl:value-of select="$charapos"/>.3/=<xsl:value-of select="$leader"/>.3</xsl:attribute>
				</xsl:element>
			</xsl:element>
			<xsl:element name="Param">
				<xsl:attribute name="name"><xsl:value-of select="$maploc"/>.4</xsl:attribute>
				<xsl:attribute name="com">=</xsl:attribute>
				<xsl:attribute name="val">=_temp_location</xsl:attribute>
				<xsl:element name="Command">
					<xsl:attribute name="com">param/batpos/<xsl:value-of select="$charapos"/>.4/=<xsl:value-of select="$leader"/>.4</xsl:attribute>
				</xsl:element>
			</xsl:element>
			<xsl:element name="Param">
				<xsl:attribute name="name"><xsl:value-of select="$maploc"/>.5</xsl:attribute>
				<xsl:attribute name="com">=</xsl:attribute>
				<xsl:attribute name="val">=_temp_location</xsl:attribute>
				<xsl:element name="Command">
					<xsl:attribute name="com">param/batpos/<xsl:value-of select="$charapos"/>.5/=<xsl:value-of select="$leader"/>.5</xsl:attribute>
				</xsl:element>
			</xsl:element>
			<xsl:element name="Param">
				<xsl:attribute name="name"><xsl:value-of select="$maploc"/>.6</xsl:attribute>
				<xsl:attribute name="com">=</xsl:attribute>
				<xsl:attribute name="val">=_temp_location</xsl:attribute>
				<xsl:element name="Command">
					<xsl:attribute name="com">param/batpos/<xsl:value-of select="$charapos"/>.6/=<xsl:value-of select="$leader"/>.6</xsl:attribute>
				</xsl:element>
			</xsl:element>
			<xsl:element name="Param">
				<xsl:attribute name="name"><xsl:value-of select="$maploc"/>.7</xsl:attribute>
				<xsl:attribute name="com">=</xsl:attribute>
				<xsl:attribute name="val">=_temp_location</xsl:attribute>
				<xsl:element name="Command">
					<xsl:attribute name="com">param/batpos/<xsl:value-of select="$charapos"/>.7/=<xsl:value-of select="$leader"/>.7</xsl:attribute>
				</xsl:element>
			</xsl:element>
			<xsl:element name="Param">
				<xsl:attribute name="name"><xsl:value-of select="$maploc"/>.8</xsl:attribute>
				<xsl:attribute name="com">=</xsl:attribute>
				<xsl:attribute name="val">=_temp_location</xsl:attribute>
				<xsl:element name="Command">
					<xsl:attribute name="com">param/batpos/<xsl:value-of select="$charapos"/>.8/=<xsl:value-of select="$leader"/>.8</xsl:attribute>
				</xsl:element>
			</xsl:element>
			<xsl:element name="Param">
				<xsl:attribute name="name"><xsl:value-of select="$maploc"/>.9</xsl:attribute>
				<xsl:attribute name="com">=</xsl:attribute>
				<xsl:attribute name="val">=_temp_location</xsl:attribute>
				<xsl:element name="Command">
					<xsl:attribute name="com">param/batpos/<xsl:value-of select="$charapos"/>.9/=<xsl:value-of select="$leader"/>.9</xsl:attribute>
				</xsl:element>
			</xsl:element>
			<xsl:element name="Param">
				<xsl:attribute name="name"><xsl:value-of select="$maploc"/>.10</xsl:attribute>
				<xsl:attribute name="com">=</xsl:attribute>
				<xsl:attribute name="val">=_temp_location</xsl:attribute>
				<xsl:element name="Command">
					<xsl:attribute name="com">param/batpos/<xsl:value-of select="$charapos"/>.10/=<xsl:value-of select="$leader"/>.10</xsl:attribute>
				</xsl:element>
			</xsl:element>
			<xsl:element name="Param">
				<xsl:attribute name="name"><xsl:value-of select="$maploc"/>.11</xsl:attribute>
				<xsl:attribute name="com">=</xsl:attribute>
				<xsl:attribute name="val">=_temp_location</xsl:attribute>
				<xsl:element name="Command">
					<xsl:attribute name="com">param/batpos/<xsl:value-of select="$charapos"/>.11/=<xsl:value-of select="$leader"/>.11</xsl:attribute>
				</xsl:element>
			</xsl:element>
		</xsl:if>
	</xsl:element>

</xsl:template>

</xsl:stylesheet>
