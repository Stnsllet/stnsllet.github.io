<?xml version="1.0" encoding="Shift_JIS"?>
<xsl:stylesheet xmlns:xsl="http://www.w3.org/1999/XSL/Transform" version="1.0"  xmlns:spibre="http://geroha.ld.infoseek.co.jp/spibre/">
<xsl:output method="xml" version="1.0" encoding="Shift_JIS" indent="yes" />
<xsl:param name="_temp_list"/>
<xsl:param name="_temp_path"/>

<xsl:template match="CallTrans">
	<xsl:element name="CallTrans">
		<xsl:attribute name="path"><xsl:value-of select="$_temp_path"/></xsl:attribute>
		<xsl:copy-of select="child"/>
		<xsl:value-of select="$_temp_list" disable-output-escaping="yes"/>
	</xsl:element>
</xsl:template>


</xsl:stylesheet>
