<?xml version="1.0" encoding="Shift_JIS"?>
<xsl:stylesheet xmlns:xsl="http://www.w3.org/1999/XSL/Transform" version="1.0" xmlns:spibre="a">
<xsl:output method="xml" version="1.0" encoding="Shift_JIS" indent="yes" />

<xsl:param name="_temp_paty"/>

<xsl:template match="CallTrans">
	<xsl:variable name="params" select="@params"/>
	<xsl:variable name="type" select="@type"/>
	<xsl:variable name="paty" select="$_temp_paty"/>
	<xsl:element name="Delay">
		<xsl:attribute name="time">1</xsl:attribute>
			<xsl:element name="Param">
				<xsl:attribute name="name">_temp_EnemyTeamA</xsl:attribute>
				<xsl:attribute name="val"><xsl:value-of select="$paty"/></xsl:attribute>
			</xsl:element>
			<xsl:choose>
				<xsl:when test="$type = '1'">
					<xsl:element name="Param">
						<xsl:attribute name="name">_temp_EnemyTeamT</xsl:attribute>
						<xsl:attribute name="val"><xsl:value-of select="$paty"/></xsl:attribute>
					</xsl:element>
				</xsl:when>
			</xsl:choose>
			<xsl:element name="Param">
				<xsl:attribute name="name">_temp_func</xsl:attribute>
				<xsl:attribute name="val">ExLevel</xsl:attribute>
			</xsl:element>
			<xsl:element name="LoadEvent">
				<xsl:attribute name="path">Event/Tournament/Common/NameChange.xml</xsl:attribute>
			</xsl:element>
			<xsl:element name="Window">
			<xsl:choose>
				<xsl:when test="$type = '2'">
				<xsl:attribute name="x">50</xsl:attribute>
				<xsl:attribute name="y">28</xsl:attribute>
				<xsl:attribute name="w">190</xsl:attribute>
				<xsl:attribute name="h">60</xsl:attribute>
				<xsl:attribute name="name">NowSelect</xsl:attribute>
				<xsl:attribute name="lock">0</xsl:attribute>
				</xsl:when>
				<xsl:when test="$type != '2'">
				<xsl:attribute name="x">50</xsl:attribute>
				<xsl:attribute name="y">27</xsl:attribute>
				<xsl:attribute name="w">190</xsl:attribute>
				<xsl:attribute name="h">70</xsl:attribute>
				<xsl:attribute name="name">NowSelect</xsl:attribute>
				<xsl:attribute name="lock">0</xsl:attribute>
				</xsl:when>
			</xsl:choose>
				<xsl:choose>
					<xsl:when test="$type != '2'">
						<xsl:element name="Plane">
							<xsl:attribute name="x">6</xsl:attribute>
							<xsl:attribute name="y">6</xsl:attribute>
							<xsl:attribute name="name">VS</xsl:attribute>
						</xsl:element>
					</xsl:when>
					<xsl:when test="$type = '2'">
						<xsl:element name="Plane">
							<xsl:attribute name="x">6</xsl:attribute>
							<xsl:attribute name="y">6</xsl:attribute>
							<xsl:attribute name="name">����I</xsl:attribute>
						</xsl:element>
					</xsl:when>
				</xsl:choose>
				<xsl:choose>
					<xsl:when test="$type = '0'">
						<xsl:element name="Plane">
							<xsl:attribute name="x">30</xsl:attribute>
							<xsl:attribute name="y">6</xsl:attribute>
							<xsl:attribute name="name">=_temp_EnemyTeamNameA</xsl:attribute>
						</xsl:element>
					</xsl:when>
					<xsl:when test="$type = '1'">
						<xsl:element name="Plane">
							<xsl:attribute name="x">30</xsl:attribute>
							<xsl:attribute name="y">6</xsl:attribute>
							<xsl:attribute name="name">=_temp_EnemyTeamNameT</xsl:attribute>
						</xsl:element>
					</xsl:when>
					<xsl:when test="$type = '2'">
						<xsl:element name="Plane">
							<xsl:attribute name="x">52</xsl:attribute>
							<xsl:attribute name="y">6</xsl:attribute>
							<xsl:attribute name="name">=_temp_EnemyTeamNameA</xsl:attribute>
						</xsl:element>
					</xsl:when>
				</xsl:choose>
				<xsl:choose>
					<xsl:when test="$type != '2'">
						<xsl:element name="Plane">
							<xsl:attribute name="x">30</xsl:attribute>
							<xsl:attribute name="y">50</xsl:attribute>
							<xsl:attribute name="name">����</xsl:attribute>
							<xsl:attribute name="event">Event/Tournament/Common/Check.xml</xsl:attribute>
						</xsl:element>
						<xsl:element name="Plane">
							<xsl:attribute name="x">130</xsl:attribute>
							<xsl:attribute name="y">50</xsl:attribute>
							<xsl:attribute name="name">�߂�</xsl:attribute>
							<xsl:attribute name="event">Event/Tournament/System.xml</xsl:attribute>
						</xsl:element>
						<xsl:element name="Plane">
							<xsl:attribute name="x">35</xsl:attribute>
							<xsl:attribute name="y">30</xsl:attribute>
							<xsl:attribute name="name">��</xsl:attribute>
							<xsl:attribute name="event">Event/Tournament/Common/Function.xml</xsl:attribute>
							<xsl:attribute name="com">param/rnd/_temp_Exlevel/0</xsl:attribute>
						</xsl:element>
						<xsl:element name="Plane">
							<xsl:attribute name="x">28</xsl:attribute>
							<xsl:attribute name="y">30</xsl:attribute>
							<xsl:attribute name="name">[ �@]</xsl:attribute>
							<xsl:attribute name="on">tor_ExEasy</xsl:attribute>
						</xsl:element>
						<xsl:element name="Plane">
							<xsl:attribute name="x">85</xsl:attribute>
							<xsl:attribute name="y">30</xsl:attribute>
							<xsl:attribute name="name">��</xsl:attribute>
							<xsl:attribute name="event">Event/Tournament/Common/Function.xml</xsl:attribute>
							<xsl:attribute name="com">param/rnd/_temp_Exlevel/1</xsl:attribute>
						</xsl:element>
						<xsl:element name="Plane">
							<xsl:attribute name="x">78</xsl:attribute>
							<xsl:attribute name="y">30</xsl:attribute>
							<xsl:attribute name="name">[ �@]</xsl:attribute>
							<xsl:attribute name="on">tor_ExNormal</xsl:attribute>
						</xsl:element>
						<xsl:element name="Plane">
							<xsl:attribute name="x">135</xsl:attribute>
							<xsl:attribute name="y">30</xsl:attribute>
							<xsl:attribute name="name">��</xsl:attribute>
							<xsl:attribute name="event">Event/Tournament/Common/Function.xml</xsl:attribute>
							<xsl:attribute name="com">param/rnd/_temp_Exlevel/2</xsl:attribute>
						</xsl:element>
						<xsl:element name="Plane">
							<xsl:attribute name="x">128</xsl:attribute>
							<xsl:attribute name="y">30</xsl:attribute>
							<xsl:attribute name="name">[ �@]</xsl:attribute>
							<xsl:attribute name="on">tor_ExHard</xsl:attribute>
						</xsl:element>
					</xsl:when>
					<xsl:when test="$type = '2'">
						<xsl:element name="Plane">
							<xsl:attribute name="x">30</xsl:attribute>
							<xsl:attribute name="y">30</xsl:attribute>
							<xsl:attribute name="name">����</xsl:attribute>
							<xsl:attribute name="event">Event/Tournament/Common/Check.xml</xsl:attribute>
						</xsl:element>
						<xsl:element name="Plane">
							<xsl:attribute name="x">130</xsl:attribute>
							<xsl:attribute name="y">30</xsl:attribute>
							<xsl:attribute name="name">�߂�</xsl:attribute>
							<xsl:attribute name="event">Event/Tournament/System.xml</xsl:attribute>
						</xsl:element>
					</xsl:when>
				</xsl:choose>

			</xsl:element>
		</xsl:element>

</xsl:template>

</xsl:stylesheet>
