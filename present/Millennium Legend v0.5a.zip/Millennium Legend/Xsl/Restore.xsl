<?xml version="1.0" encoding="Shift_JIS"?>

<xsl:stylesheet xmlns:xsl="http://www.w3.org/1999/XSL/Transform" version="1.0">
<xsl:output method="xml" version="1.0" encoding="Shift_JIS" indent="yes" />
<xsl:param name="_temp_time"/>

<xsl:template match="CallTrans">
	<xsl:variable name="name" select="@name"/>
	<xsl:variable name="lev" select="@lev"/>
	<xsl:variable name="job" select="@job"/>
	<xsl:variable name="wep" select="@wep"/>
	<xsl:variable name="body" select="@body"/>
	<xsl:variable name="acs" select="@acs"/>
	<xsl:variable name="kill" select="@kill"/>

	<xsl:element name="Event">
		<xsl:element name="Command">
			<xsl:attribute name="com">param/member/_temp_level/<xsl:value-of select="$name"/>/level</xsl:attribute>
		</xsl:element>
		<xsl:element name="Command">
			<xsl:attribute name="com">param/member/_temp_job/<xsl:value-of select="$name"/>/job</xsl:attribute>
		</xsl:element>
		<xsl:element name="Command">
			<xsl:attribute name="com">param/member/_temp_wep/<xsl:value-of select="$name"/>/wep</xsl:attribute>
		</xsl:element>
		<xsl:element name="Command">
			<xsl:attribute name="com">param/member/_temp_body/<xsl:value-of select="$name"/>/body</xsl:attribute>
		</xsl:element>
		<xsl:element name="Command">
			<xsl:attribute name="com">param/member/_temp_acs/<xsl:value-of select="$name"/>/acs</xsl:attribute>
		</xsl:element>
		<xsl:element name="Command">
			<xsl:attribute name="com">param/member/_temp_kill/<xsl:value-of select="$name"/>/kill</xsl:attribute>
		</xsl:element>

		<xsl:if test="$lev!=''">
		<xsl:element name="Param">
			<xsl:attribute name="name">_temp_level</xsl:attribute>
			<xsl:attribute name="val"><xsl:value-of select="$lev"/></xsl:attribute>
		</xsl:element>
		</xsl:if>
		<xsl:if test="$wep!=''">
		<xsl:element name="Param">
			<xsl:attribute name="name">_temp_wep</xsl:attribute>
			<xsl:attribute name="val"><xsl:value-of select="$wep"/></xsl:attribute>
		</xsl:element>
		</xsl:if>
		<xsl:if test="$body!=''">
		<xsl:element name="Param">
			<xsl:attribute name="name">_temp_body</xsl:attribute>
			<xsl:attribute name="val"><xsl:value-of select="$body"/></xsl:attribute>
		</xsl:element>
		</xsl:if>
		<xsl:if test="$acs!=''">
		<xsl:element name="Param">
			<xsl:attribute name="name">_temp_acs</xsl:attribute>
			<xsl:attribute name="val"><xsl:value-of select="$acs"/></xsl:attribute>
		</xsl:element>
		</xsl:if>
		<xsl:if test="$kill!=''">
		<xsl:element name="Param">
			<xsl:attribute name="name">_temp_kill</xsl:attribute>
			<xsl:attribute name="val"><xsl:value-of select="$kill"/></xsl:attribute>
		</xsl:element>
		</xsl:if>
		<xsl:if test="$job!=''">
		<xsl:element name="Param">
			<xsl:attribute name="name">_temp_job</xsl:attribute>
			<xsl:attribute name="val"><xsl:value-of select="$job"/></xsl:attribute>
		</xsl:element>
		</xsl:if>


		<xsl:element name="Paty">
			<xsl:attribute name="army">user</xsl:attribute>
			<xsl:element name="Member">
				<xsl:attribute name="lev">=_temp_level</xsl:attribute>
				<xsl:attribute name="pason"><xsl:value-of select="$name"/></xsl:attribute>
				<xsl:attribute name="job">=_temp_job</xsl:attribute>
				<xsl:attribute name="wep">=_temp_wep</xsl:attribute>
				<xsl:attribute name="body">=_temp_body</xsl:attribute>
				<xsl:attribute name="acs">=_temp_acs</xsl:attribute>
				<xsl:element name="Status">
					<xsl:attribute name="kill">=_temp_kill</xsl:attribute>
				</xsl:element>
			</xsl:element>
		</xsl:element>
	</xsl:element>
</xsl:template>


</xsl:stylesheet>
