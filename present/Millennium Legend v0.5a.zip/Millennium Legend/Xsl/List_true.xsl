<?xml version="1.0" encoding="Shift_JIS"?>
<xsl:stylesheet xmlns:xsl="http://www.w3.org/1999/XSL/Transform" version="1.0"  xmlns:spibre="http://geraha.ld.infoseek.co.jp/spibre/">
<xsl:output method="xml" version="1.0" encoding="Shift_JIS" indent="yes" />

<xsl:param name="_temp_list"/>
<xsl:param name="_temp_iterator"/>

<msxsl:script xmlns:msxsl="urn:schemas-microsoft-com:xslt" language="JavaScript" implements-prefix="spibre">
  function getNode(list,com){
	var array = list.split('/');
   	return(array[com]);
  }
  function getLength(list){
	var array = list.split('/');
   	return(array.length);
  }
</msxsl:script>

<xsl:template match="CallTrans">

	<xsl:element name="List">
		<xsl:element name="Param">
			<xsl:attribute name="name">_temp_length</xsl:attribute>
			<xsl:attribute name="val"><xsl:value-of select="spibre:getLength($_temp_list)"/></xsl:attribute>
		</xsl:element>
		<xsl:element name="Param">
			<xsl:attribute name="name">_temp_iterator</xsl:attribute>
			<xsl:attribute name="com">ld</xsl:attribute>
			<xsl:attribute name="val">=_temp_length</xsl:attribute>

			<xsl:choose>
				<xsl:when test="@type = 'Param'">
					<xsl:element name="Param">
						<xsl:attribute name="name">_temp_readlist</xsl:attribute>
						<xsl:attribute name="val"><xsl:value-of select="spibre:getNode($_temp_list,$_temp_iterator)"/></xsl:attribute>
						<xsl:element name="Param">
							<xsl:attribute name="name">=_temp_readlist</xsl:attribute>
							<xsl:attribute name="val"><xsl:value-of select="@val"/></xsl:attribute>
						</xsl:element>
					</xsl:element>
				</xsl:when>
				<xsl:when test="@type = 'Param_l'">
					<xsl:element name="Param">
						<xsl:attribute name="name"><xsl:value-of select="@name"/></xsl:attribute>
						<xsl:attribute name="val"><xsl:value-of select="spibre:getNode($_temp_list,$_temp_iterator)"/></xsl:attribute>
						<xsl:element name="Param">
							<xsl:attribute name="name"><xsl:value-of select="@name"/></xsl:attribute>
							<xsl:attribute name="com">=</xsl:attribute>
							<xsl:attribute name="val">=<xsl:value-of select="@val"/></xsl:attribute>
							<xsl:element name="Param">
								<xsl:attribute name="name">_temp_strbool</xsl:attribute>
								<xsl:attribute name="val">true</xsl:attribute>
							</xsl:element>
						</xsl:element>
					</xsl:element>
				</xsl:when>
				<xsl:when test="@type = 'Param_v'">
					<xsl:element name="Param">
						<xsl:attribute name="name"><xsl:value-of select="@name"/></xsl:attribute>
						<xsl:attribute name="val"><xsl:value-of select="spibre:getNode($_temp_list,$_temp_iterator)"/></xsl:attribute>
						<xsl:element name="Param">
							<xsl:attribute name="name"><xsl:value-of select="@name"/></xsl:attribute>
							<xsl:attribute name="com">=</xsl:attribute>
							<xsl:attribute name="val"><xsl:value-of select="@val"/></xsl:attribute>
							<xsl:element name="Param">
								<xsl:attribute name="name">_temp_strbool</xsl:attribute>
								<xsl:attribute name="val">true</xsl:attribute>
							</xsl:element>
						</xsl:element>
					</xsl:element>
				</xsl:when>
				<xsl:when test="1">
					<xsl:element name="Param">
						<xsl:attribute name="name"><xsl:value-of select="@name"/></xsl:attribute>
						<xsl:attribute name="val"><xsl:value-of select="spibre:getNode($_temp_list,$_temp_iterator)"/></xsl:attribute>
						<xsl:apply-templates />
					</xsl:element>
				</xsl:when>
			</xsl:choose>


			<xsl:element name="Param">
				<xsl:attribute name="name">_temp_iterator</xsl:attribute>
				<xsl:attribute name="com">+</xsl:attribute>
				<xsl:attribute name="val">1</xsl:attribute>
			</xsl:element>
			<xsl:element name="Param">
				<xsl:attribute name="name">_temp_iterator</xsl:attribute>
				<xsl:attribute name="com">ld</xsl:attribute>
				<xsl:attribute name="val">=_temp_limitlist</xsl:attribute>
				<xsl:element name="CallTrans">
					<xsl:attribute name="name"><xsl:value-of select="@name"/></xsl:attribute>
					<xsl:attribute name="type"><xsl:value-of select="@type"/></xsl:attribute>
					<xsl:attribute name="val"><xsl:value-of select="@val"/></xsl:attribute>
					<xsl:attribute name="params">_temp_list/_temp_iterator</xsl:attribute>
					<xsl:attribute name="path">Xsl/List.xsl</xsl:attribute>
					<xsl:element name="Event"><xsl:apply-templates /></xsl:element>
				</xsl:element>
			</xsl:element>
		</xsl:element>

	</xsl:element>
</xsl:template>

<xsl:template match="*">
	<xsl:copy-of select="."/>
</xsl:template>

</xsl:stylesheet>

