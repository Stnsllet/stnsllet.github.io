<?xml version="1.0" encoding="Shift_JIS"?>
<xsl:stylesheet xmlns:xsl="http://www.w3.org/1999/XSL/Transform" version="1.0"  xmlns:sys="https://stnsllet.github.io/">
<xsl:output method="xml" version="1.0" encoding="Shift_JIS" indent="yes" />
<xsl:param name="_temp_state_name"/>
<xsl:param name="_temp_state_id"/>
<xsl:param name="_temp_state_hp"/>
<xsl:param name="_temp_state_mp"/>
<xsl:param name="_temp_state_act"/>
<xsl:param name="_temp_state_special"/>
<xsl:param name="_temp_state_ex"/>

<xsl:template match="CallTrans">
	<xsl:element name="List">
		<xsl:element name="State">
			<xsl:attribute name="name"><xsl:value-of select="$_temp_state_name"/></xsl:attribute>
			<xsl:attribute name="id"><xsl:value-of select="$_temp_state_id"/></xsl:attribute>
			<xsl:attribute name="hp"><xsl:value-of select="$_temp_state_hp"/></xsl:attribute>
			<xsl:attribute name="mp"><xsl:value-of select="$_temp_state_mp"/></xsl:attribute>
			<xsl:attribute name="act"><xsl:value-of select="$_temp_state_act"/></xsl:attribute>
			<xsl:attribute name="special"><xsl:value-of select="$_temp_state_special"/></xsl:attribute>
			<xsl:element name="Param">
				<xsl:attribute name="name">_temp_sys_slastex</xsl:attribute>
				<xsl:attribute name="val"><xsl:value-of select="$_temp_state_ex"/></xsl:attribute>
			</xsl:element>
			<xsl:element name="Param">
				<xsl:attribute name="name">_temp_sys_laststate</xsl:attribute>
				<xsl:attribute name="val"><xsl:value-of select="$_temp_state_name"/></xsl:attribute>
				<xsl:apply-templates/>
			</xsl:element>
		</xsl:element>
	</xsl:element>
</xsl:template>

<xsl:template match="*">
	<xsl:copy-of select="."/>
</xsl:template>

</xsl:stylesheet>
