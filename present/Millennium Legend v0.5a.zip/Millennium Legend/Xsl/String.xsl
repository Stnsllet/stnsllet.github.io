<?xml version="1.0" encoding="Shift_JIS"?>
<xsl:stylesheet xmlns:xsl="http://www.w3.org/1999/XSL/Transform" version="1.0" xmlns:spibre="a">
<xsl:output method="xml" version="1.0" encoding="Shift_JIS" indent="yes" />

<xsl:param name="_temp_str"/>
<xsl:param name="_temp_strval"/>

<msxsl:script xmlns:msxsl="urn:schemas-microsoft-com:xslt" language="JavaScript" implements-prefix="spibre">
function addChars( targetNum, setFigure, setChar ) {
	var targetFigure = String(targetNum).length;
	var addZeros = "";

	for( var i=0 ; i &lt; (setFigure - targetFigure) ; i++ ) {
      		addZeros += setChar;
    	}
	return (""+addZeros + targetNum);
  }
function bit2( targetNum ) {
	var targetFigure = String(targetNum).length;
	if(targetFigure==1){return ("0"+targetNum);}
	return (targetNum);
  }

function add(src,adds) {
	var input = parseInt(src);
	var opera = parseInt(adds);
	return (input | opera).toString(10);
}

function sub(src,subs) {
	var input = parseInt(src);
	var opera = parseInt(subs);
	return (input &amp; ~opera).toString(10);
}

function or(src,ors) {
	var input = parseInt(src);
	var opera = parseInt(ors);
	if(input &amp; opera)return true;
	else return false;
}

function spliter(outputlist,inputlist){
	var ret = '&lt;Event&gt;';
	var output = outputlist.split('/');
	var input = inputlist.split('/');
 
	for (i = 0; i &lt; output.length; i++) {
		j = i;
		if (j &gt;= input.length){
			j = input.length-1;
		}
		ret = ret + '&lt;Param name=&quot;' + output[i] + '&quot; val=&quot;' + input[j] + '&quot;/&gt;';
	}
	ret = ret + '&lt;/Event&gt;';
	return ret;
}

</msxsl:script>

<xsl:template match="CallTrans">
	<xsl:variable name="params" select="@params"/>
	<xsl:variable name="val" select="$_temp_strval"/>
	<xsl:variable name="type" select="@type"/>
	<xsl:variable name="f" select="$_temp_str"/>
  	<xsl:if test="$type = 'contains'">
		<xsl:if test="contains($f, $val)">
		<xsl:element name="Param">
			<xsl:attribute name="name">_temp_strbool</xsl:attribute>
			<xsl:attribute name="val">true</xsl:attribute>
		</xsl:element>
		</xsl:if>
	</xsl:if>
  	<xsl:if test="$type = 'uncontains'">
		<xsl:if test="not(contains($f, $val))">
		<xsl:element name="Param">
			<xsl:attribute name="name">_temp_strbool</xsl:attribute>
			<xsl:attribute name="val">true</xsl:attribute>
		</xsl:element>
		</xsl:if>
	</xsl:if>

  	<xsl:if test="$type = 'add'">
		<xsl:element name="Param">
			<xsl:attribute name="name">_temp_strbool</xsl:attribute>
			<xsl:attribute name="val"><xsl:value-of select="spibre:add($f,$val)"/></xsl:attribute>
		</xsl:element>
	</xsl:if>
  	<xsl:if test="$type = 'sub'">
		<xsl:element name="Param">
			<xsl:attribute name="name">_temp_strbool</xsl:attribute>
			<xsl:attribute name="val"><xsl:value-of select="spibre:sub($f,$val)"/></xsl:attribute>
		</xsl:element>
	</xsl:if>
  	<xsl:if test="$type = 'or'">
		<xsl:element name="Param">
			<xsl:attribute name="name">_temp_strbool</xsl:attribute>
			<xsl:attribute name="val"><xsl:value-of select="spibre:or($f,$val)"/></xsl:attribute>
		</xsl:element>
	</xsl:if>

  	<xsl:if test="$type = 'length'">
		<xsl:element name="Param">
			<xsl:attribute name="name">_temp_strval</xsl:attribute>
			<xsl:attribute name="val"><xsl:value-of select="string-length($f)"/></xsl:attribute>
		</xsl:element>
	</xsl:if>

  	<xsl:if test="$type = 'pointer'">
		<xsl:element name="Param">
			<xsl:attribute name="name">_temp_strbool</xsl:attribute>
			<xsl:attribute name="val">=<xsl:value-of select="$f"/></xsl:attribute>
		</xsl:element>
	</xsl:if>

  	<xsl:if test="$type = 'split'">
	  	<xsl:value-of select="spibre:spliter($f,$val)" disable-output-escaping="yes"/>
	</xsl:if>

  	<xsl:if test="$type = 'num_right'">
		<xsl:element name="Event">
		<xsl:element name="Param">
			<xsl:attribute name="name"><xsl:value-of select="@params"/></xsl:attribute>
			<xsl:attribute name="val"></xsl:attribute>
		</xsl:element>
		<xsl:element name="Param">
			<xsl:attribute name="name"><xsl:value-of select="@params"/></xsl:attribute>
			<xsl:attribute name="com">+</xsl:attribute>
			<xsl:attribute name="val"><xsl:value-of select="spibre:addChars($f,8,'  ')"/></xsl:attribute>
		</xsl:element>
		</xsl:element>
	</xsl:if>
  	<xsl:if test="$type = '2bit'">
		<xsl:element name="Event">
			<xsl:element name="Param">
				<xsl:attribute name="name">_temp_temps</xsl:attribute>
				<xsl:attribute name="val">=<xsl:value-of select="@params"/></xsl:attribute>
			</xsl:element>
		<xsl:element name="Param">
			<xsl:attribute name="name"><xsl:value-of select="@params"/></xsl:attribute>
			<xsl:attribute name="com">ld</xsl:attribute>
			<xsl:attribute name="val">11</xsl:attribute>
			<xsl:element name="Param">
				<xsl:attribute name="name">_temp_haves</xsl:attribute>
				<xsl:attribute name="val"></xsl:attribute>
			</xsl:element>
			<xsl:element name="Param">
				<xsl:attribute name="name">_temp_haves</xsl:attribute>
				<xsl:attribute name="com">+</xsl:attribute>
				<xsl:attribute name="val">0</xsl:attribute>
			</xsl:element>
			<xsl:element name="Param">
				<xsl:attribute name="name">_temp_haves</xsl:attribute>
				<xsl:attribute name="com">+</xsl:attribute>
				<xsl:attribute name="val">=_temp_temps</xsl:attribute>
			</xsl:element>
		</xsl:element>
			<xsl:element name="Param">
				<xsl:attribute name="name"><xsl:value-of select="@params"/></xsl:attribute>
				<xsl:attribute name="val"></xsl:attribute>
			</xsl:element>
			<xsl:element name="Param">
				<xsl:attribute name="name"><xsl:value-of select="@params"/></xsl:attribute>
				<xsl:attribute name="com">+</xsl:attribute>
				<xsl:attribute name="val">=_temp_haves</xsl:attribute>
			</xsl:element>
		</xsl:element>
	</xsl:if>
</xsl:template>

</xsl:stylesheet>
