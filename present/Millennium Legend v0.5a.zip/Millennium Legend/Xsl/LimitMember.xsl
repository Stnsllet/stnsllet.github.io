<?xml version="1.0" encoding="Shift_JIS"?>
<xsl:stylesheet xmlns:xsl="http://www.w3.org/1999/XSL/Transform" version="1.0"  xmlns:spibre="http://geroha.ld.infoseek.co.jp/spibre/">
<xsl:output method="xml" version="1.0" encoding="Shift_JIS" indent="yes" />
<xsl:param name="_temp_count">1</xsl:param>

<xsl:template match="CallTrans">
	<xsl:apply-templates />
</xsl:template>

<xsl:template match="Paty">
	<xsl:copy>
		<xsl:for-each select="@*">
			<xsl:copy />
		</xsl:for-each>
		<xsl:for-each select="Member">
			<xsl:if test="position() &lt;= $_temp_count"><xsl:copy-of select="."/></xsl:if>
		</xsl:for-each>
    </xsl:copy>
</xsl:template>

<xsl:template match="*">
	<xsl:copy-of select="."/>
</xsl:template>

</xsl:stylesheet>
