<?xml version="1.0" encoding="Shift_JIS"?>
<xsl:stylesheet xmlns:xsl="http://www.w3.org/1999/XSL/Transform" version="1.0"  xmlns:spibre="http://geroha.ld.infoseek.co.jp/spibre/">
<xsl:output method="xml" version="1.0" encoding="Shift_JIS" indent="yes" />
<xsl:param name="_temp_gauge1"/>
<xsl:param name="_temp_gauge2"/>
<xsl:param name="_temp_gauge3"/>
<xsl:param name="_temp_gauge4"/>

<xsl:template match="CallTrans">

<xsl:element name="Event">
	<xsl:if test="@type = 'batin'">
		<xsl:element name="Param">
			<xsl:attribute name="name">_temp_battlein</xsl:attribute>
			<xsl:attribute name="val">Event/Common/BattleIn.xml</xsl:attribute>
		</xsl:element>
		<xsl:if test="@file">
			<xsl:element name="Param">
				<xsl:attribute name="name">_temp_battlein</xsl:attribute>
				<xsl:attribute name="val">Event/Common/<xsl:value-of select="@file"/>.xml</xsl:attribute>
			</xsl:element>
		</xsl:if>
		<xsl:element name="Param">
			<xsl:attribute name="name">_temp_batwindow</xsl:attribute>
			<xsl:attribute name="val">BattleWindows</xsl:attribute>
		</xsl:element>
		<xsl:element name="LoadEvent">
			<xsl:attribute name="path">=_temp_battlein</xsl:attribute>
		</xsl:element>
	</xsl:if>

	<xsl:if test="@type = 'load'">
		<xsl:if test="@file">
		<xsl:element name="Param">
			<xsl:attribute name="name">_temp_sclastcallpath</xsl:attribute>
			<xsl:attribute name="val">Event/Mission/<xsl:value-of select="@file"/>.xml</xsl:attribute>
		</xsl:element>
		<xsl:element name="LoadEvent">
			<xsl:attribute name="path">Event/Mission/<xsl:value-of select="@file"/>.xml</xsl:attribute>
		</xsl:element>
		</xsl:if>
	</xsl:if>

	<xsl:if test="@type = 'clear'">
		<xsl:element name="List">
		<xsl:element name="Title">
			<xsl:attribute name="show">cutin</xsl:attribute>
			<xsl:attribute name="msg">Clear�I</xsl:attribute>
			<xsl:attribute name="wait">1</xsl:attribute>
			<xsl:attribute name="xml:space">preserve</xsl:attribute>
		</xsl:element>
		<xsl:element name="Event">
			<xsl:attribute name="flg">=_temp_misselect</xsl:attribute>
		</xsl:element>
		<xsl:element name="Param">
			<xsl:attribute name="name">_temp_StaRe</xsl:attribute>
			<xsl:attribute name="val">=_temp_misselect</xsl:attribute>
		</xsl:element>
		<xsl:element name="Param">
			<xsl:attribute name="name">_temp_sclastcallpath</xsl:attribute>
			<xsl:attribute name="val">Start</xsl:attribute>
		</xsl:element>

		<xsl:element name="CallTrans">
			<xsl:attribute name="file">Start</xsl:attribute>
			<xsl:attribute name="path">=SC</xsl:attribute>
			<xsl:element name="Common">
				<xsl:attribute name="path">Bonus</xsl:attribute>
			</xsl:element>
			<xsl:element name="UserData">
				<xsl:element name="Get">
					<xsl:attribute name="result">1</xsl:attribute>
				</xsl:element>
			</xsl:element>

			<xsl:element name="Event">
				<xsl:attribute name="path">Mission/MissionSelect.xml</xsl:attribute>
			</xsl:element>
		</xsl:element>
		</xsl:element>
	</xsl:if>

	<xsl:if test="@type = 'start'">
		<xsl:element name="List">
		<xsl:element name="ZoomIn">
			<xsl:attribute name="zoom">1.2</xsl:attribute>
			<xsl:attribute name="angle">30</xsl:attribute>
			<xsl:attribute name="pos"><xsl:value-of select="@pos"/></xsl:attribute>
		</xsl:element>
		<xsl:element name="Title">
			<xsl:attribute name="xml:space">preserve</xsl:attribute>
			<xsl:attribute name="wait">1</xsl:attribute>
			<xsl:attribute name="show">mist</xsl:attribute>
			<xsl:attribute name="msg"> Ready�E�E�E�H </xsl:attribute>
		</xsl:element>
		<xsl:element name="ZoomIn">
			<xsl:attribute name="zoom">1.2</xsl:attribute>
			<xsl:attribute name="angle">30</xsl:attribute>
			<xsl:attribute name="name"><xsl:value-of select="@name"/></xsl:attribute>
		</xsl:element>
		<xsl:element name="LoadEvent">
			<xsl:attribute name="path">Event/Common/TimeAttack.xml</xsl:attribute>
		</xsl:element>
		<xsl:element name="Title">
			<xsl:attribute name="xml:space">preserve</xsl:attribute>
			<xsl:attribute name="wait">1</xsl:attribute>
			<xsl:attribute name="show">old</xsl:attribute>
			<xsl:attribute name="msg"> Mission Start�I </xsl:attribute>
		</xsl:element>
		<xsl:element name="Param">
			<xsl:attribute name="name">_temp_stageparamname</xsl:attribute>
			<xsl:attribute name="val">Mis</xsl:attribute>		
		</xsl:element>
		<xsl:element name="Param">
			<xsl:attribute name="name">_temp_stageparamname</xsl:attribute>
			<xsl:attribute name="com">+</xsl:attribute>
			<xsl:attribute name="val">=_temp_Stagename</xsl:attribute>
		</xsl:element>
		<xsl:element name="Param">
			<xsl:attribute name="name">_temp_stageparamname</xsl:attribute>
			<xsl:attribute name="com">+</xsl:attribute>
			<xsl:attribute name="val">Time</xsl:attribute>		
		</xsl:element>
		<xsl:element name="Timer">
			<xsl:attribute name="time">100</xsl:attribute>
			<xsl:attribute name="cycle">-1</xsl:attribute>
			<xsl:element name="Param">
				<xsl:attribute name="name">=_temp_stageparamname</xsl:attribute>
				<xsl:attribute name="com">+</xsl:attribute>
				<xsl:attribute name="val">0.1</xsl:attribute>	
			</xsl:element>
		</xsl:element>
		</xsl:element>
	</xsl:if>
	<xsl:if test="@type = 'retry'">
	<xsl:element name="Msg">
		<xsl:attribute name="msg">���g���C���܂����H</xsl:attribute>
		<xsl:element name="Com">
			<xsl:attribute name="msg">�E�͂�</xsl:attribute>
		 <xsl:element name="List">
		     <xsl:element name="Event">
			<xsl:element name="Mode">
				<xsl:attribute name="mode">none</xsl:attribute>
			</xsl:element>
			<xsl:element name="Mode">
				<xsl:attribute name="mode">battle</xsl:attribute>
			</xsl:element>
			<xsl:element name="LoadEvent">
				<xsl:attribute name="path">Event/Mission/Common/MissionLoad.xml</xsl:attribute>
			</xsl:element>
		     </xsl:element>
		  </xsl:element>
		</xsl:element>
		<xsl:element name="Com">
			<xsl:attribute name="msg">�E������</xsl:attribute>
			<xsl:element name="LoadEvent">
				<xsl:attribute name="path">Event/Mission/Common/Select.xml</xsl:attribute>
			</xsl:element>
		</xsl:element>
	</xsl:element>
	</xsl:if>
	<xsl:if test="@time">
		<xsl:element name="Command">
			<xsl:attribute name="com">window/show/Timer/<xsl:value-of select="@time"/></xsl:attribute>
		</xsl:element>
	</xsl:if>
	<xsl:if test="@unit">
		<xsl:element name="Param">
			<xsl:attribute name="name">_temp_RouteID</xsl:attribute>
			<xsl:attribute name="val">Mission</xsl:attribute>
		</xsl:element>
		<xsl:element name="Param">
			<xsl:attribute name="name">_temp_Stagename</xsl:attribute>
			<xsl:attribute name="val"><xsl:value-of select="@unit"/></xsl:attribute>
		</xsl:element>
		<xsl:element name="Param">
			<xsl:attribute name="name">_temp_StageID</xsl:attribute>
			<xsl:attribute name="val">/</xsl:attribute>
		</xsl:element>
		<xsl:element name="Param">
			<xsl:attribute name="name">_temp_StageID</xsl:attribute>
			<xsl:attribute name="com">+</xsl:attribute>
			<xsl:attribute name="val"><xsl:value-of select="@unit"/></xsl:attribute>
		</xsl:element>
		<xsl:element name="Param">
			<xsl:attribute name="name">_temp_efp</xsl:attribute>
			<xsl:attribute name="val">Event/Mission/Common/<xsl:value-of select="@unit"/> Unit.xml</xsl:attribute>
		</xsl:element>
	</xsl:if>
	<xsl:if test="@com">
		<xsl:element name="Param">
			<xsl:attribute name="name">_temp_loadcom</xsl:attribute>
			<xsl:attribute name="val">Event/Mission/Common/</xsl:attribute>
		</xsl:element>
		<xsl:element name="Param">
			<xsl:attribute name="name">_temp_loadcom</xsl:attribute>
			<xsl:attribute name="com">+</xsl:attribute>
			<xsl:attribute name="val">=_temp_Stagename</xsl:attribute>
		</xsl:element>
		<xsl:element name="Param">
			<xsl:attribute name="name">_temp_loadcom</xsl:attribute>
			<xsl:attribute name="com">+</xsl:attribute>
			<xsl:attribute name="val"> </xsl:attribute>
		</xsl:element>
		<xsl:element name="Param">
			<xsl:attribute name="name">_temp_loadcom</xsl:attribute>
			<xsl:attribute name="com">+</xsl:attribute>
			<xsl:attribute name="val"><xsl:value-of select="@com"/>.xml</xsl:attribute>
		</xsl:element>
		<xsl:element name="LoadEvent">
			<xsl:attribute name="path">=_temp_loadcom</xsl:attribute>
		</xsl:element>
	</xsl:if>
	<xsl:if test="@sel">
		<xsl:element name="LoadEvent">
			<xsl:attribute name="path">Event/Mission/Select/Mserect<xsl:value-of select="@sel"/>.xml</xsl:attribute>
		</xsl:element>
	</xsl:if>
</xsl:element>

</xsl:template>

</xsl:stylesheet>
