<?xml version="1.0" encoding="Shift_JIS"?>
<xsl:stylesheet xmlns:xsl="http://www.w3.org/1999/XSL/Transform" version="1.0">
<xsl:output method="xml" version="1.0" encoding="Shift_JIS" indent="yes" />
<xsl:param name="_temp_time"/>

<xsl:template match="CallTrans">

	<xsl:variable name="h" select="floor($_temp_time div 3600000)"/>
	<xsl:variable name="m" select="floor($_temp_time div 60000) - ($h*60)"/>
	<xsl:variable name="s" select="floor($_temp_time div 1000) - ($h*3600) - ($m*60)"/>
	<xsl:element name="Param">
		<xsl:attribute name="name">_temp_msg</xsl:attribute>
		<xsl:attribute name="com">+</xsl:attribute>
		<xsl:attribute name="val"><xsl:value-of select="format-number($h,'000')"/>:<xsl:value-of select="format-number($m,'00')"/>:<xsl:value-of select="format-number($s,'00')"/></xsl:attribute>
	</xsl:element>

</xsl:template>

</xsl:stylesheet>
