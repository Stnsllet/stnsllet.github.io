<?xml version="1.0" encoding="Shift_JIS"?>
<xsl:stylesheet xmlns:xsl="http://www.w3.org/1999/XSL/Transform" version="1.0"  xmlns:spibre="http://geraha.ld.infoseek.co.jp/spibre/">
<xsl:output method="xml" version="1.0" encoding="Shift_JIS" indent="yes" />

<xsl:param name="_temp_vector"/>
<xsl:param name="_temp_push"/>
<xsl:param name="_temp_at"/>
<xsl:param name="_temp_erase"/>

<msxsl:script xmlns:msxsl="urn:schemas-microsoft-com:xslt" language="JavaScript" implements-prefix="spibre">
<![CDATA[
  function getNode(list,com){
	var array = list.split('/');
   	return(array[com]);
  }
  function getLength(list){
	var array = list.split('/');
   	return(array.length);
  }

  function pop_out1(list){
	var array = list.split('/');
   	return(array[array.length-1]);
  }
  function pop_out2(list){
	var str='';
	var array = list.split('/');
	for(var i=0; i < array.length-1; i++) {
		str += array[i];
		if(array.length-2>i)str += '/';
	}
   	return(str);
  }

  function erase(list,com){
	var str='';
	var array = list.split('/');
	for(var i=0; i < array.length; i++) {
		if(array[i]!=com){
			str += array[i];
		}
		if(array.length-1>i&&array[i+1]!=com)str += '/';
	}
   	return(str);
  }

  function push(list,com){
	var str=''+list;
	str=str+'/';
	var p=com;
	str=str+p;
   	return(str);
  }
]]>
</msxsl:script>

<xsl:template match="CallTrans">
	<xsl:variable name="at" select="format-number(@at, '0')"/>
	<xsl:variable name="erase" select="string(@erase)"/>
	<xsl:variable name="push" select="string(@push)"/>
	<xsl:element name="List">

  	<xsl:choose>
        <xsl:when test="@init">
		<xsl:element name="Param">
			<xsl:attribute name="name">_temp_vector</xsl:attribute>
			<xsl:attribute name="val"><xsl:value-of select="@init"/></xsl:attribute>
		</xsl:element>
		<xsl:element name="Param">
			<xsl:attribute name="name"><xsl:value-of select="@copy"/></xsl:attribute>
			<xsl:attribute name="val">=_temp_vector</xsl:attribute>
		</xsl:element>
		<xsl:if test="@erase or @pop_out or @push or @at or @size_out or @at_out">
		<xsl:element name="CallTrans">
			<xsl:attribute name="params"><xsl:value-of select="@params"/></xsl:attribute>
			<xsl:if test="@erase"><xsl:attribute name="pop_out"><xsl:value-of select="@pop_out"/></xsl:attribute></xsl:if>
			<xsl:if test="@pop_out"><xsl:attribute name="pop_out"><xsl:value-of select="@pop_out"/></xsl:attribute></xsl:if>
			<xsl:if test="@push"><xsl:attribute name="push"><xsl:value-of select="@push"/></xsl:attribute></xsl:if>
			<xsl:if test="@at"><xsl:attribute name="at"><xsl:value-of select="@at"/></xsl:attribute></xsl:if>
			<xsl:if test="@size_out"><xsl:attribute name="size_out"><xsl:value-of select="@size_out"/></xsl:attribute></xsl:if>
			<xsl:if test="@at_out"><xsl:attribute name="at_out"><xsl:value-of select="@at_out"/></xsl:attribute></xsl:if>
			<xsl:attribute name="copy"><xsl:value-of select="@copy"/></xsl:attribute>
			<xsl:attribute name="path">Xsl/Vector.xsl</xsl:attribute>
		</xsl:element>
		</xsl:if>
	</xsl:when>
        <xsl:when test="@erase">
		<xsl:element name="Param">
			<xsl:attribute name="name">_temp_vector</xsl:attribute>
			<xsl:attribute name="val"><xsl:value-of select="spibre:erase($_temp_vector,$_temp_erase)"/></xsl:attribute>
		</xsl:element>
		<xsl:element name="Param">
			<xsl:attribute name="name"><xsl:value-of select="@copy"/></xsl:attribute>
			<xsl:attribute name="val">=_temp_vector</xsl:attribute>
		</xsl:element>
		<xsl:if test="@pop_out or @push or @at or @size_out or @at_out">
		<xsl:element name="CallTrans">
			<xsl:attribute name="params"><xsl:value-of select="@params"/></xsl:attribute>
			<xsl:if test="@pop_out"><xsl:attribute name="pop_out"><xsl:value-of select="@pop_out"/></xsl:attribute></xsl:if>
			<xsl:if test="@push"><xsl:attribute name="push"><xsl:value-of select="@push"/></xsl:attribute></xsl:if>
			<xsl:if test="@at"><xsl:attribute name="at"><xsl:value-of select="@at"/></xsl:attribute></xsl:if>
			<xsl:if test="@size_out"><xsl:attribute name="size_out"><xsl:value-of select="@size_out"/></xsl:attribute></xsl:if>
			<xsl:if test="@at_out"><xsl:attribute name="at_out"><xsl:value-of select="@at_out"/></xsl:attribute></xsl:if>
			<xsl:attribute name="copy"><xsl:value-of select="@copy"/></xsl:attribute>
			<xsl:attribute name="path">Xsl/Vector.xsl</xsl:attribute>
		</xsl:element>
		</xsl:if>
	</xsl:when>
        <xsl:when test="@pop_out">
		<xsl:element name="Param">
			<xsl:attribute name="name"><xsl:value-of select="@pop_out"/></xsl:attribute>
			<xsl:attribute name="val"><xsl:value-of select="spibre:pop_out1($_temp_vector)"/></xsl:attribute>
		</xsl:element>
		<xsl:element name="Param">
			<xsl:attribute name="name">_temp_vector</xsl:attribute>
			<xsl:attribute name="val"><xsl:value-of select="spibre:pop_out2($_temp_vector)"/></xsl:attribute>
		</xsl:element>
		<xsl:element name="Param">
			<xsl:attribute name="name"><xsl:value-of select="@copy"/></xsl:attribute>
			<xsl:attribute name="val">=_temp_vector</xsl:attribute>
		</xsl:element>
		<xsl:if test="@push or @at or @size_out or @at_out">
		<xsl:element name="CallTrans">
			<xsl:attribute name="params"><xsl:value-of select="@params"/></xsl:attribute>
			<xsl:if test="@push"><xsl:attribute name="push"><xsl:value-of select="@push"/></xsl:attribute></xsl:if>
			<xsl:if test="@at"><xsl:attribute name="at"><xsl:value-of select="@at"/></xsl:attribute></xsl:if>
			<xsl:if test="@size_out"><xsl:attribute name="size_out"><xsl:value-of select="@size_out"/></xsl:attribute></xsl:if>
			<xsl:if test="@at_out"><xsl:attribute name="at_out"><xsl:value-of select="@at_out"/></xsl:attribute></xsl:if>
			<xsl:attribute name="copy"><xsl:value-of select="@params"/></xsl:attribute>
			<xsl:attribute name="path">Xsl/Vector.xsl</xsl:attribute>
		</xsl:element>
		</xsl:if>
	</xsl:when>
	<xsl:when test="@push">
		<xsl:element name="Param">
			<xsl:attribute name="name">_temp_vector</xsl:attribute>
			<xsl:attribute name="val"><xsl:value-of select="spibre:push($_temp_vector,$_temp_push)"/></xsl:attribute>
		</xsl:element>
		<xsl:element name="Param">
			<xsl:attribute name="name"><xsl:value-of select="@copy"/></xsl:attribute>
			<xsl:attribute name="val">=_temp_vector</xsl:attribute>
		</xsl:element>
		<xsl:if test="@at or @size_out or @at_out">
		<xsl:element name="CallTrans">
			<xsl:attribute name="params"><xsl:value-of select="@params"/></xsl:attribute>
			<xsl:if test="@at"><xsl:attribute name="at"><xsl:value-of select="@at"/></xsl:attribute></xsl:if>
			<xsl:if test="@size_out"><xsl:attribute name="size_out"><xsl:value-of select="@size_out"/></xsl:attribute></xsl:if>
			<xsl:if test="@at_out"><xsl:attribute name="at_out"><xsl:value-of select="@at_out"/></xsl:attribute></xsl:if>
			<xsl:attribute name="copy"><xsl:value-of select="@params"/></xsl:attribute>
			<xsl:attribute name="path">Xsl/Vector.xsl</xsl:attribute>
		</xsl:element>
		</xsl:if>

	</xsl:when>
	<xsl:when test="1">
		<xsl:if test="@at_out">
		<xsl:element name="Param">
			<xsl:attribute name="name"><xsl:value-of select="@at_out"/></xsl:attribute>
			<xsl:attribute name="val"><xsl:value-of select="spibre:getNode($_temp_vector,$_temp_at)"/></xsl:attribute>
		</xsl:element>
		</xsl:if>
		<xsl:if test="@size_out">
		<xsl:element name="Param">
			<xsl:attribute name="name"><xsl:value-of select="@size_out"/></xsl:attribute>
			<xsl:attribute name="val"><xsl:value-of select="spibre:getLength($_temp_vector)"/></xsl:attribute>
		</xsl:element>
		</xsl:if>
		<xsl:element name="Param">
			<xsl:attribute name="name"><xsl:value-of select="@copy"/></xsl:attribute>
			<xsl:attribute name="val">=_temp_vector</xsl:attribute>
		</xsl:element>
	</xsl:when>
  	</xsl:choose>



	</xsl:element>
</xsl:template>

<xsl:template match="*">
	<xsl:copy-of select="."/>
</xsl:template>

</xsl:stylesheet>

