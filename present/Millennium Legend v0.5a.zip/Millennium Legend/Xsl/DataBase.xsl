<?xml version="1.0" encoding="Shift_JIS"?>
<xsl:stylesheet xmlns:xsl="http://www.w3.org/1999/XSL/Transform" version="1.0"  xmlns:spibre="http://geroha.ld.infoseek.co.jp/spibre/">
<xsl:output method="xml" version="1.0" encoding="Shift_JIS" indent="yes" />

<xsl:param name="_temp_searchdata"/>

<xsl:template match="CallTrans">

	<xsl:variable name="get" select="@get"/>
	<xsl:variable name="search" select="$_temp_searchdata"/>

	<xsl:element name="List">
	<xsl:if test="@type='pason'">
	<xsl:for-each select="document(concat('../',@data))/PasonData/Pason[@name=$_temp_searchdata]">
		<xsl:element name="Param">
			<xsl:attribute name="name"><xsl:value-of select="$get"/>.name</xsl:attribute>
			<xsl:attribute name="val"><xsl:value-of select="@name"/></xsl:attribute>
		</xsl:element>
		<xsl:element name="Param">
			<xsl:attribute name="name"><xsl:value-of select="$get"/>.str</xsl:attribute>
			<xsl:attribute name="val"><xsl:value-of select="@str"/></xsl:attribute>
		</xsl:element>
		<xsl:element name="Param">
			<xsl:attribute name="name"><xsl:value-of select="$get"/>.help</xsl:attribute>
			<xsl:attribute name="val"><xsl:value-of select="@help"/></xsl:attribute>
		</xsl:element>

		<xsl:for-each select="./Ex">
		<xsl:element name="Param">
			<xsl:attribute name="name"><xsl:value-of select="$get"/>.Ex.job</xsl:attribute>
			<xsl:attribute name="val"><xsl:value-of select="@job"/></xsl:attribute>
		</xsl:element>
		<xsl:element name="Param">
			<xsl:attribute name="name"><xsl:value-of select="$get"/>.Ex.empeq</xsl:attribute>
			<xsl:attribute name="val"><xsl:value-of select="@empeq"/></xsl:attribute>
		</xsl:element>
		<xsl:element name="Param">
			<xsl:attribute name="name"><xsl:value-of select="$get"/>.Ex.emprate</xsl:attribute>
			<xsl:attribute name="val"><xsl:value-of select="@emprate"/></xsl:attribute>
		</xsl:element>
		</xsl:for-each>
	</xsl:for-each>
	</xsl:if>
	<xsl:if test="@type='job'">
	<xsl:for-each select="document(concat('../',@data))/JobData/Job[@name=$_temp_searchdata]">
		<xsl:element name="Param">
			<xsl:attribute name="name"><xsl:value-of select="$get"/>.name</xsl:attribute>
			<xsl:attribute name="val"><xsl:value-of select="@name"/></xsl:attribute>
		</xsl:element>
		<xsl:element name="Param">
			<xsl:attribute name="name"><xsl:value-of select="$get"/>.str</xsl:attribute>
			<xsl:attribute name="val"><xsl:value-of select="@str"/></xsl:attribute>
		</xsl:element>
		<xsl:element name="Param">
			<xsl:attribute name="name"><xsl:value-of select="$get"/>.help</xsl:attribute>
			<xsl:attribute name="val"><xsl:value-of select="@help"/></xsl:attribute>
		</xsl:element>
	</xsl:for-each>
	</xsl:if>
	</xsl:element>
</xsl:template>

</xsl:stylesheet>
