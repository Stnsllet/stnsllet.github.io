<?xml version="1.0" encoding="Shift_JIS"?>
<xsl:stylesheet xmlns:xsl="http://www.w3.org/1999/XSL/Transform" version="1.0" xmlns:spibre="a">
<xsl:output method="xml" version="1.0" encoding="Shift_JIS" indent="yes" />

<xsl:param name="_temp_num"/>
<xsl:param name="_temp_numval"/>
<xsl:param name="_temp_Mdig"/>

<msxsl:script xmlns:msxsl="urn:schemas-microsoft-com:xslt" language="JavaScript" implements-prefix="spibre">

  function multi(int,ex){
   	return(Math.pow(int, ex));
  }

  function remain(mit,wal){
   	return(mit % wal);
  }
  function max(a,b){
   	return(Math.max(a, b));
  }
  function min(a,b){
   	return(Math.min(a, b));
  }
  function round(a){
   	return(Math.round(a));
  }
  function rounddown(a){
   	return(Math.floor(a));
  }
  function roundup(a){
   	return(Math.ceil(a));
  }
  function pi(){
   	return(Math.PI);
  }
  function sin(data){
   	return(Math.sin(Math.PI * data));
  }
<![CDATA[
  function inout(param, area){
	areas = area.split('/');
	if(param>=areas[0] && param<=areas[1]){
		return 1;
	}
	return 0;

  }
]]>
  function even(a) {
	if (a % 2 == 0) {
		return 0;
	}
	else {
		return 1;
	}
  }
  function cos(data){
   	return(Math.cos(Math.PI * data));
  }
  function abs(a){
   	return(Math.abs(a));
  }
  function rnd(max,min){
   	return Math.floor(Math.random()*(max-min)+min);
  }
  function rnds(a){
   	return(Math.random() * a);
  }
  function log(a){
   	return(Math.log(a));
  }
function digit(nums,dig){
	var a = Number(dig)*10;
	var c = a/10;
	var b = Math.floor(nums % a / c);
	return (b);
}

function toRadian(num){
	return 2.0/num;
}

function distance(name, taget){
	pos1 = name.split('/');
	pos2 = taget.split('/');
	a = pos1[0] - pos2[0];
	b = pos1[1] - pos2[1];
	d = Math.sqrt(Math.pow(a,2) + Math.pow(b,2));
   	return(d);
}

</msxsl:script>

<xsl:template match="CallTrans">
	<xsl:variable name="val" select="$_temp_numval"/>
	<xsl:variable name="dig" select="$_temp_Mdig"/>
	<xsl:variable name="num" select="$_temp_num"/>
  	<xsl:if test="@type = 'abs'">
		<xsl:element name="Param">
			<xsl:attribute name="name">_temp_mathret</xsl:attribute>
			<xsl:attribute name="val"><xsl:value-of select="spibre:abs($num)"/></xsl:attribute>
		</xsl:element>
	</xsl:if>
  	<xsl:if test="@type = 'inout'">
		<xsl:element name="Param">
			<xsl:attribute name="name">_temp_mathret</xsl:attribute>
			<xsl:attribute name="val"><xsl:value-of select="spibre:inout($num,$val)"/></xsl:attribute>
		</xsl:element>
	</xsl:if>
  	<xsl:if test="@type = 'even'">
		<xsl:element name="Param">
			<xsl:attribute name="name">_temp_mathret</xsl:attribute>
			<xsl:attribute name="val"><xsl:value-of select="spibre:even($num)"/></xsl:attribute>
		</xsl:element>
	</xsl:if>
  	<xsl:if test="@type = 'multi'">
		<xsl:element name="Param">
			<xsl:attribute name="name">_temp_mathret</xsl:attribute>
			<xsl:attribute name="val"><xsl:value-of select="spibre:multi($num,$val)"/></xsl:attribute>
		</xsl:element>
	</xsl:if>
  	<xsl:if test="@type = 'digit'">
		<xsl:element name="Param">
			<xsl:attribute name="name">_temp_mathret</xsl:attribute>
			<xsl:attribute name="val"><xsl:value-of select="spibre:digit($num,$val)"/></xsl:attribute>
		</xsl:element>
	</xsl:if>
  	<xsl:if test="@type = 'distance'">
		<xsl:element name="Param">
			<xsl:attribute name="name">_temp_mathret</xsl:attribute>
			<xsl:attribute name="val"><xsl:value-of select="spibre:distance($num,$dig)"/></xsl:attribute>
		</xsl:element>
	</xsl:if>
  	<xsl:if test="@type = 'floor'">
		<xsl:element name="Param">
			<xsl:attribute name="name">_temp_mathret</xsl:attribute>
			<xsl:attribute name="val"><xsl:value-of select="spibre:rounddown($num)"/></xsl:attribute>
		</xsl:element>
	</xsl:if>
  	<xsl:if test="@type = 'round'">
		<xsl:element name="Param">
			<xsl:attribute name="name">_temp_mathret</xsl:attribute>
			<xsl:attribute name="val"><xsl:value-of select="spibre:round($num)"/></xsl:attribute>
		</xsl:element>
	</xsl:if>
  	<xsl:if test="@type = 'ceil'">
		<xsl:element name="Param">
			<xsl:attribute name="name">_temp_mathret</xsl:attribute>
			<xsl:attribute name="val"><xsl:value-of select="spibre:roundup($num)"/></xsl:attribute>
		</xsl:element>
	</xsl:if>
  	<xsl:if test="@type = 'pi'">
		<xsl:element name="Param">
			<xsl:attribute name="name">_temp_mathret</xsl:attribute>
			<xsl:attribute name="val"><xsl:value-of select="spibre:pi()"/></xsl:attribute>
		</xsl:element>
	</xsl:if>
  	<xsl:if test="@type = 'rndint'">
		<xsl:element name="Param">
			<xsl:attribute name="name">_temp_mathret</xsl:attribute>
			<xsl:attribute name="val"><xsl:value-of select="spibre:rnd($num,$val)"/></xsl:attribute>
		</xsl:element>
	</xsl:if>
  	<xsl:if test="@type = 'radian'">
		<xsl:element name="Param">
			<xsl:attribute name="name">_temp_mathret</xsl:attribute>
			<xsl:attribute name="val"><xsl:value-of select="spibre:toRadian($num)"/></xsl:attribute>
		</xsl:element>
	</xsl:if>
</xsl:template>

</xsl:stylesheet>
