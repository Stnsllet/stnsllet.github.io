<?xml version="1.0" encoding="Shift_JIS"?>
<xsl:stylesheet xmlns:xsl="http://www.w3.org/1999/XSL/Transform" version="1.0" 
	xmlns:spibre="a">
	<xsl:output method="xml" version="1.0" encoding="Shift_JIS" indent="yes" />

	<xsl:template match="CallTrans">
		<xsl:variable name="loadevent" select="@load"/>

		<xsl:element name="Choice">
			<xsl:if test="not(@force)">
				<xsl:element name="ChkFlg">
					<xsl:attribute name="on">sys_FadeCut</xsl:attribute>
					<xsl:element name="Param">
						<xsl:attribute name="name">_temp_sclastcallpath</xsl:attribute>
						<xsl:attribute name="val">
							<xsl:value-of select="@load"/>
						</xsl:attribute>
					</xsl:element>
					<xsl:element name="Choice">
						<xsl:element name="LoadEvent">
							<xsl:attribute name="path">
								<xsl:value-of select="@load"/>
							</xsl:attribute>
						</xsl:element>
						<xsl:element name="CallTrans">
							<xsl:attribute name="type">Fade</xsl:attribute>
							<xsl:attribute name="file">
								<xsl:value-of select="@load"/>
							</xsl:attribute>
							<xsl:attribute name="path">Xsl/Error.xsl</xsl:attribute>
						</xsl:element>
					</xsl:element>
				</xsl:element>
			</xsl:if>
			<xsl:element name="Event">
				<xsl:element name="Timer">
					<xsl:attribute name="time">10</xsl:attribute>
					<xsl:element name="LoadEvent">
						<xsl:attribute name="path">Event/Common/Fadeout.xml</xsl:attribute>
					</xsl:element>
				</xsl:element>
				<xsl:element name="Timer">
					<xsl:attribute name="time">1500</xsl:attribute>
					<xsl:element name="Command">
						<xsl:attribute name="com">window/filter/Tex/Fade/Black/0.png</xsl:attribute>
					</xsl:element>
					<xsl:element name="Param">
						<xsl:attribute name="name">_temp_sclastcallpath</xsl:attribute>
						<xsl:attribute name="val">
							<xsl:value-of select="@load"/>
						</xsl:attribute>
					</xsl:element>
					<xsl:element name="Choice">
						<xsl:element name="LoadEvent">
							<xsl:attribute name="path">
								<xsl:value-of select="@load"/>
							</xsl:attribute>
						</xsl:element>
						<xsl:element name="CallTrans">
							<xsl:attribute name="type">Fade</xsl:attribute>
							<xsl:attribute name="file">
								<xsl:value-of select="@load"/>
							</xsl:attribute>
							<xsl:attribute name="path">Xsl/Error.xsl</xsl:attribute>
						</xsl:element>
					</xsl:element>
				</xsl:element>
			</xsl:element>
		</xsl:element>

	</xsl:template>

</xsl:stylesheet>
