<?xml version="1.0" encoding="Shift_JIS"?>
<xsl:stylesheet xmlns:xsl="http://www.w3.org/1999/XSL/Transform" version="1.0" xmlns:spibre="http://geraha.ld.infoseek.co.jp/spibre/">
<xsl:output method="xml" version="1.0" encoding="Shift_JIS" indent="yes" />

<xsl:param name="_temp_list"/>
<xsl:param name="_temp_limitlist"/>

<msxsl:script xmlns:msxsl="urn:schemas-microsoft-com:xslt" language="JavaScript" implements-prefix="spibre">
<![CDATA[
  function getNode(list,com){
	var array = list.split('/');
   	return(array[com]);
  }
  function getLength(list, limit){
	var array = list.split('/');
	if(limit < array.length) return limit;
   	return(array.length);
  }
]]>
</msxsl:script>

<xsl:template match="CallTrans">
	<xsl:element name="List">
		<xsl:call-template name="listing">
			<xsl:with-param name="name" select="@name"/>
			<xsl:with-param name="type" select="@type"/>
			<xsl:with-param name="val" select="@val"/>
			<xsl:with-param name="list" select="$_temp_list"/>
			<xsl:with-param name="i" select="0"/>
			<xsl:with-param name="end" select="spibre:getLength($_temp_list,$_temp_limitlist)"/>
		</xsl:call-template>
	</xsl:element>
</xsl:template>

<xsl:template name="listing">
	<xsl:param name="end"/>
	<xsl:param name="i"/>
	<xsl:param name="name"/>
	<xsl:param name="type"/>
	<xsl:param name="val"/>
	<xsl:param name="list"/>
	<xsl:if test="$end &gt; $i">
		<xsl:element name="List">
				<xsl:choose>
					<xsl:when test="$type = 'Param'">
						<xsl:element name="Param">
							<xsl:attribute name="name">_temp_readlist</xsl:attribute>
							<xsl:attribute name="val"><xsl:value-of select="spibre:getNode($list,$i)"/></xsl:attribute>
							<xsl:element name="Param">
								<xsl:attribute name="name">=_temp_readlist</xsl:attribute>
								<xsl:attribute name="val"><xsl:value-of select="$val"/></xsl:attribute>
							</xsl:element>
						</xsl:element>
					</xsl:when>
					<xsl:when test="$type = 'Param_l'">
						<xsl:element name="Param">
							<xsl:attribute name="name">_temp_sys_paramcheck</xsl:attribute>
							<xsl:attribute name="val"><xsl:value-of select="spibre:getNode($list,$i)"/></xsl:attribute>
							<xsl:element name="Param">
								<xsl:attribute name="name">_temp_sys_paramcheck</xsl:attribute>
								<xsl:attribute name="com">=</xsl:attribute>
								<xsl:attribute name="val"><xsl:value-of select="$val"/></xsl:attribute>
								<xsl:element name="Param">
									<xsl:attribute name="name">_temp_strbool</xsl:attribute>
									<xsl:attribute name="val">true</xsl:attribute>
								</xsl:element>
							</xsl:element>
						</xsl:element>
					</xsl:when>
					<xsl:when test="$type = 'Param_v'">
						<xsl:element name="Param">
							<xsl:attribute name="name">_temp_sys_paramcheck</xsl:attribute>
							<xsl:attribute name="val"><xsl:value-of select="spibre:getNode($list,$i)"/></xsl:attribute>
							<xsl:element name="Param">
								<xsl:attribute name="name">_temp_sys_paramcheck</xsl:attribute>
								<xsl:attribute name="com">=</xsl:attribute>
								<xsl:attribute name="val"><xsl:value-of select="$val"/></xsl:attribute>
								<xsl:element name="Param">
									<xsl:attribute name="name">_temp_strbool</xsl:attribute>
									<xsl:attribute name="val">true</xsl:attribute>
								</xsl:element>
							</xsl:element>
						</xsl:element>
					</xsl:when>
					<xsl:when test="1">
						<xsl:element name="Param">
							<xsl:attribute name="name"><xsl:value-of select="$name"/>.i</xsl:attribute>
							<xsl:attribute name="val"><xsl:value-of select="$i"/></xsl:attribute>
						</xsl:element>					
						<xsl:element name="Param">
							<xsl:attribute name="name"><xsl:value-of select="$name"/></xsl:attribute>
							<xsl:attribute name="val"><xsl:value-of select="spibre:getNode($list,$i)"/></xsl:attribute>
							<xsl:apply-templates/>
							<xsl:call-template name="listing">
								<xsl:with-param name="end" select="$end"/>
								<xsl:with-param name="i" select="$i + 1"/>
								<xsl:with-param name="name" select="$name"/>
								<xsl:with-param name="type" select="$type"/>
								<xsl:with-param name="val" select="$val"/>
								<xsl:with-param name="list" select="$list"/>
							</xsl:call-template>
						</xsl:element>
					</xsl:when>
				</xsl:choose>
		</xsl:element>

	</xsl:if>
</xsl:template>

<xsl:template match="*">
	<xsl:copy-of select="."/>
</xsl:template>

</xsl:stylesheet>

