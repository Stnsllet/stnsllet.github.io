<?xml version="1.0" encoding="Shift_JIS"?>
<xsl:stylesheet xmlns:xsl="http://www.w3.org/1999/XSL/Transform" version="1.0" xmlns:sc="a">
<xsl:output method="xml" version="1.0" encoding="Shift_JIS" indent="yes" />

<xsl:param name="_temp_cronus"/>

<msxsl:script xmlns:msxsl="urn:schemas-microsoft-com:xslt" language="JavaScript" implements-prefix="sc">
<![CDATA[

cronus = {
    	h: function(time){
        	times = Math.floor(time / 3600000);
		return times;
	},
	m: function(time){
		times = Math.floor(time / 60000) - this.h(time) * 60;
		return times;
	},
	s: function(time){
		times = Math.floor(time / 1000)-this.m(time) * 60 - this.h(time) * 3600;
		return times;
	},
	c: function(time){
		times = time- this.h(time) * 3600000-this.m(time) * 60000-this.s(time) * 1000;
		return Math.round(times/10,-1);
	}
};

function digit(time){
	return ("0" + Number(time)).slice(-2);
}
function digit_l(time){
	return ("00" + time).slice(-3);
}
function decode(time){
	cc = 0;
	if(time.indexOf('.') != -1){
	      times= time.split('.');
		cc = times[1];
	       time= times[0];
	}
	if(time.indexOf(':') != -1) times = time.split(':');
	if(times.length==3){
		hh=times[0];
		mm=times[1];
		ss=times[2];
	}
	if(times.length==2){
		hh=0;
		mm=times[0];
		ss=times[1];
	}
	if(times.length==1){
		hh=0;
		mm=0;
		ss=times[0];
	}
	return (cc*10+ss*1000+mm*60000+hh*3600000);
}
function decode_clock(time){
	times = time.split(':');
	return (times[1]*60000+times[0]*3600000);
}

function exec(time,com){
	hh =	digit(cronus.h(time));
	mm =	digit(cronus.m(time));
	ss =	digit(cronus.s(time));
	cc =	digit(cronus.c(time));
	hhh=  digit_l(cronus.h(time));
       real=   	new Date();
	ryy=    real.getFullYear();
	try{
	rmo=	digit(real.getMonth()+1);
	rdt=	digit(real.getDate());
	rhh=	digit(real.getHours());
	rmm=	digit(real.getMinutes());
	rsc=	digit(real.getSeconds());

	switch(com){
		case "all":
			return(hh+':'+mm+':'+ss+'.'+cc);
		case "speed":
			return(mm+':'+ss+'.'+cc);
		case "short":
			return(mm+':'+ss);
		case "short_str":
			return(mm+'��'+ss+'�b');
		case "time":
			return(hh+':'+mm+':'+ss);
		case "time_str":
			return(hh+'����'+mm+'��'+ss+'�b');
		case "clock":
			return(hh+':'+mm);
		case "clock_str":
			return(hh+'����'+mm+'��');
		case "long":
			return(hhh+':'+mm+':'+ss);
		case "none":
			return(time);
		case "hour":
			return(hh);
		case "minute":
			return(mm);
		case "second":
			return(ss);
		case "comma":
			return(cc);
		case "realall":
			return(ryy + '/' + rmo +'/'+ rdt +' '+ rhh +':'+ rmm +':'+ rsc );
		case "realall_str":
			return(ryy + '�N' + rmo +'��'+ rdt +'�� '+ rhh +'��'+ rmm +'��'+ rsc + '�b');
		case "reallong":
			return(rmo + '/' + rdt +' '+ rhh +':'+ rmm +':'+ rsc );
		case "reallong_str":
			return(rmo +'��'+ rdt +'�� '+ rhh +'��'+ rmm +'��'+ rsc + '�b');
		case "realshort":
			return(rmm + ':' + rsc );
		case "realshort_str":
			return(rmm +'��'+ rsc + '�b');
		case "realtime":
			return(rhh + ':' + rmm +':'+ rsc );
		case "realtime_str":
			return(rhh +'��'+ rmm +'��'+ rsc + '�b');
		case "realclock":
			return(rhh + ':' + rmm );
		case "realclock_str":
			return(rhh +'��'+ rmm +'��');
		case "realday":
			return(rmo + '/' + rdt );
		case "realday_str":
			return(rmo +'��'+ rdt +'��');
		case "realsaveday":
			return(rmo + '/' + rdt + ' ' + rhh + ':' + rmm );
		case "realyear":
			return(ryy);
		case "realyear_str":
			return(ryy + '�N');
		case "realdate":
			return(real.getDate());
		case "realmonth":
			return(real.getMonth()+1);
		case "realhour":
			return(real.getHours());
		case "realmin":
			return(real.getMinutes());
		case "realsec":
			return(real.getSeconds());
		case "decode":
			return(decode(time));
		case "decode_clock":
			return(decode_clock(time));
	}
	}
	catch(exception){
    		return exception.message;
	}
	return("Invalid Com:"+com);
}


]]>
</msxsl:script>


<xsl:template match="CallTrans">
	<xsl:variable name="cronus" select="$_temp_cronus"/>
	<xsl:element name="Event">
		<xsl:element name="Param">
			<xsl:attribute name="name">_temp_xslreturn</xsl:attribute>
			<xsl:attribute name="val"><xsl:value-of select="sc:exec($cronus,string(@com))"/></xsl:attribute>
		</xsl:element>
	</xsl:element>
</xsl:template>

</xsl:stylesheet>
