<?xml version="1.0" encoding="Shift_JIS"?>
<xsl:stylesheet xmlns:xsl="http://www.w3.org/1999/XSL/Transform" version="1.0" xmlns:spibre="a">
<xsl:output method="xml" version="1.0" encoding="Shift_JIS" indent="yes" />

<xsl:param name="_temp_itid"/>

<xsl:template match="CallTrans">
	<xsl:variable name="params" select="@params"/>
	<xsl:variable name="name" select="@name"/>
	<xsl:variable name="type" select="@type"/>
	<xsl:variable name="item" select="@item"/>
	<xsl:variable name="count" select="@count"/>

	<xsl:variable name="itemid" select="$_temp_itid"/>
	<xsl:element name="Event">
		<xsl:element name="Param">
			<xsl:attribute name="name">_temp_itemid</xsl:attribute>
			<xsl:attribute name="val"><xsl:value-of select="$itemid"/></xsl:attribute>
		</xsl:element>
		<xsl:element name="LoadEvent">
			<xsl:attribute name="path">Event/Common/ItemHaveCheck.xml</xsl:attribute>
		</xsl:element>
  		<xsl:if test="$type = 'save'">
			<xsl:for-each select="document('../Data/AllItem.xml')/ItemData/Item[@ex=$item]">
			<xsl:element name="Command">
				<xsl:attribute name="com">data/have/<xsl:value-of select="@id"/>/1</xsl:attribute>
				<xsl:element name="Param">
					<xsl:attribute name="name">_temp_I<xsl:value-of select="@id"/></xsl:attribute>
					<xsl:attribute name="val">1</xsl:attribute>
				</xsl:element>

			</xsl:element>
			</xsl:for-each>
		</xsl:if>
  		<xsl:if test="$type = 'load'">
			<xsl:for-each select="document('../Data/AllItem.xml')/ItemData/Item[@ex=$item]">
			<xsl:element name="Param">
				<xsl:attribute name="name">_temp_I<xsl:value-of select="@id"/></xsl:attribute>
				<xsl:attribute name="com">=</xsl:attribute>
				<xsl:attribute name="val">1</xsl:attribute>
				<xsl:element name="UserData">
					<xsl:element name="Get">
						<xsl:attribute name="item"><xsl:value-of select="@id"/></xsl:attribute>
					</xsl:element>
				</xsl:element>
			</xsl:element>
			</xsl:for-each>
		</xsl:if>
  		<xsl:if test="$type = 'have'">
			<xsl:element name="Param">
				<xsl:attribute name="name"><xsl:value-of select="@name"/></xsl:attribute>
				<xsl:attribute name="val">=_temp_itemhave</xsl:attribute>
			</xsl:element>
		</xsl:if>
  		<xsl:if test="$type = '+'">
			<xsl:element name="Command">
				<xsl:attribute name="com">data/deleteitem/<xsl:value-of select="$itemid"/></xsl:attribute>
			</xsl:element>
			<xsl:element name="Param">
				<xsl:attribute name="name">_temp_itemdp</xsl:attribute>
				<xsl:attribute name="val">=_temp_itemhave</xsl:attribute>
			</xsl:element>
			<xsl:element name="Param">
				<xsl:attribute name="name">_temp_itemdp</xsl:attribute>
				<xsl:attribute name="com">+</xsl:attribute>
				<xsl:attribute name="val"><xsl:value-of select="@count"/></xsl:attribute>
			</xsl:element>
			<xsl:element name="LoadEvent">
				<xsl:attribute name="path">Event/Common/Parts/ItemAoC.xml</xsl:attribute>
			</xsl:element>
		</xsl:if>
  		<xsl:if test="$type = '='">
			<xsl:element name="Command">
				<xsl:attribute name="com">data/deleteitem/<xsl:value-of select="$itemid"/></xsl:attribute>
			</xsl:element>
			<xsl:element name="Param">
				<xsl:attribute name="name">_temp_itemdp</xsl:attribute>
				<xsl:attribute name="val">=_temp_itemhave</xsl:attribute>
			</xsl:element>
			<xsl:element name="Param">
				<xsl:attribute name="name">_temp_itemdp</xsl:attribute>
				<xsl:attribute name="val"><xsl:value-of select="@count"/></xsl:attribute>
			</xsl:element>
			<xsl:element name="LoadEvent">
				<xsl:attribute name="path">Event/Common/Parts/ItemAoC.xml</xsl:attribute>
			</xsl:element>
		</xsl:if>
  		<xsl:if test="$type = '-'">
			<xsl:element name="Command">
				<xsl:attribute name="com">data/deleteitem/<xsl:value-of select="$itemid"/></xsl:attribute>
			</xsl:element>
			<xsl:element name="Param">
				<xsl:attribute name="name">_temp_itemdp</xsl:attribute>
				<xsl:attribute name="val">=_temp_itemhave</xsl:attribute>
			</xsl:element>
			<xsl:element name="Param">
				<xsl:attribute name="name">_temp_itemdp</xsl:attribute>
				<xsl:attribute name="com">-</xsl:attribute>
				<xsl:attribute name="val"><xsl:value-of select="@count"/></xsl:attribute>
			</xsl:element>
			<xsl:element name="LoadEvent">
				<xsl:attribute name="path">Event/Common/Parts/ItemAoC.xml</xsl:attribute>
			</xsl:element>
			<xsl:element name="Param">
				<xsl:attribute name="name">_temp_itemdp</xsl:attribute>
				<xsl:attribute name="com">ld</xsl:attribute>
				<xsl:attribute name="val">1</xsl:attribute>
				<xsl:element name="Command">
					<xsl:attribute name="com">data/deleteitem/<xsl:value-of select="$itemid"/></xsl:attribute>
				</xsl:element>
			</xsl:element>
		</xsl:if>
  		<xsl:if test="$type = 'data'">
			<xsl:for-each select="document('../Data/AllItem.xml')/ItemData/Item[@id=$itemid]">
			<xsl:element name="Param">
				<xsl:attribute name="name"><xsl:value-of select="$name"/></xsl:attribute>
				<xsl:attribute name="val"><xsl:value-of select="@id"/></xsl:attribute>
			</xsl:element>
			<xsl:element name="Param">
				<xsl:attribute name="name"><xsl:value-of select="$name"/>.str</xsl:attribute>
				<xsl:attribute name="val"><xsl:value-of select="@str"/></xsl:attribute>
			</xsl:element>
			<xsl:element name="Param">
				<xsl:attribute name="name"><xsl:value-of select="$name"/>.type</xsl:attribute>
				<xsl:attribute name="val"><xsl:value-of select="@type"/></xsl:attribute>
			</xsl:element>
			<xsl:element name="Param">
				<xsl:attribute name="name"><xsl:value-of select="$name"/>.help</xsl:attribute>
				<xsl:attribute name="val"><xsl:value-of select="@help"/></xsl:attribute>
			</xsl:element>
			<xsl:for-each select="./Data">
				<xsl:element name="Param">
					<xsl:attribute name="name"><xsl:value-of select="$name"/>.hp</xsl:attribute>
					<xsl:attribute name="val"><xsl:value-of select="@hp"/></xsl:attribute>
				</xsl:element>
				<xsl:element name="Param">
					<xsl:attribute name="name"><xsl:value-of select="$name"/>.mp</xsl:attribute>
					<xsl:attribute name="val"><xsl:value-of select="@mp"/></xsl:attribute>
				</xsl:element>
				<xsl:element name="Param">
					<xsl:attribute name="name"><xsl:value-of select="$name"/>.atc</xsl:attribute>
					<xsl:attribute name="val"><xsl:value-of select="@atc"/></xsl:attribute>
				</xsl:element>
				<xsl:element name="Param">
					<xsl:attribute name="name"><xsl:value-of select="$name"/>.def</xsl:attribute>
					<xsl:attribute name="val"><xsl:value-of select="@def"/></xsl:attribute>
				</xsl:element>
				<xsl:element name="Param">
					<xsl:attribute name="name"><xsl:value-of select="$name"/>.mag</xsl:attribute>
					<xsl:attribute name="val"><xsl:value-of select="@mag"/></xsl:attribute>
				</xsl:element>
				<xsl:element name="Param">
					<xsl:attribute name="name"><xsl:value-of select="$name"/>.spd</xsl:attribute>
					<xsl:attribute name="val"><xsl:value-of select="@spd"/></xsl:attribute>
				</xsl:element>
				<xsl:element name="Param">
					<xsl:attribute name="name"><xsl:value-of select="$name"/>.len</xsl:attribute>
					<xsl:attribute name="val"><xsl:value-of select="@len"/></xsl:attribute>
				</xsl:element>
				<xsl:element name="Param">
					<xsl:attribute name="name"><xsl:value-of select="$name"/>.pow</xsl:attribute>
					<xsl:attribute name="val"><xsl:value-of select="@pow"/></xsl:attribute>
				</xsl:element>
				<xsl:element name="Param">
					<xsl:attribute name="name"><xsl:value-of select="$name"/>.count</xsl:attribute>
					<xsl:attribute name="val"><xsl:value-of select="@count"/></xsl:attribute>
				</xsl:element>
				<xsl:element name="Param">
					<xsl:attribute name="name"><xsl:value-of select="$name"/>.rare</xsl:attribute>
					<xsl:attribute name="val"><xsl:value-of select="@rare"/></xsl:attribute>
				</xsl:element>
				<xsl:element name="Param">
					<xsl:attribute name="name"><xsl:value-of select="$name"/>.mtype</xsl:attribute>
					<xsl:attribute name="val"><xsl:value-of select="@mtype"/></xsl:attribute>
				</xsl:element>
				<xsl:element name="Param">
					<xsl:attribute name="name"><xsl:value-of select="$name"/>.ex</xsl:attribute>
					<xsl:attribute name="val"><xsl:value-of select="@ex"/></xsl:attribute>
				</xsl:element>

			</xsl:for-each>
			<xsl:element name="Param">
				<xsl:attribute name="name"><xsl:value-of select="$name"/>.skill.1</xsl:attribute><xsl:attribute name="val"></xsl:attribute>
			</xsl:element>
			<xsl:element name="Param">
				<xsl:attribute name="name"><xsl:value-of select="$name"/>.skill.1.level</xsl:attribute><xsl:attribute name="val"></xsl:attribute>
			</xsl:element>
			<xsl:element name="Param">
				<xsl:attribute name="name"><xsl:value-of select="$name"/>.skill.2</xsl:attribute><xsl:attribute name="val"></xsl:attribute>
			</xsl:element>
			<xsl:element name="Param">
				<xsl:attribute name="name"><xsl:value-of select="$name"/>.skill.2.level</xsl:attribute><xsl:attribute name="val"></xsl:attribute>
			</xsl:element>
			<xsl:element name="Param">
				<xsl:attribute name="name"><xsl:value-of select="$name"/>.skill.3</xsl:attribute><xsl:attribute name="val"></xsl:attribute>
			</xsl:element>
			<xsl:element name="Param">
				<xsl:attribute name="name"><xsl:value-of select="$name"/>.skill.3.level</xsl:attribute><xsl:attribute name="val"></xsl:attribute>
			</xsl:element>
			<xsl:element name="Param">
				<xsl:attribute name="name"><xsl:value-of select="$name"/>.skill.4</xsl:attribute><xsl:attribute name="val"></xsl:attribute>
			</xsl:element>
			<xsl:element name="Param">
				<xsl:attribute name="name"><xsl:value-of select="$name"/>.skill.4.level</xsl:attribute><xsl:attribute name="val"></xsl:attribute>
			</xsl:element>
			<xsl:for-each select="./Skill">
				<xsl:element name="Param">
					<xsl:attribute name="name"><xsl:value-of select="$name"/>.skill.<xsl:value-of select="position()"/></xsl:attribute>
					<xsl:attribute name="val"><xsl:value-of select="@name"/></xsl:attribute>
				</xsl:element>
				<xsl:element name="Param">
					<xsl:attribute name="name"><xsl:value-of select="$name"/>.skill.<xsl:value-of select="position()"/>.level</xsl:attribute>
					<xsl:attribute name="val"><xsl:value-of select="@level"/></xsl:attribute>
				</xsl:element>
			</xsl:for-each>
			</xsl:for-each>
		</xsl:if>
	</xsl:element>
</xsl:template>

</xsl:stylesheet>
