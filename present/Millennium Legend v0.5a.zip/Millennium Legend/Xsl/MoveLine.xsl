<?xml version="1.0" encoding="Shift_JIS"?>
<xsl:stylesheet xmlns:xsl="http://www.w3.org/1999/XSL/Transform" version="1.0"  xmlns:sys="https://stnsllet.github.io/">
<xsl:output method="xml" version="1.0" encoding="Shift_JIS" indent="yes" />
<xsl:param name="_temp_ml_name"/>
<xsl:param name="_temp_ml_len"/>
<xsl:param name="_temp_ml_inter"/>
<xsl:param name="_temp_ml_end"/>

<xsl:template match="CallTrans">
	<xsl:element name="Event">
		<xsl:element name="Param">
			<xsl:attribute name="name">_temp_posing_<xsl:value-of select="$_temp_ml_name"/></xsl:attribute>
			<xsl:attribute name="val">1</xsl:attribute>
		</xsl:element>
		<xsl:element name="Timer">
			<xsl:attribute name="name"><xsl:value-of select="$_temp_ml_name"/></xsl:attribute>
			<xsl:attribute name="cycle">-1</xsl:attribute>
			<xsl:element name="ChkFlg">
				<xsl:attribute name="off"><xsl:value-of select="$_temp_ml_end"/></xsl:attribute>
				<xsl:element name="State">
					<xsl:attribute name="name"><xsl:value-of select="$_temp_ml_name"/></xsl:attribute>
					<xsl:attribute name="act">stop</xsl:attribute>
					<xsl:apply-templates />
				</xsl:element>
			</xsl:element>
		</xsl:element>
	</xsl:element>
</xsl:template>

<!-- <xsl:element name="Msg">
	<xsl:attribute name="msg">s</xsl:attribute>
</xsl:element> -->

<xsl:template match="Pos">
	<xsl:element name="Event">
		<xsl:element name="Param">
			<xsl:attribute name="name">_temp_posing_<xsl:value-of select="$_temp_ml_name"/></xsl:attribute>
			<xsl:attribute name="com">=</xsl:attribute>
			<xsl:attribute name="val"><xsl:value-of select="position()"/></xsl:attribute>
			<xsl:element name="Move">
				<xsl:attribute name="name"><xsl:value-of select="$_temp_ml_name"/></xsl:attribute>
				<xsl:if test="not(@taget)">
					<xsl:attribute name="x"><xsl:value-of select="@x"/></xsl:attribute>
					<xsl:attribute name="y"><xsl:value-of select="@y"/></xsl:attribute>
				</xsl:if>
				<xsl:if test="@taget"><xsl:attribute name="taget"><xsl:value-of select="@taget"/></xsl:attribute></xsl:if>
			</xsl:element>
			<xsl:element name="Event">
				<xsl:attribute name="flg">_temp_posing_<xsl:value-of select="$_temp_ml_name"/>_<xsl:value-of select="@x"/>_<xsl:value-of select="@y"/>_<xsl:value-of select="position()"/></xsl:attribute>
				<xsl:element name="Range">
					<xsl:attribute name="name"><xsl:value-of select="$_temp_ml_name"/></xsl:attribute>
					<xsl:if test="@taget"><xsl:attribute name="taget"><xsl:value-of select="@taget"/></xsl:attribute></xsl:if>
					<xsl:if test="not(@taget)"><xsl:attribute name="pos"><xsl:value-of select="@x"/>/<xsl:value-of select="@y"/></xsl:attribute></xsl:if>
					<xsl:attribute name="length"><xsl:value-of select="$_temp_ml_len"/></xsl:attribute>
					
					<xsl:element name="Param">
						<xsl:attribute name="name">_temp_posing_<xsl:value-of select="$_temp_ml_name"/></xsl:attribute>
						<xsl:attribute name="val"><xsl:value-of select="position() + 1"/></xsl:attribute>
					</xsl:element>
					<xsl:element name="Param">
						<xsl:attribute name="name">_temp_sclastcallpath</xsl:attribute>
						<xsl:attribute name="val">sys_moveline</xsl:attribute>
					</xsl:element>
					<xsl:element name="CallTrans">
						<xsl:attribute name="file">sys_moveline</xsl:attribute>
						<xsl:attribute name="path">=SC</xsl:attribute>
						<xsl:apply-templates/>
					</xsl:element>
					<xsl:if test="@flg">
					<xsl:element name="Event">
						<xsl:attribute name="flg"><xsl:value-of select="@flg"/></xsl:attribute>
					</xsl:element>
					</xsl:if>
				</xsl:element>
			</xsl:element>
		</xsl:element>

	</xsl:element>
</xsl:template>

<xsl:template match="*">
	<xsl:copy-of select="."/>
</xsl:template>

</xsl:stylesheet>
