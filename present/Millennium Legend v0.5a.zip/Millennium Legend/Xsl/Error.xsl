<?xml version="1.0" encoding="Shift_JIS"?>
<xsl:stylesheet xmlns:xsl="http://www.w3.org/1999/XSL/Transform" version="1.0"  xmlns:spibre="http://geroha.ld.infoseek.co.jp/spibre/">
<xsl:output method="xml" version="1.0" encoding="Shift_JIS" indent="yes" />


<xsl:template match="CallTrans">
	<xsl:variable name="type" select="@type"/>
	<xsl:variable name="path" select="@file"/>
	<xsl:element name="Event">
	<xsl:element name="Param">
		<xsl:attribute name="name">_temp_ErrorY</xsl:attribute>
		<xsl:attribute name="val">3</xsl:attribute>
	</xsl:element>
	<xsl:element name="Param">
		<xsl:attribute name="name">_temp_ErrorY</xsl:attribute>
		<xsl:attribute name="com">*</xsl:attribute>
		<xsl:attribute name="val">=_temp_ErrorCount</xsl:attribute>
	</xsl:element>
	<xsl:element name="Param">
		<xsl:attribute name="name">_temp_ErrorY</xsl:attribute>
		<xsl:attribute name="com">rd</xsl:attribute>
		<xsl:attribute name="val">96</xsl:attribute>
		<xsl:element name="Param">
			<xsl:attribute name="name">_temp_ErrorY</xsl:attribute>
			<xsl:attribute name="val">3</xsl:attribute>
		</xsl:element>
		<xsl:element name="Param">
			<xsl:attribute name="name">_temp_ErrorCount</xsl:attribute>
			<xsl:attribute name="val">0</xsl:attribute>
		</xsl:element>
	</xsl:element>
	<xsl:element name="Param">
		<xsl:attribute name="name">_temp_ErrorMsg</xsl:attribute>
		<xsl:attribute name="val">�G���[�I�F</xsl:attribute>
	</xsl:element>
	<xsl:element name="Param">
		<xsl:attribute name="name">_temp_ErrorMsg</xsl:attribute>
		<xsl:attribute name="com">+</xsl:attribute>
		<xsl:attribute name="val">=_temp_SysStageload</xsl:attribute>
	</xsl:element>
	<xsl:element name="Param">
		<xsl:attribute name="name">_temp_ErrorMsg</xsl:attribute>
		<xsl:attribute name="com">+</xsl:attribute>
		<xsl:attribute name="val">���ǂݍ��߂܂���I</xsl:attribute>
	</xsl:element>

	<xsl:element name="Param">
		<xsl:attribute name="name">_temp_NotFError</xsl:attribute>
		<xsl:attribute name="val">�G���[�I�F���̃C�x���g�ɂ̓t�@�C���^�O�������Ă��܂���I(����F</xsl:attribute>
	</xsl:element>
	<xsl:element name="Param">
		<xsl:attribute name="name">_temp_NotFError</xsl:attribute>
		<xsl:attribute name="com">+</xsl:attribute>
		<xsl:attribute name="val">=_temp_sclastcallpath</xsl:attribute>
	</xsl:element>
	<xsl:element name="Param">
		<xsl:attribute name="name">_temp_NotFError</xsl:attribute>
		<xsl:attribute name="com">+</xsl:attribute>
		<xsl:attribute name="val">)</xsl:attribute>
	</xsl:element>

	<xsl:element name="Param">
		<xsl:attribute name="name">_temp_ErrorMsg</xsl:attribute>
		<xsl:attribute name="com">+</xsl:attribute>
		<xsl:attribute name="val">(<xsl:value-of select="$type"/>�^�̃G���[)</xsl:attribute>
	</xsl:element>
	<xsl:element name="Param">
		<xsl:attribute name="name">_temp_NotPermiss</xsl:attribute>
		<xsl:attribute name="val">�x���I�F���̃t�@�C���͋�����Ă܂���B(</xsl:attribute>
	</xsl:element>
	<xsl:element name="Param">
		<xsl:attribute name="name">_temp_NotPermiss</xsl:attribute>
		<xsl:attribute name="com">+</xsl:attribute>
		<xsl:attribute name="val">=_temp_sclastreadpath</xsl:attribute>
	</xsl:element>
	<xsl:element name="Param">
		<xsl:attribute name="name">_temp_NotPermiss</xsl:attribute>
		<xsl:attribute name="com">+</xsl:attribute>
		<xsl:attribute name="val">)</xsl:attribute>
	</xsl:element>
	<xsl:element name="Param">
		<xsl:attribute name="name">_temp_NotPermiss</xsl:attribute>
		<xsl:attribute name="com">+</xsl:attribute>
		<xsl:attribute name="val">=_temp_sclastcallpath</xsl:attribute>
	</xsl:element>
	<xsl:element name="Param">
		<xsl:attribute name="name">_temp_NErrorMsg</xsl:attribute>
		<xsl:attribute name="val">�G���[�I�F���̃C�x���g�ɂ̓t�@�C���^�O�������Ă��܂���I(����F</xsl:attribute>
	</xsl:element>
	<xsl:element name="Param">
		<xsl:attribute name="name">_temp_NErrorMsg</xsl:attribute>
		<xsl:attribute name="com">+</xsl:attribute>
		<xsl:attribute name="val">=_temp_sclastcallpath</xsl:attribute>
	</xsl:element>
	<xsl:element name="Param">
		<xsl:attribute name="name">_temp_NErrorMsg</xsl:attribute>
		<xsl:attribute name="com">+</xsl:attribute>
		<xsl:attribute name="val">)</xsl:attribute>
	</xsl:element>
	<xsl:element name="Param">
		<xsl:attribute name="name">_temp_SErrorMsg</xsl:attribute>
		<xsl:attribute name="val">�G���[�I�F�͈͊O�̓ǂݍ��݂ł��I(</xsl:attribute>
	</xsl:element>
	<xsl:element name="Param">
		<xsl:attribute name="name">_temp_SErrorMsg</xsl:attribute>
		<xsl:attribute name="com">+</xsl:attribute>
		<xsl:attribute name="val">=_temp_sclastreadpath</xsl:attribute>
	</xsl:element>
	<xsl:element name="Param">
		<xsl:attribute name="name">_temp_SErrorMsg</xsl:attribute>
		<xsl:attribute name="com">+</xsl:attribute>
		<xsl:attribute name="val">)</xsl:attribute>
	</xsl:element>
	<xsl:element name="Param">
		<xsl:attribute name="name">S_SEC</xsl:attribute>
		<xsl:attribute name="com">+</xsl:attribute>
		<xsl:attribute name="val">1</xsl:attribute>
	</xsl:element>
	<xsl:element name="Powered">
		<xsl:attribute name="x">0</xsl:attribute>
		<xsl:attribute name="y">=_temp_ErrorY</xsl:attribute>
		<xsl:attribute name="w">1000</xsl:attribute>
		<xsl:attribute name="h">18</xsl:attribute>
		<xsl:attribute name="life">5000</xsl:attribute>
		<xsl:element name="Tag">
			<xsl:if test="$type = 'System'"><xsl:attribute name="msg">=_temp_SErrorMsg</xsl:attribute></xsl:if>
			<xsl:if test="$type = 'Event'"><xsl:attribute name="msg">�G���[�I�FEvent/<xsl:value-of select="$path"/>���ǂݍ��߂܂���I(<xsl:value-of select="$type"/>�^�̃G���[)</xsl:attribute></xsl:if>
			<xsl:if test="$type = 'Common'"><xsl:attribute name="msg">�G���[�I�FEvent/Common/<xsl:value-of select="$path"/>.xml���ǂݍ��߂܂���I(<xsl:value-of select="$type"/>�^�̃G���[)</xsl:attribute></xsl:if>
			<xsl:if test="$type = 'World'"><xsl:attribute name="msg">�G���[�I�FEvent/World/<xsl:value-of select="$path"/>.xml���ǂݍ��߂܂���I(<xsl:value-of select="$type"/>�^�̃G���[)</xsl:attribute></xsl:if>
			<xsl:if test="$type = 'Point'"><xsl:attribute name="msg">�G���[�I�F<xsl:value-of select="$path"/>���ǂݍ��߂܂���I(<xsl:value-of select="$type"/>�^�̃G���[)</xsl:attribute></xsl:if>
			<xsl:if test="$type = 'Stage'"><xsl:attribute name="msg">=_temp_ErrorMsg</xsl:attribute></xsl:if>
			<xsl:if test="$type = 'Fade'"><xsl:attribute name="msg">�G���[�I�F<xsl:value-of select="$path"/>���ǂݍ��߂܂���I(<xsl:value-of select="$type"/>�^�̃G���[)</xsl:attribute></xsl:if>
			<xsl:if test="$type = 'Permission'"><xsl:attribute name="msg">=_temp_NotPermiss</xsl:attribute></xsl:if>
			<xsl:if test="$type = 'NotFile'"><xsl:attribute name="msg">=_temp_NErrorMsg</xsl:attribute></xsl:if>
			<xsl:attribute name="col">0xffff0000</xsl:attribute>
		</xsl:element>
	</xsl:element>
	<xsl:element name="Param">
		<xsl:attribute name="name">_temp_ErrorCount</xsl:attribute>
		<xsl:attribute name="com">+</xsl:attribute>
		<xsl:attribute name="val">1</xsl:attribute>
	</xsl:element>

	<xsl:element name="Delay">
		<xsl:attribute name="time">5000</xsl:attribute>
		<xsl:element name="Param">
			<xsl:attribute name="name">_temp_ErrorCount</xsl:attribute>
			<xsl:attribute name="com">-</xsl:attribute>
			<xsl:attribute name="val">1</xsl:attribute>
		</xsl:element>
		<xsl:element name="Param">
			<xsl:attribute name="name">_temp_ErrorCount</xsl:attribute>
			<xsl:attribute name="com">ld</xsl:attribute>
			<xsl:attribute name="val">0</xsl:attribute>
			<xsl:element name="Param">
				<xsl:attribute name="name">_temp_ErrorCount</xsl:attribute>
				<xsl:attribute name="val">0</xsl:attribute>
			</xsl:element>
		</xsl:element>
	</xsl:element>


	</xsl:element>
</xsl:template>

</xsl:stylesheet>
