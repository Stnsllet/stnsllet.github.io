<?xml version="1.0" encoding="Shift_JIS"?>
<xsl:stylesheet xmlns:xsl="http://www.w3.org/1999/XSL/Transform" version="1.0"  xmlns:spibre="http://geroha.ld.infoseek.co.jp/spibre/">
<xsl:output method="xml" version="1.0" encoding="Shift_JIS" indent="yes" />

<msxsl:script xmlns:msxsl="urn:schemas-microsoft-com:xslt" language="JavaScript" implements-prefix="spibre">

  function getDate(){
  	var dateObj=new Date();
   	var nowDate=dateObj.toLocaleString();

   	return(nowDate);
  }

</msxsl:script>

<xsl:template match="CallTrans">
<Event>
	<xsl:element name="Param">
		<xsl:attribute name="name">_temp_msg</xsl:attribute>
<xsl:attribute name="val"><xsl:value-of select="spibre:getDate()" /></xsl:attribute>
	</xsl:element>
</Event>
</xsl:template>

</xsl:stylesheet>
