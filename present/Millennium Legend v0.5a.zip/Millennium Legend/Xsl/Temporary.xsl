<?xml version="1.0" encoding="Shift_JIS"?>
<xsl:stylesheet xmlns:xsl="http://www.w3.org/1999/XSL/Transform" version="1.0"  xmlns:spibre="http://geroha.ld.infoseek.co.jp/spibre/">
<xsl:output method="xml" version="1.0" encoding="Shift_JIS" indent="yes" />

<xsl:param name="_temp_sclastcallpath"/>
<xsl:param name="_temp_templary_idp"/>

<xsl:template match="CallTrans">

	<xsl:variable name="type" select="@type"/>
	<xsl:variable name="id" select="@id"/>
	<xsl:variable name="lle" select="$_temp_sclastcallpath"/>
	<xsl:variable name="temps" select="$_temp_templary_idp"/>

	<xsl:element name="Event">

		<xsl:if test="@type='Permission'">
			<xsl:if test="contains($temps, $lle)">
				<xsl:element name="Event">
					<xsl:attribute name="flg">t_Permission</xsl:attribute>
				</xsl:element>
			</xsl:if>
		</xsl:if>

		<xsl:if test="$id">
			<xsl:element name="Param">
				<xsl:attribute name="name">_temp_templary_idp</xsl:attribute>
				<xsl:attribute name="com">+</xsl:attribute>
				<xsl:attribute name="val"><xsl:value-of select="$id"/></xsl:attribute>
			</xsl:element>
		</xsl:if>

	</xsl:element>
</xsl:template>

</xsl:stylesheet>
