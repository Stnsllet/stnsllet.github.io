<?xml version="1.0" encoding="Shift_JIS"?>
<xsl:stylesheet xmlns:xsl="http://www.w3.org/1999/XSL/Transform" version="1.0"  xmlns:spibre="http://geroha.ld.infoseek.co.jp/spibre/">
<xsl:output method="xml" version="1.0" encoding="Shift_JIS" indent="yes" />


<xsl:param name="_temp_convertdata"/>
<xsl:template match="CallTrans">
	<xsl:variable name="data" select="$_temp_convertdata"/>

	<xsl:element name="Event">
		<xsl:for-each select="document(concat('../',$data))">
			<xsl:copy><xsl:copy-of select="."/></xsl:copy>
		</xsl:for-each>
	</xsl:element>
</xsl:template>

</xsl:stylesheet>
