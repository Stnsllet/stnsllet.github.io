<?xml version="1.0" encoding="Shift_JIS"?>
<xsl:stylesheet xmlns:xsl="http://www.w3.org/1999/XSL/Transform" version="1.0" xmlns:spibre="a">
<xsl:output method="xml" version="1.0" encoding="Shift_JIS" indent="yes" />

<xsl:param name="_temp_Pos.X"/>
<xsl:param name="_temp_Pos.Y"/>
<xsl:param name="_temp_Pos.D"/>
<xsl:param name="_temp_pos"/>

<xsl:template match="CallTrans">
	<xsl:variable name="params" select="@params"/>
	<xsl:variable name="pos" select="$_temp_pos"/>
	<xsl:variable name="x" select="substring-before($_temp_pos,'/')"/>
	<xsl:variable name="y" select="substring-before(substring-after($_temp_pos,'/'),'/')"/>
	<xsl:variable name="d" select="substring-after(substring-after($_temp_pos,'/'),'/')"/>
  <xsl:choose>
        <xsl:when test="$params = '_temp_Pos.X/_temp_pos'">
		<xsl:element name="Param">
			<xsl:attribute name="name">_temp_Pos.X</xsl:attribute>
			<xsl:attribute name="val"><xsl:value-of select="$x"/></xsl:attribute>
		</xsl:element>
        </xsl:when>
         <xsl:when test="$params = '_temp_Pos.Y/_temp_pos'">
		<xsl:element name="Param">
			<xsl:attribute name="name">_temp_Pos.Y</xsl:attribute>
			<xsl:attribute name="val"><xsl:value-of select="$y"/></xsl:attribute>
		</xsl:element>
        </xsl:when>
        <xsl:when test="$params = '_temp_Pos.D/_temp_pos'">
		<xsl:element name="Param">
			<xsl:attribute name="name">_temp_Pos.D</xsl:attribute>
			<xsl:attribute name="val"><xsl:value-of select="$d"/></xsl:attribute>
		</xsl:element>
        </xsl:when>
        <xsl:when test="$params = '_temp_pos/_temp_Pos.X/_temp_Pos.Y/_temp_Pos.D'">
		<xsl:element name="Param">
			<xsl:attribute name="name">_temp_pos</xsl:attribute>
			<xsl:attribute name="val"><xsl:value-of select="$_temp_Pos.X"/>/<xsl:value-of select="$_temp_Pos.Y"/>/<xsl:value-of select="$_temp_Pos.D"/></xsl:attribute>
		</xsl:element>
        </xsl:when>
</xsl:choose>



</xsl:template>

</xsl:stylesheet>
