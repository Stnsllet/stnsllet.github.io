<?xml version="1.0" encoding="Shift_JIS"?>
<xsl:stylesheet xmlns:xsl="http://www.w3.org/1999/XSL/Transform" version="1.0" xmlns:spibre="a">
<xsl:output method="xml" version="1.0" encoding="Shift_JIS" indent="yes" />

<xsl:param name="_temp_lock"/>
<xsl:param name="_temp_base"/>
<xsl:param name="_temp_look"/>
<msxsl:script xmlns:msxsl="urn:schemas-microsoft-com:xslt" language="JavaScript" implements-prefix="spibre">
  function sin(data){
   	return(Math.sin(Math.PI * data));
  }
  function cos(data){
   	return(Math.cos(Math.PI * data));
  }
  function x(x,lx){
	var nx = 0;
	nx = x - lx;
   	return(nx);
  }
  function y(y,ly){
	var ny = 0;
	ny = y - ly;
   	return(ny);
  }
  function atan2(x,y){
   	return(Math.atan2(y, x));
  }
</msxsl:script>

<xsl:template match="CallTrans">
	<xsl:variable name="speed" select="200"/>
	<xsl:variable name="x" select="substring-before($_temp_base,'/')"/>
	<xsl:variable name="y" select="substring-before(substring-after($_temp_base,'/'),'/')"/>
	<xsl:variable name="d" select="substring-after(substring-after($_temp_base,'/'),'/')"/>
	<xsl:variable name="lx" select="substring-before($_temp_look,'/')"/>
	<xsl:variable name="ly" select="substring-before(substring-after($_temp_look,'/'),'/')"/>
	<xsl:variable name="ld" select="substring-after(substring-after($_temp_look,'/'),'/')"/>
	<xsl:variable name="nx" select="spibre:x($x,$lx)"/>
	<xsl:variable name="ny" select="spibre:y($y,$ly)"/>

	<xsl:variable name="nx2" select="format-number(0*spibre:sin(spibre:atan2($nx,$ny)) + $speed *spibre:cos(spibre:atan2($nx,$ny)) + $x, '0.##')"/>
	<xsl:variable name="ny2" select="format-number(-0*spibre:cos(spibre:atan2($nx,$ny)) + $speed *spibre:sin(spibre:atan2($nx,$ny)) + $y, '0.##')"/>

	<xsl:element name="Param">
		<xsl:attribute name="name">_temp_lock</xsl:attribute>
		<xsl:attribute name="val"><xsl:value-of select="$nx2"/>/<xsl:value-of select="$ny2"/>/<xsl:value-of select="$d"/></xsl:attribute>
	</xsl:element>

</xsl:template>

</xsl:stylesheet>
