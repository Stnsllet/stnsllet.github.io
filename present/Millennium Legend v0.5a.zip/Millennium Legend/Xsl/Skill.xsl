<?xml version="1.0" encoding="Shift_JIS"?>
<xsl:stylesheet xmlns:xsl="http://www.w3.org/1999/XSL/Transform" version="1.0"  xmlns:spibre="http://geroha.ld.infoseek.co.jp/spibre/">
<xsl:output method="xml" version="1.0" encoding="Shift_JIS" indent="yes" />

<xsl:param name="_temp_skname"/>

<xsl:template match="CallTrans">
	<xsl:variable name="SkillDef" select="document('../Data/Skill.xml')/SkillDefine"/>
	<xsl:variable name="name" select="@name"/>
	<xsl:variable name="search" select="$_temp_skname"/>
	<xsl:element name="List">
	<xsl:for-each select="$SkillDef/Skill[@name=$_temp_skname]">
		<xsl:element name="Param">
			<xsl:attribute name="name"><xsl:value-of select="$name"/></xsl:attribute>
			<xsl:attribute name="val"><xsl:value-of select="@name"/></xsl:attribute>
		</xsl:element>
		<xsl:element name="Param">
			<xsl:attribute name="name"><xsl:value-of select="$name"/>.type</xsl:attribute>
			<xsl:attribute name="val"><xsl:value-of select="@type"/></xsl:attribute>
		</xsl:element>
		<xsl:element name="Param">
			<xsl:attribute name="name"><xsl:value-of select="$name"/>.str</xsl:attribute>
			<xsl:attribute name="val"><xsl:value-of select="@str"/></xsl:attribute>
		</xsl:element>
		<xsl:element name="Param">
			<xsl:attribute name="name"><xsl:value-of select="$name"/>.help</xsl:attribute>
			<xsl:attribute name="val"><xsl:value-of select="@help"/></xsl:attribute>
		</xsl:element>
		<xsl:element name="Param">
			<xsl:attribute name="name"><xsl:value-of select="$name"/>.x</xsl:attribute>
			<xsl:attribute name="val"><xsl:value-of select="@x"/></xsl:attribute>
		</xsl:element>
		<xsl:element name="Param">
			<xsl:attribute name="name"><xsl:value-of select="$name"/>.y</xsl:attribute>
			<xsl:attribute name="val"><xsl:value-of select="@y"/></xsl:attribute>
		</xsl:element>
		<xsl:call-template name="getIcon">
			<xsl:with-param name="name" select="$name"/>
			<xsl:with-param name="x" select="@x"/>
			<xsl:with-param name="y" select="@y"/>
		</xsl:call-template>
	</xsl:for-each>

	</xsl:element>
</xsl:template>

<xsl:template name="getIcon">
	<xsl:param name="name"/>
	<xsl:param name="x"/>
	<xsl:param name="y"/>
	<xsl:param name="iconlist" select="document('../Event/Common/SkillIcon.xml')/Icon/X[@x=$x]"/>
	<xsl:element name="List">
	<xsl:for-each select="$iconlist/Y[@y=$y]">
		<xsl:element name="Param">
			<xsl:attribute name="name"><xsl:value-of select="$name"/>.icon</xsl:attribute>
			<xsl:attribute name="val"><xsl:value-of select="@icon"/></xsl:attribute>
		</xsl:element>
	</xsl:for-each>
	</xsl:element>
</xsl:template>

</xsl:stylesheet>
