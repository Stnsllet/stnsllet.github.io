<?xml version="1.0" encoding="Shift_JIS"?>
<xsl:stylesheet xmlns:xsl="http://www.w3.org/1999/XSL/Transform" version="1.0"  xmlns:spibre="http://geroha.ld.infoseek.co.jp/spibre/">
<xsl:output method="xml" version="1.0" encoding="Shift_JIS" indent="yes" />

<xsl:template match="CallTrans">
	<xsl:variable name="param" select="@param"/>
	<xsl:variable name="team" select="@team"/>
	<xsl:variable name="type" select="@type"/>
	<xsl:variable name="func" select="@func"/>
	<xsl:variable name="name" select="@name"/>
	<xsl:variable name="hide" select="@hide"/>
	<xsl:variable name="com" select="@com"/>
	<xsl:variable name="no" select="@no"/>
	<xsl:variable name="file" select="@file"/>
	<xsl:variable name="ex" select="@ex"/>

	<xsl:element name="Event">
		<xsl:if test="$type = 'Entry'">
		<xsl:element name="Choice">
			<xsl:element name="Command">
				<xsl:attribute name="com">param/leader/_temp_name<xsl:value-of select="$no"/>/<xsl:value-of select="$no"/></xsl:attribute>
				<xsl:element name="Param">
					<xsl:attribute name="name">_temp_cou<xsl:value-of select="$no"/></xsl:attribute>
					<xsl:attribute name="val"></xsl:attribute>
				</xsl:element>
				<xsl:element name="Param">
					<xsl:attribute name="name">_temp_exp<xsl:value-of select="$no"/></xsl:attribute>
					<xsl:attribute name="val">�E</xsl:attribute>
				</xsl:element>
				<xsl:element name="Command">
					<xsl:attribute name="com">param/member/_temp_cou<xsl:value-of select="$no"/>/=_temp_name<xsl:value-of select="$no"/>/name</xsl:attribute>
				</xsl:element>
				<xsl:element name="Param">
					<xsl:attribute name="name">_temp_exp<xsl:value-of select="$no"/></xsl:attribute>
					<xsl:attribute name="com">+</xsl:attribute>
					<xsl:attribute name="val">=_temp_cou<xsl:value-of select="$no"/></xsl:attribute>
				</xsl:element>
				<xsl:element name="Param">
					<xsl:attribute name="name">_temp_exp<xsl:value-of select="$no"/></xsl:attribute>
					<xsl:attribute name="com">+</xsl:attribute>
					<xsl:attribute name="val">����</xsl:attribute>
				</xsl:element>
			</xsl:element>
			<xsl:element name="Event">
				<xsl:attribute name="flg">t_exp<xsl:value-of select="$no"/></xsl:attribute>
			</xsl:element>
		</xsl:element>
		</xsl:if>

		<xsl:if test="$type = 'Function'">
			<xsl:element name="Param">
				<xsl:attribute name="name">_temp_func</xsl:attribute>
				<xsl:attribute name="val"><xsl:value-of select="$func"/></xsl:attribute>
			</xsl:element>
			<xsl:element name="Param">
				<xsl:attribute name="name">_temp_ex</xsl:attribute>
				<xsl:attribute name="val"><xsl:value-of select="$ex"/></xsl:attribute>
			</xsl:element>
			<xsl:element name="Param">
				<xsl:attribute name="name">_temp_file</xsl:attribute>
				<xsl:attribute name="val">Event/Tournament/<xsl:value-of select="$file"/></xsl:attribute>
			</xsl:element>
			<xsl:element name="LoadEvent">
				<xsl:attribute name="path">Event/Tournament/Common/Function.xml</xsl:attribute>
			</xsl:element>
		</xsl:if>

		<xsl:if test="$type = 'TeamSet'">
			<xsl:element name="Param">
				<xsl:attribute name="name">_temp_teamset</xsl:attribute>
				<xsl:attribute name="val">_temp_EnemyTeam<xsl:value-of select="$team"/></xsl:attribute>
			</xsl:element>
			<xsl:element name="Param">
				<xsl:attribute name="name">_temp_Extype</xsl:attribute>
				<xsl:attribute name="val">0</xsl:attribute>
			</xsl:element>
			<xsl:if test="$ex = '1'">
			<xsl:element name="Param">
				<xsl:attribute name="name">_temp_Extype</xsl:attribute>
				<xsl:attribute name="val">1</xsl:attribute>
			</xsl:element>
			</xsl:if>
			<xsl:element name="LoadEvent">
				<xsl:attribute name="path">Event/Tournament/Common/Random Select Trial.xml</xsl:attribute>
			</xsl:element>
		</xsl:if>

		<xsl:if test="$type = 'Rename'">
			<xsl:element name="Param">
				<xsl:attribute name="name">_temp_ep</xsl:attribute>
				<xsl:attribute name="val">=_temp_EnemyTeam<xsl:value-of select="$team"/></xsl:attribute>
			</xsl:element>
			<xsl:element name="LoadEvent">
				<xsl:attribute name="path">Event/Tournament/Common/ENameList.xml</xsl:attribute>
			</xsl:element>
			<xsl:element name="Param">
				<xsl:attribute name="name">_temp_EnemyTeamName<xsl:value-of select="$team"/></xsl:attribute>
				<xsl:attribute name="val">=_temp_epf</xsl:attribute>
			</xsl:element>
			<xsl:if test="$hide = '1'">
			<xsl:element name="Param">
				<xsl:attribute name="name">_temp_EnemyTeamName<xsl:value-of select="$team"/></xsl:attribute>
				<xsl:attribute name="val">???????????</xsl:attribute>
			</xsl:element>
			</xsl:if>
		</xsl:if>

		<xsl:if test="$type = 'Ban'">
			<xsl:element name="State">
				<xsl:attribute name="name"><xsl:value-of select="$name"/></xsl:attribute>
				<xsl:element name="Event">
					<xsl:attribute name="flg"><xsl:value-of select="$name"/>_ent</xsl:attribute>
				</xsl:element>
				<xsl:element name="Param">
					<xsl:attribute name="name">_temp_err</xsl:attribute>
					<xsl:attribute name="com">+</xsl:attribute>
					<xsl:attribute name="val">1</xsl:attribute>
				</xsl:element>
				<xsl:element name="Command">
					<xsl:attribute name="com">param/member/_temp_idname/<xsl:value-of select="$name"/>/name</xsl:attribute>
				</xsl:element>
				<xsl:element name="Param">
					<xsl:attribute name="name">_temp_list</xsl:attribute>
					<xsl:attribute name="com">+</xsl:attribute>
					<xsl:attribute name="val">=_temp_idname</xsl:attribute>
				</xsl:element>
				<xsl:element name="Param">
					<xsl:attribute name="name">_temp_list</xsl:attribute>
					<xsl:attribute name="com">+</xsl:attribute>
					<xsl:attribute name="val">&#xa;</xsl:attribute>
				</xsl:element>
			</xsl:element>
		</xsl:if>

		<xsl:if test="$type = 'Stock'">
			<xsl:element name="ChkFlg">
				<xsl:attribute name="on"><xsl:value-of select="$name"/>_ent</xsl:attribute>
				<xsl:element name="Command">
					<xsl:attribute name="com">data/unview/<xsl:value-of select="$name"/></xsl:attribute>
				</xsl:element>
				<xsl:element name="Command">
					<xsl:attribute name="com">data/review/<xsl:value-of select="$name"/></xsl:attribute>
				</xsl:element>
			</xsl:element>
		</xsl:if>

		<xsl:if test="$type = 'Unlock'">
			<xsl:element name="Param">
				<xsl:attribute name="name">_temp_team</xsl:attribute>
				<xsl:attribute name="val"><xsl:value-of select="$team"/></xsl:attribute>
			</xsl:element>
			<xsl:element name="Param">
				<xsl:attribute name="name">_temp_Unlock<xsl:value-of select="$no"/></xsl:attribute>
				<xsl:attribute name="val">Unl_</xsl:attribute>
			</xsl:element>
			<xsl:element name="Param">
				<xsl:attribute name="name">_temp_Unlock<xsl:value-of select="$no"/></xsl:attribute>
				<xsl:attribute name="com">+</xsl:attribute>
				<xsl:attribute name="val">=_temp_team</xsl:attribute>
			</xsl:element>
			<xsl:element name="ChkFlg">
				<xsl:attribute name="on">=_temp_Unlock<xsl:value-of select="$no"/></xsl:attribute>
				<xsl:element name="Event">
				<xsl:attribute name="flg">Unlock<xsl:value-of select="$no"/></xsl:attribute>
				</xsl:element>
			</xsl:element>
		</xsl:if>

		<xsl:if test="$type = 'ReadPaty'">
			<xsl:element name="Param">
				<xsl:attribute name="name">_temp_EnemyTeamA</xsl:attribute>
				<xsl:attribute name="val"></xsl:attribute>
			</xsl:element>
			<xsl:element name="Param">
				<xsl:attribute name="name">_temp_EnemyTeamW</xsl:attribute>
				<xsl:attribute name="val"></xsl:attribute>
			</xsl:element>
			<xsl:element name="Param">
				<xsl:attribute name="name">_temp_EnemyTeamT</xsl:attribute>
				<xsl:attribute name="val"></xsl:attribute>
			</xsl:element>
			<xsl:element name="Param">
				<xsl:attribute name="name">_temp_EnemyTeam<xsl:value-of select="$team"/></xsl:attribute>
				<xsl:attribute name="val"><xsl:value-of select="$name"/></xsl:attribute>
			</xsl:element>
			<xsl:element name="LoadEvent">
				<xsl:attribute name="path">Event/Tournament/Party/<xsl:value-of select="$name"/>.xml</xsl:attribute>
			</xsl:element>
			<xsl:element name="LoadEvent">
				<xsl:attribute name="path">Event/Tournament/Common/SkillEvent.xml</xsl:attribute>
			</xsl:element>
		</xsl:if>
		<xsl:if test="$com">
			<xsl:element name="LoadEvent">
				<xsl:attribute name="path">Event/Tournament/Common/<xsl:value-of select="$com"/>.xml</xsl:attribute>
			</xsl:element>
		</xsl:if>
	</xsl:element>

</xsl:template>

</xsl:stylesheet>
