<?xml version="1.0" encoding="Shift_JIS"?>
<xsl:stylesheet xmlns:xsl="http://www.w3.org/1999/XSL/Transform" version="1.0"  xmlns:spibre="http://geroha.ld.infoseek.co.jp/spibre/">
<xsl:output method="xml" version="1.0" encoding="Shift_JIS" indent="yes" />
<xsl:param name="_temp_num"/>

<msxsl:script xmlns:msxsl="urn:schemas-microsoft-com:xslt" language="JavaScript" implements-prefix="spibre">
<![CDATA[
  function trans(num,base,change){
	var n=String(num); 
	var re = new RegExp("[a-z]+", "i");
	var str = parseInt(n, base).toString(change);
	if(String(str).match(re)||str<10)str = ("0"+str).slice(-2);
   	return(str);
  }
]]>
</msxsl:script>

<xsl:template match="CallTrans">
	<xsl:variable name="num" select="string(@num)"/>
	<xsl:variable name="base" select="string(@base)"/>
	<xsl:variable name="pars" select="string(@pars)"/>
	<xsl:variable name="nums" select="string($_temp_num)"/>


	<xsl:element name="Event">
	<xsl:element name="Param">
		<xsl:attribute name="name">_temp_temps</xsl:attribute>
		<xsl:attribute name="val"></xsl:attribute>
	</xsl:element>
	<xsl:element name="Param">
		<xsl:attribute name="name">_temp_temps</xsl:attribute>
		<xsl:attribute name="com">+</xsl:attribute>
		<xsl:attribute name="val"><xsl:value-of select="spibre:trans($nums,$base,$pars)"/></xsl:attribute>
	</xsl:element>
	<xsl:element name="Param">
		<xsl:attribute name="name">_temp_num</xsl:attribute>
		<xsl:attribute name="val"><xsl:value-of select="spibre:trans($nums,$base,$pars)"/></xsl:attribute>
	</xsl:element>
	<xsl:if test="$pars > 10">
		<xsl:element name="Param">
			<xsl:attribute name="name">_temp_temps</xsl:attribute>
			<xsl:attribute name="com">ld</xsl:attribute>
			<xsl:attribute name="val">10</xsl:attribute>
			<xsl:element name="Param">
				<xsl:attribute name="name">_temp_num</xsl:attribute>
				<xsl:attribute name="val"></xsl:attribute>
			</xsl:element>
			<xsl:element name="Param">
				<xsl:attribute name="name">_temp_num</xsl:attribute>
				<xsl:attribute name="com">+</xsl:attribute>
				<xsl:attribute name="val">=_temp_temps</xsl:attribute>
			</xsl:element>
		</xsl:element>
	</xsl:if>
	</xsl:element>

</xsl:template>

</xsl:stylesheet>
