<?xml version="1.0" encoding="Shift_JIS"?>
<xsl:stylesheet xmlns:xsl="http://www.w3.org/1999/XSL/Transform" version="1.0" xmlns:spibre="a">
<xsl:output method="xml" version="1.0" encoding="Shift_JIS" indent="yes" />

<msxsl:script xmlns:msxsl="urn:schemas-microsoft-com:xslt" language="JavaScript" implements-prefix="spibre">
  function sin(data){
   	return(Math.sin(Math.PI * data));
  }
  function cos(data){
   	return(Math.cos(Math.PI * data));
  }
</msxsl:script>

<xsl:template match="CallTrans">
	<xsl:variable name="poly" select="@poly"/>
	<xsl:variable name="x" select="@x"/>
	<xsl:variable name="y" select="@y"/>
	<xsl:variable name="d" select="@dir"/>

	<xsl:variable name="nx" select="format-number($shift_f*spibre:sin($d) - $shift_r*spibre:cos($d) + $x, '0.##')"/>
	<xsl:variable name="ny" select="format-number(-$shift_f*spibre:cos($d) - $shift_r*spibre:sin($d) + $y, '0.##')"/>
<xsl:element name="Event">
	<xsl:element name="Param">
		<xsl:attribute name="name">_temp_ppsx</xsl:attribute>
		<xsl:attribute name="val"><xsl:value-of select="$nx"/></xsl:attribute>
	</xsl:element>
	<xsl:element name="Param">
		<xsl:attribute name="name">_temp_ppsy</xsl:attribute>
		<xsl:attribute name="val"><xsl:value-of select="$ny"/></xsl:attribute>
	</xsl:element>
	<xsl:element name="Param">
		<xsl:attribute name="name">_temp_ppsd</xsl:attribute>
		<xsl:attribute name="val"><xsl:value-of select="$d"/></xsl:attribute>
	</xsl:element>
</xsl:element>
</xsl:template>

</xsl:stylesheet>
