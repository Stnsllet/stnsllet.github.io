<?xml version="1.0" encoding="Shift_JIS"?>
<xsl:stylesheet xmlns:xsl="http://www.w3.org/1999/XSL/Transform" version="1.0"  xmlns:sys="https://stnsllet.github.io/">
<xsl:output method="xml" version="1.0" encoding="Shift_JIS" indent="yes" />
<xsl:param name="_temp_acpos"/>
<xsl:param name="_temp_acleft"/>
<xsl:param name="_temp_actop"/>
<xsl:param name="_temp_acbottom"/>
<xsl:param name="_temp_acright"/>
<xsl:param name="_temp_acarea"/>

<msxsl:script xmlns:msxsl="urn:schemas-microsoft-com:xslt" language="JavaScript" implements-prefix="sys">
<![CDATA[
function inarea(pos,x1,y1,x2,y2){
	pos1 = pos.split('/');
	if (x1==-1) boolLeft = true;
	else boolLeft = pos1[0] >= x1;
	if (y1==-1) boolTop = true;
	else boolTop = pos1[1] >= y1;
	if (x2==-1) boolRight = true;
	else boolRight = pos1[0] <= x2;
	if (y2==-1) boolBottom = true;
	else boolBottom = pos1[1] <= y2;
	ret = boolLeft&&boolTop&&boolRight&&boolBottom;
	return(ret);
}

function inarea2(pos,area){
	pos1 = pos.split('/');
	area1 = area.split('/');
	if (area1[0]==-1) boolLeft = true;
	else boolLeft = Number(pos1[0]) >= Number(area1[0]);
	if (area1[1]==-1) boolTop = true;
	else boolTop = Number(pos1[1]) >= Number(area1[1]);
	if (area1[2]==-1) boolRight = true;
	else boolRight = Number(pos1[0]) <= Number(area1[2]);
	if (area1[3]==-1) boolBottom = true;
	else boolBottom = Number(pos1[1]) <= Number(area1[3]);
	ret = boolLeft&&boolTop&&boolRight&&boolBottom;
	return(ret);
}

function setarea(x1,y1,x2,y2){
	return(x1+"/"+y1+"/"+x2+"/"+y2);
}
]]>
</msxsl:script>

<xsl:template match="CallTrans">

	<xsl:element name="Event">
	<xsl:choose>

	<xsl:when test="@cycle">
		<xsl:element name="Param">
			<xsl:attribute name="name">_temp_ac<xsl:value-of select="@id"/>bool</xsl:attribute>
			<xsl:attribute name="val"><xsl:value-of select="sys:inarea2($_temp_acpos,$_temp_acarea)"/></xsl:attribute>
		</xsl:element>
	</xsl:when>
	<xsl:when test="@id">
		<xsl:element name="Param">
			<xsl:attribute name="name">_temp_ac<xsl:value-of select="@id"/>area</xsl:attribute>
			<xsl:attribute name="val"><xsl:value-of select="sys:setarea($_temp_acleft,$_temp_actop,$_temp_acright,$_temp_acbottom)"/></xsl:attribute>
		</xsl:element>
	</xsl:when>
	<xsl:when test="not(@id)">
		<xsl:element name="Param">
			<xsl:attribute name="name">_temp_acbool</xsl:attribute>
			<xsl:attribute name="val"><xsl:value-of select="sys:inarea($_temp_acpos,$_temp_acleft,$_temp_actop,$_temp_acright,$_temp_acbottom)"/></xsl:attribute>
		</xsl:element>
	</xsl:when>
	</xsl:choose>
	</xsl:element>

</xsl:template>

</xsl:stylesheet>
